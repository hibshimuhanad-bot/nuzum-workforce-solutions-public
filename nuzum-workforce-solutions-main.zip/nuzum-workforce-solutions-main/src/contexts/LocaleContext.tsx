import { createContext, useContext, useState, useEffect, ReactNode } from "react";

type Locale = "en" | "ar";

interface LocaleContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string) => string;
}

const LocaleContext = createContext<LocaleContextType | undefined>(undefined);

const translations: Record<Locale, Record<string, string>> = {
  en: {
    // Navigation
    "nav.analytics": "Analytics",
    "nav.employees": "Employees",
    "nav.payroll": "Payroll",
    "nav.fleet": "Fleet Management",
    "nav.attendance": "Attendance",
    "nav.documents": "Documents",
    "nav.reports": "Reports",
    "nav.leave": "Leave Requests",
    "nav.roles": "User Roles",
    "nav.settings": "Settings",
    "nav.logout": "Logout",
    
    // Auth
    "auth.signIn": "Sign In",
    "auth.signUp": "Sign Up",
    "auth.email": "Email",
    "auth.password": "Password",
    "auth.companyName": "Company Name",
    "auth.alreadyHaveAccount": "Already have an account?",
    "auth.dontHaveAccount": "Don't have an account?",
    "auth.signInButton": "Sign In",
    "auth.signUpButton": "Create Account",
    
    // Common
    "common.save": "Save",
    "common.cancel": "Cancel",
    "common.delete": "Delete",
    "common.edit": "Edit",
    "common.add": "Add",
    "common.search": "Search",
    "common.filter": "Filter",
    "common.actions": "Actions",
    "common.status": "Status",
    "common.date": "Date",
    "common.name": "Name",
    "common.email": "Email",
    "common.phone": "Phone",
    "common.address": "Address",
    "common.loading": "Loading...",
    "common.noData": "No data available",
    "common.success": "Success",
    "common.error": "Error",
    
    // Employees
    "employees.title": "Employees",
    "employees.addNew": "Add Employee",
    "employees.position": "Position",
    "employees.joinDate": "Join Date",
    "employees.active": "Active",
    "employees.inactive": "Inactive",
    
    // Payroll
    "payroll.title": "Payroll",
    "payroll.baseSalary": "Base Salary",
    "payroll.allowances": "Allowances",
    "payroll.deductions": "Deductions",
    "payroll.netSalary": "Net Salary",
    "payroll.month": "Month",
    "payroll.year": "Year",
    
    // Fleet
    "fleet.title": "Fleet Management",
    "fleet.vehicles": "Vehicles",
    "fleet.maintenance": "Maintenance",
    "fleet.fuelLogs": "Fuel Logs",
    "fleet.assignments": "Assignments",
    
    // Settings
    "settings.title": "Settings",
    "settings.companyProfile": "Company Profile",
    "settings.preferences": "Preferences",
    "settings.darkMode": "Dark Mode",
    "settings.language": "Language",
    "settings.notifications": "Notifications",
    "settings.saveChanges": "Save Changes",
    
    // Analytics
    "analytics.title": "Analytics Dashboard",
    "analytics.aiInsights": "AI Insights",
    "analytics.predictiveMetrics": "Predictive Metrics",
    "analytics.trends": "Trends",
    "analytics.notifications": "Smart Notifications",
  },
  ar: {
    // Navigation
    "nav.analytics": "لوحة التحليلات",
    "nav.employees": "الموظفين",
    "nav.payroll": "كشوف المرتبات",
    "nav.fleet": "إدارة الأسطول",
    "nav.attendance": "الحضور",
    "nav.documents": "المستندات",
    "nav.reports": "التقارير",
    "nav.leave": "طلبات الإجازة",
    "nav.roles": "أدوار المستخدم",
    "nav.settings": "الإعدادات",
    "nav.logout": "تسجيل الخروج",
    
    // Auth
    "auth.signIn": "تسجيل الدخول",
    "auth.signUp": "إنشاء حساب",
    "auth.email": "البريد الإلكتروني",
    "auth.password": "كلمة المرور",
    "auth.companyName": "اسم الشركة",
    "auth.alreadyHaveAccount": "لديك حساب بالفعل؟",
    "auth.dontHaveAccount": "ليس لديك حساب؟",
    "auth.signInButton": "دخول",
    "auth.signUpButton": "إنشاء حساب",
    
    // Common
    "common.save": "حفظ",
    "common.cancel": "إلغاء",
    "common.delete": "حذف",
    "common.edit": "تعديل",
    "common.add": "إضافة",
    "common.search": "بحث",
    "common.filter": "تصفية",
    "common.actions": "الإجراءات",
    "common.status": "الحالة",
    "common.date": "التاريخ",
    "common.name": "الاسم",
    "common.email": "البريد الإلكتروني",
    "common.phone": "الهاتف",
    "common.address": "العنوان",
    "common.loading": "جاري التحميل...",
    "common.noData": "لا توجد بيانات",
    "common.success": "نجح",
    "common.error": "خطأ",
    
    // Employees
    "employees.title": "الموظفين",
    "employees.addNew": "إضافة موظف",
    "employees.position": "المنصب",
    "employees.joinDate": "تاريخ الانضمام",
    "employees.active": "نشط",
    "employees.inactive": "غير نشط",
    
    // Payroll
    "payroll.title": "كشوف المرتبات",
    "payroll.baseSalary": "الراتب الأساسي",
    "payroll.allowances": "البدلات",
    "payroll.deductions": "الاستقطاعات",
    "payroll.netSalary": "صافي الراتب",
    "payroll.month": "الشهر",
    "payroll.year": "السنة",
    
    // Fleet
    "fleet.title": "إدارة الأسطول",
    "fleet.vehicles": "المركبات",
    "fleet.maintenance": "الصيانة",
    "fleet.fuelLogs": "سجلات الوقود",
    "fleet.assignments": "التخصيصات",
    
    // Settings
    "settings.title": "الإعدادات",
    "settings.companyProfile": "ملف الشركة",
    "settings.preferences": "التفضيلات",
    "settings.darkMode": "الوضع الليلي",
    "settings.language": "اللغة",
    "settings.notifications": "الإشعارات",
    "settings.saveChanges": "حفظ التغييرات",
    
    // Analytics
    "analytics.title": "لوحة التحليلات",
    "analytics.aiInsights": "رؤى الذكاء الاصطناعي",
    "analytics.predictiveMetrics": "المقاييس التنبؤية",
    "analytics.trends": "الاتجاهات",
    "analytics.notifications": "الإشعارات الذكية",
  },
};

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocale] = useState<Locale>(() => {
    const savedLocale = localStorage.getItem("locale");
    return (savedLocale === "ar" || savedLocale === "en") ? savedLocale : "en";
  });

  useEffect(() => {
    // Update document direction and language
    document.dir = locale === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = locale;
    localStorage.setItem("locale", locale);
  }, [locale]);

  const t = (key: string): string => {
    return translations[locale][key] || key;
  };

  return (
    <LocaleContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </LocaleContext.Provider>
  );
}

export function useLocale() {
  const context = useContext(LocaleContext);
  if (!context) {
    throw new Error("useLocale must be used within LocaleProvider");
  }
  return context;
}
