import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EmployeeList from "@/components/dashboard/EmployeeList";
import PayrollList from "@/components/payroll/PayrollList";
import AttendanceList from "@/components/attendance/AttendanceList";
import { DocumentList } from "@/components/documents/DocumentList";
import { LeaveRequestsList } from "@/components/leave/LeaveRequestsList";
import { DepartmentList } from "@/components/departments/DepartmentList";
import { UserRolesList } from "@/components/roles/UserRolesList";

const EmployeeManagement = () => {
  return (
    <Tabs defaultValue="employees" className="space-y-6">
      <TabsList className="w-full grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-1">
        <TabsTrigger value="employees">الموظفين</TabsTrigger>
        <TabsTrigger value="payroll">الرواتب</TabsTrigger>
        <TabsTrigger value="attendance">الحضور</TabsTrigger>
        <TabsTrigger value="documents">المرفقات</TabsTrigger>
        <TabsTrigger value="leave">الإجازات</TabsTrigger>
        <TabsTrigger value="departments">الأقسام</TabsTrigger>
        <TabsTrigger value="roles">الصلاحيات</TabsTrigger>
      </TabsList>

      <TabsContent value="employees">
        <EmployeeList />
      </TabsContent>

      <TabsContent value="payroll">
        <PayrollList />
      </TabsContent>

      <TabsContent value="attendance">
        <AttendanceList />
      </TabsContent>

      <TabsContent value="documents">
        <DocumentList />
      </TabsContent>

      <TabsContent value="leave">
        <LeaveRequestsList />
      </TabsContent>

      <TabsContent value="departments">
        <DepartmentList />
      </TabsContent>

      <TabsContent value="roles">
        <UserRolesList />
      </TabsContent>
    </Tabs>
  );
};

export default EmployeeManagement;
