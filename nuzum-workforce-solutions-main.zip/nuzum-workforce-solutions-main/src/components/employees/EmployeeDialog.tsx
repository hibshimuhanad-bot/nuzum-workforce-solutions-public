import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useOrganization } from "@/hooks/useOrganization";
import { useLocale } from "@/contexts/LocaleContext";

interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string;
  position: string;
  join_date: string;
  status: string;
  department_id?: string;
  avatar_url?: string;
  national_id?: string;
  passport_number?: string;
  contract_type?: string;
  salary?: number;
  nationality?: string;
  nationality_type?: string;
  iqama_number?: string;
  iqama_expiry_date?: string;
}

interface EmployeeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  employee?: Employee | null;
  onSuccess: () => void;
}

export function EmployeeDialog({ open, onOpenChange, employee, onSuccess }: EmployeeDialogProps) {
  const { organizationId } = useOrganization();
  const { t } = useLocale();
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    position: "",
    join_date: "",
    status: "active",
    nationality: "",
    nationality_type: "saudi",
    iqama_number: "",
    iqama_expiry_date: "",
  });

  useEffect(() => {
    if (employee) {
      setFormData({
        name: employee.name || "",
        email: employee.email || "",
        phone: employee.phone || "",
        position: employee.position || "",
        join_date: employee.join_date || "",
        status: employee.status || "active",
        nationality: employee.nationality || "",
        nationality_type: employee.nationality_type || "saudi",
        iqama_number: employee.iqama_number || "",
        iqama_expiry_date: employee.iqama_expiry_date || "",
      });
    } else {
      setFormData({
        name: "",
        email: "",
        phone: "",
        position: "",
        join_date: "",
        status: "active",
        nationality: "",
        nationality_type: "saudi",
        iqama_number: "",
        iqama_expiry_date: "",
      });
    }
  }, [employee]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!organizationId) {
      toast.error(t("common.error"), {
        description: "Organization not found",
      });
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("No user found");

      const employeeData = {
        ...formData,
        user_id: user.id,
        organization_id: organizationId,
      };

      if (employee) {
        const { error } = await supabase
          .from("employees")
          .update(employeeData)
          .eq("id", employee.id);

        if (error) throw error;
        toast.success(t("common.success"), {
          description: "Employee updated successfully",
        });
      } else {
        const { error } = await supabase
          .from("employees")
          .insert([employeeData]);

        if (error) throw error;
        toast.success(t("common.success"), {
          description: "Employee added successfully",
        });
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast.error(t("common.error"), {
        description: error.message,
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{employee ? t("common.edit") : t("employees.addNew")}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">{t("common.name")}</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="email">{t("common.email")}</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">{t("common.phone")}</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="position">{t("employees.position")}</Label>
              <Input
                id="position"
                value={formData.position}
                onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="join_date">{t("employees.joinDate")}</Label>
              <Input
                id="join_date"
                type="date"
                value={formData.join_date}
                onChange={(e) => setFormData({ ...formData, join_date: e.target.value })}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="status">{t("common.status")}</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">{t("employees.active")}</SelectItem>
                  <SelectItem value="inactive">{t("employees.inactive")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="border-t pt-4">
            <h3 className="text-sm font-semibold mb-3">معلومات الجنسية</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="nationality">الجنسية</Label>
                <Input
                  id="nationality"
                  value={formData.nationality}
                  onChange={(e) => setFormData({ ...formData, nationality: e.target.value })}
                  placeholder="مصري، هندي، فلبيني..."
                />
              </div>

              <div>
                <Label htmlFor="nationality_type">نوع الجنسية</Label>
                <Select 
                  value={formData.nationality_type} 
                  onValueChange={(value) => setFormData({ ...formData, nationality_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="saudi">سعودي</SelectItem>
                    <SelectItem value="non_saudi">غير سعودي</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {formData.nationality_type === 'non_saudi' && (
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <Label htmlFor="iqama_number">رقم الإقامة</Label>
                  <Input
                    id="iqama_number"
                    value={formData.iqama_number}
                    onChange={(e) => setFormData({ ...formData, iqama_number: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="iqama_expiry_date">تاريخ انتهاء الإقامة</Label>
                  <Input
                    id="iqama_expiry_date"
                    type="date"
                    value={formData.iqama_expiry_date}
                    onChange={(e) => setFormData({ ...formData, iqama_expiry_date: e.target.value })}
                  />
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit">{t("common.save")}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
