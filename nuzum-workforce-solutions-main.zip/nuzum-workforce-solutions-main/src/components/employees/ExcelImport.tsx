import { Button } from "@/components/ui/button";
import { Download, Upload } from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useOrganization } from "@/hooks/useOrganization";

interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string;
  position: string;
  status: string;
  join_date: string;
  department_id?: string;
  national_id?: string;
  passport_number?: string;
  contract_type?: string;
  salary?: number;
}

interface ExcelImportProps {
  employees: Employee[];
  onImportSuccess: () => void;
}

export const ExcelImport = ({ employees, onImportSuccess }: ExcelImportProps) => {
  const { user } = useAuth();
  const { organizationId } = useOrganization();

  const handleExport = () => {
    const exportData = employees.map((emp) => ({
      الاسم: emp.name,
      البريد: emp.email,
      الهاتف: emp.phone,
      المنصب: emp.position,
      الحالة: emp.status,
      "تاريخ الالتحاق": emp.join_date,
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "الموظفون");
    XLSX.writeFile(wb, `employees_${new Date().toISOString().split("T")[0]}.xlsx`);

    toast({ title: "تم تصدير البيانات بنجاح" });
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user || !organizationId) return;

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[];

      if (jsonData.length === 0) {
        toast({
          title: "خطأ",
          description: "الملف فارغ",
          variant: "destructive",
        });
        return;
      }

      // Validate and transform data
      const importData = jsonData.map((row) => ({
        name: row["الاسم"] || row["name"] || "",
        email: row["البريد"] || row["email"] || "",
        phone: row["الهاتف"] || row["phone"] || "",
        position: row["المنصب"] || row["position"] || "",
        status: row["الحالة"] || row["status"] || "active",
        join_date: row["تاريخ الالتحاق"] || row["join_date"] || new Date().toISOString().split("T")[0],
        organization_id: organizationId,
        user_id: user.id,
      }));

      // Validate required fields
      const invalidRows = importData.filter((row) => !row.name || !row.email || !row.phone || !row.position);
      if (invalidRows.length > 0) {
        toast({
          title: "خطأ في البيانات",
          description: `يوجد ${invalidRows.length} صف يحتوي على بيانات غير مكتملة`,
          variant: "destructive",
        });
        return;
      }

      // Insert data
      const { error } = await supabase.from("employees").insert(importData);

      if (error) throw error;

      toast({
        title: "نجح الاستيراد",
        description: `تم استيراد ${importData.length} موظف`,
      });

      onImportSuccess();
      e.target.value = "";
    } catch (error: any) {
      toast({
        title: "خطأ في الاستيراد",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex gap-2">
      <Button variant="outline" onClick={handleExport}>
        <Download className="h-4 w-4 ml-2" />
        تصدير Excel
      </Button>
      <Button variant="outline" asChild>
        <label className="cursor-pointer">
          <Upload className="h-4 w-4 ml-2" />
          استيراد Excel
          <input
            type="file"
            accept=".xlsx,.xls"
            className="hidden"
            onChange={handleImport}
          />
        </label>
      </Button>
    </div>
  );
};
