import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface RentalAgreementDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  agreement?: any;
}

export default function RentalAgreementDialog({ open, onOpenChange, agreement }: RentalAgreementDialogProps) {
  const { organizationId } = useOrganization();
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    project_id: "",
    vehicle_id: "",
    supplier_id: "",
    daily_rate: "",
    monthly_rate: "",
    billing_type: "daily",
    start_date: "",
    end_date: "",
    terms: "",
    status: "active",
    notes: "",
  });

  const { data: projects = [] } = useQuery({
    queryKey: ["fleet_projects", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase.from("fleet_projects").select("*").eq("organization_id", organizationId);
      if (error) throw error;
      return data || [];
    },
    enabled: !!organizationId,
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["vehicles", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase.from("vehicles").select("*").eq("organization_id", organizationId);
      if (error) throw error;
      return data || [];
    },
    enabled: !!organizationId,
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase.from("suppliers").select("*").eq("organization_id", organizationId);
      if (error) throw error;
      return data || [];
    },
    enabled: !!organizationId,
  });

  useEffect(() => {
    if (agreement) {
      setFormData({
        project_id: agreement.project_id || "",
        vehicle_id: agreement.vehicle_id || "",
        supplier_id: agreement.supplier_id || "",
        daily_rate: agreement.daily_rate || "",
        monthly_rate: agreement.monthly_rate || "",
        billing_type: agreement.billing_type || "daily",
        start_date: agreement.start_date || "",
        end_date: agreement.end_date || "",
        terms: agreement.terms || "",
        status: agreement.status || "active",
        notes: agreement.notes || "",
      });
    } else {
      setFormData({
        project_id: "",
        vehicle_id: "",
        supplier_id: "",
        daily_rate: "",
        monthly_rate: "",
        billing_type: "daily",
        start_date: "",
        end_date: "",
        terms: "",
        status: "active",
        notes: "",
      });
    }
  }, [agreement]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const payload = {
        ...formData,
        organization_id: organizationId,
        user_id: user.id,
        daily_rate: parseFloat(formData.daily_rate),
        monthly_rate: formData.monthly_rate ? parseFloat(formData.monthly_rate) : null,
        end_date: formData.end_date || null,
      };

      if (agreement) {
        const { error } = await supabase.from("vehicle_rental_agreements").update(payload).eq("id", agreement.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("vehicle_rental_agreements").insert([payload]);
        if (error) throw error;
      }

      queryClient.invalidateQueries({ queryKey: ["rental_agreements"] });
      toast.success(agreement ? "تم تحديث الاتفاقية بنجاح" : "تم إضافة الاتفاقية بنجاح");
      onOpenChange(false);
    } catch (error: any) {
      toast.error("فشل حفظ البيانات: " + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{agreement ? "تعديل الاتفاقية" : "إضافة اتفاقية إيجار جديدة"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="project_id">المشروع *</Label>
              <Select value={formData.project_id} onValueChange={(value) => setFormData({ ...formData, project_id: value })}>
                <SelectTrigger><SelectValue placeholder="اختر المشروع" /></SelectTrigger>
                <SelectContent>
                  {projects.map((p) => (<SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="vehicle_id">السيارة *</Label>
              <Select value={formData.vehicle_id} onValueChange={(value) => setFormData({ ...formData, vehicle_id: value })}>
                <SelectTrigger><SelectValue placeholder="اختر السيارة" /></SelectTrigger>
                <SelectContent>
                  {vehicles.map((v) => (<SelectItem key={v.id} value={v.id}>{v.plate_number} - {v.make} {v.model}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="supplier_id">المورد *</Label>
              <Select value={formData.supplier_id} onValueChange={(value) => setFormData({ ...formData, supplier_id: value })}>
                <SelectTrigger><SelectValue placeholder="اختر المورد" /></SelectTrigger>
                <SelectContent>
                  {suppliers.map((s) => (<SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="billing_type">نوع الفوترة *</Label>
              <Select value={formData.billing_type} onValueChange={(value) => setFormData({ ...formData, billing_type: value })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">يومي</SelectItem>
                  <SelectItem value="monthly">شهري</SelectItem>
                  <SelectItem value="custom">مخصص</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="daily_rate">السعر اليومي *</Label>
              <Input id="daily_rate" type="number" step="0.01" value={formData.daily_rate} onChange={(e) => setFormData({ ...formData, daily_rate: e.target.value })} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="monthly_rate">السعر الشهري</Label>
              <Input id="monthly_rate" type="number" step="0.01" value={formData.monthly_rate} onChange={(e) => setFormData({ ...formData, monthly_rate: e.target.value })} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="start_date">تاريخ البدء *</Label>
              <Input id="start_date" type="date" value={formData.start_date} onChange={(e) => setFormData({ ...formData, start_date: e.target.value })} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="end_date">تاريخ الانتهاء</Label>
              <Input id="end_date" type="date" value={formData.end_date} onChange={(e) => setFormData({ ...formData, end_date: e.target.value })} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">الحالة</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">نشط</SelectItem>
                  <SelectItem value="completed">منتهي</SelectItem>
                  <SelectItem value="cancelled">ملغي</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="terms">الشروط</Label>
            <Textarea id="terms" value={formData.terms} onChange={(e) => setFormData({ ...formData, terms: e.target.value })} rows={2} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">ملاحظات</Label>
            <Textarea id="notes" value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} rows={2} />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
            <Button type="submit" disabled={isSubmitting}>{isSubmitting ? "جاري الحفظ..." : "حفظ"}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
