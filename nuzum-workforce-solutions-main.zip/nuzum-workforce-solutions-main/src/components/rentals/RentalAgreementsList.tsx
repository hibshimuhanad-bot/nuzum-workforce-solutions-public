import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Edit, Trash2, FileText } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";
import RentalAgreementDialog from "./RentalAgreementDialog";

export default function RentalAgreementsList() {
  const { organizationId } = useOrganization();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedAgreement, setSelectedAgreement] = useState<any>(null);

  const { data: agreements = [], isLoading } = useQuery({
    queryKey: ["rental_agreements", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vehicle_rental_agreements")
        .select(`
          *,
          project:fleet_projects(name),
          vehicle:vehicles(plate_number, make, model),
          supplier:suppliers(name)
        `)
        .eq("organization_id", organizationId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!organizationId,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("vehicle_rental_agreements")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["rental_agreements"] });
      toast.success("تم حذف الاتفاقية بنجاح");
    },
    onError: () => {
      toast.error("فشل حذف الاتفاقية");
    },
  });

  const handleDelete = async (id: string) => {
    if (confirm("هل أنت متأكد من حذف هذه الاتفاقية؟")) {
      deleteMutation.mutate(id);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive"; label: string }> = {
      active: { variant: "default", label: "نشط" },
      completed: { variant: "secondary", label: "منتهي" },
      cancelled: { variant: "destructive", label: "ملغي" },
    };
    const config = variants[status] || variants.active;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const stats = {
    total: agreements.length,
    active: agreements.filter((a) => a.status === "active").length,
    completed: agreements.filter((a) => a.status === "completed").length,
  };

  if (isLoading) {
    return <div className="p-8">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">اتفاقيات الإيجار</h1>
        <Button
          onClick={() => {
            setSelectedAgreement(null);
            setDialogOpen(true);
          }}
        >
          <Plus className="ml-2 h-4 w-4" />
          إضافة اتفاقية جديدة
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الاتفاقيات</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">النشطة</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.active}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">المنتهية</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.completed}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة الاتفاقيات</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>المشروع</TableHead>
                <TableHead>السيارة</TableHead>
                <TableHead>المورد</TableHead>
                <TableHead>السعر اليومي</TableHead>
                <TableHead>السعر الشهري</TableHead>
                <TableHead>نوع الفوترة</TableHead>
                <TableHead>تاريخ البدء</TableHead>
                <TableHead>تاريخ الانتهاء</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {agreements.map((agreement) => (
                <TableRow key={agreement.id}>
                  <TableCell className="font-medium">
                    {agreement.project?.name}
                  </TableCell>
                  <TableCell>
                    {agreement.vehicle?.plate_number} - {agreement.vehicle?.make}{" "}
                    {agreement.vehicle?.model}
                  </TableCell>
                  <TableCell>{agreement.supplier?.name}</TableCell>
                  <TableCell>
                    {Number(agreement.daily_rate).toLocaleString()} ريال
                  </TableCell>
                  <TableCell>
                    {agreement.monthly_rate
                      ? `${Number(agreement.monthly_rate).toLocaleString()} ريال`
                      : "-"}
                  </TableCell>
                  <TableCell>
                    {agreement.billing_type === "daily"
                      ? "يومي"
                      : agreement.billing_type === "monthly"
                      ? "شهري"
                      : "مخصص"}
                  </TableCell>
                  <TableCell>
                    {format(new Date(agreement.start_date), "dd/MM/yyyy", {
                      locale: ar,
                    })}
                  </TableCell>
                  <TableCell>
                    {agreement.end_date
                      ? format(new Date(agreement.end_date), "dd/MM/yyyy", {
                          locale: ar,
                        })
                      : "-"}
                  </TableCell>
                  <TableCell>{getStatusBadge(agreement.status)}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setSelectedAgreement(agreement);
                          setDialogOpen(true);
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(agreement.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {agreements.length === 0 && (
                <TableRow>
                  <TableCell colSpan={10} className="text-center text-muted-foreground">
                    لا توجد اتفاقيات إيجار مسجلة
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <RentalAgreementDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        agreement={selectedAgreement}
      />
    </div>
  );
}
