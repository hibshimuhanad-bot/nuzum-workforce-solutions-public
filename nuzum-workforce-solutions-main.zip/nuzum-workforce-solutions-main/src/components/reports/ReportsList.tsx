import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download } from "lucide-react";
import { toast } from "sonner";

export function ReportsList() {
  const reports = [
    { id: 1, name: "Monthly Payroll Report", type: "Payroll", date: "2024-01-31" },
    { id: 2, name: "Attendance Summary", type: "Attendance", date: "2024-01-31" },
    { id: 3, name: "Fleet Maintenance Report", type: "Fleet", date: "2024-01-31" },
    { id: 4, name: "Employee Performance", type: "HR", date: "2024-01-31" },
  ];

  const generateReport = (reportName: string) => {
    toast.success(`Generating ${reportName}...`);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Reports & Analytics
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          {reports.map((report) => (
            <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold">{report.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {report.type} • {new Date(report.date).toLocaleDateString()}
                </p>
              </div>
              <Button onClick={() => generateReport(report.name)}>
                <Download className="h-4 w-4 mr-2" />
                Generate
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
