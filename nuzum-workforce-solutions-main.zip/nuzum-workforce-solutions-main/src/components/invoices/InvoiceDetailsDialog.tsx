import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { CheckCircle, XCircle, Download, DollarSign } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

interface InvoiceDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  invoice: any;
}

export default function InvoiceDetailsDialog({ open, onOpenChange, invoice }: InvoiceDetailsDialogProps) {
  const queryClient = useQueryClient();
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");
  const [paymentData, setPaymentData] = useState({
    payment_date: "",
    payment_method: "",
    payment_reference: "",
    paid_amount: "",
  });

  const { data: lineItems = [] } = useQuery({
    queryKey: ["invoice_line_items", invoice?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("invoice_line_items")
        .select(`
          *,
          vehicle:vehicles(plate_number, make, model)
        `)
        .eq("invoice_id", invoice.id);

      if (error) throw error;
      return data || [];
    },
    enabled: !!invoice?.id,
  });

  const approveMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase
        .from("project_invoices")
        .update({
          status: "approved",
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
        })
        .eq("id", invoice.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["project_invoices"] });
      toast.success("تم الموافقة على الفاتورة");
      onOpenChange(false);
    },
    onError: () => {
      toast.error("فشل الموافقة على الفاتورة");
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (reason: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase
        .from("project_invoices")
        .update({
          status: "rejected",
          rejected_by: user?.id,
          rejected_at: new Date().toISOString(),
          rejection_reason: reason,
        })
        .eq("id", invoice.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["project_invoices"] });
      toast.success("تم رفض الفاتورة");
      setShowRejectDialog(false);
      onOpenChange(false);
    },
    onError: () => {
      toast.error("فشل رفض الفاتورة");
    },
  });

  const paymentMutation = useMutation({
    mutationFn: async (data: any) => {
      const { error } = await supabase
        .from("project_invoices")
        .update({
          status: "paid",
          payment_date: data.payment_date,
          payment_method: data.payment_method,
          payment_reference: data.payment_reference,
          paid_amount: parseFloat(data.paid_amount),
        })
        .eq("id", invoice.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["project_invoices"] });
      toast.success("تم تسجيل الدفع بنجاح");
      setShowPaymentDialog(false);
      onOpenChange(false);
    },
    onError: () => {
      toast.error("فشل تسجيل الدفع");
    },
  });

  const downloadInvoice = async () => {
    if (!invoice.invoice_file) {
      toast.error("لا يوجد ملف للفاتورة");
      return;
    }

    try {
      const { data, error } = await supabase.storage
        .from("project-invoices")
        .download(invoice.invoice_file);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = `invoice-${invoice.invoice_number}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      toast.error("فشل تحميل الملف");
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string }> = {
      draft: { variant: "outline", label: "مسودة" },
      pending: { variant: "secondary", label: "قيد المراجعة" },
      approved: { variant: "default", label: "موافق عليها" },
      rejected: { variant: "destructive", label: "مرفوضة" },
      paid: { variant: "default", label: "مدفوعة" },
      partially_paid: { variant: "secondary", label: "مدفوعة جزئياً" },
      overdue: { variant: "destructive", label: "متأخرة" },
    };
    const config = variants[status] || variants.pending;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  if (!invoice) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>تفاصيل الفاتورة #{invoice.invoice_number}</span>
            {getStatusBadge(invoice.status)}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>معلومات الفاتورة</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">المورد</p>
                <p className="font-medium">{invoice.supplier?.name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">المشروع</p>
                <p className="font-medium">{invoice.project?.name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">تاريخ الفاتورة</p>
                <p className="font-medium">
                  {format(new Date(invoice.invoice_date), "dd MMMM yyyy", { locale: ar })}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">تاريخ الاستحقاق</p>
                <p className="font-medium">
                  {format(new Date(invoice.due_date), "dd MMMM yyyy", { locale: ar })}
                </p>
              </div>
              {invoice.billing_period_start && (
                <div>
                  <p className="text-sm text-muted-foreground">فترة الفوترة</p>
                  <p className="font-medium">
                    {format(new Date(invoice.billing_period_start), "dd/MM/yyyy")} -{" "}
                    {format(new Date(invoice.billing_period_end), "dd/MM/yyyy")}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>بنود الفاتورة</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الوصف</TableHead>
                    <TableHead>السيارة</TableHead>
                    <TableHead>الفترة</TableHead>
                    <TableHead>الأيام</TableHead>
                    <TableHead>السعر</TableHead>
                    <TableHead>غرامة</TableHead>
                    <TableHead>الإجمالي</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {lineItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.description}</TableCell>
                      <TableCell>
                        {item.vehicle?.plate_number || "-"}
                      </TableCell>
                      <TableCell>
                        {format(new Date(item.start_date), "dd/MM")} -{" "}
                        {format(new Date(item.end_date), "dd/MM")}
                      </TableCell>
                      <TableCell>{item.days_count}</TableCell>
                      <TableCell>{Number(item.unit_price).toLocaleString()} ريال</TableCell>
                      <TableCell>
                        {item.penalty_amount > 0 ? (
                          <span className="text-destructive">
                            {Number(item.penalty_amount).toLocaleString()} ريال
                          </span>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell className="font-bold">
                        {Number(item.line_total).toLocaleString()} ريال
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>المجموع الفرعي:</span>
                  <span className="font-bold">{Number(invoice.subtotal).toLocaleString()} ريال</span>
                </div>
                {invoice.tax_amount > 0 && (
                  <div className="flex justify-between">
                    <span>ضريبة القيمة المضافة:</span>
                    <span>{Number(invoice.tax_amount).toLocaleString()} ريال</span>
                  </div>
                )}
                {invoice.discount_amount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>الخصم:</span>
                    <span>- {Number(invoice.discount_amount).toLocaleString()} ريال</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between text-xl font-bold">
                  <span>الإجمالي:</span>
                  <span>{Number(invoice.total_amount).toLocaleString()} ريال</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {invoice.notes && (
            <Card>
              <CardHeader>
                <CardTitle>ملاحظات</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{invoice.notes}</p>
              </CardContent>
            </Card>
          )}

          {invoice.rejection_reason && (
            <Card className="border-destructive">
              <CardHeader>
                <CardTitle className="text-destructive">سبب الرفض</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{invoice.rejection_reason}</p>
              </CardContent>
            </Card>
          )}

          <div className="flex gap-2 justify-end">
            {invoice.invoice_file && (
              <Button variant="outline" onClick={downloadInvoice}>
                <Download className="ml-2 h-4 w-4" />
                تحميل الفاتورة
              </Button>
            )}
            
            {invoice.status === "pending" && (
              <>
                <Button
                  variant="destructive"
                  onClick={() => setShowRejectDialog(true)}
                >
                  <XCircle className="ml-2 h-4 w-4" />
                  رفض
                </Button>
                <Button onClick={() => approveMutation.mutate()}>
                  <CheckCircle className="ml-2 h-4 w-4" />
                  موافقة
                </Button>
              </>
            )}

            {invoice.status === "approved" && (
              <Button onClick={() => setShowPaymentDialog(true)}>
                <DollarSign className="ml-2 h-4 w-4" />
                تسجيل الدفع
              </Button>
            )}
          </div>
        </div>

        {showRejectDialog && (
          <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>رفض الفاتورة</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="rejection_reason">سبب الرفض *</Label>
                  <Textarea
                    id="rejection_reason"
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    rows={4}
                    required
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
                    إلغاء
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => {
                      if (rejectionReason.trim()) {
                        rejectMutation.mutate(rejectionReason);
                      } else {
                        toast.error("الرجاء إدخال سبب الرفض");
                      }
                    }}
                  >
                    تأكيد الرفض
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {showPaymentDialog && (
          <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>تسجيل الدفع</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="payment_date">تاريخ الدفع *</Label>
                  <Input
                    id="payment_date"
                    type="date"
                    value={paymentData.payment_date}
                    onChange={(e) => setPaymentData({ ...paymentData, payment_date: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="payment_method">طريقة الدفع</Label>
                  <Input
                    id="payment_method"
                    value={paymentData.payment_method}
                    onChange={(e) => setPaymentData({ ...paymentData, payment_method: e.target.value })}
                    placeholder="مثال: تحويل بنكي، شيك، نقداً"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="payment_reference">رقم المرجع</Label>
                  <Input
                    id="payment_reference"
                    value={paymentData.payment_reference}
                    onChange={(e) => setPaymentData({ ...paymentData, payment_reference: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="paid_amount">المبلغ المدفوع *</Label>
                  <Input
                    id="paid_amount"
                    type="number"
                    step="0.01"
                    value={paymentData.paid_amount}
                    onChange={(e) => setPaymentData({ ...paymentData, paid_amount: e.target.value })}
                    required
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowPaymentDialog(false)}>
                    إلغاء
                  </Button>
                  <Button
                    onClick={() => {
                      if (paymentData.payment_date && paymentData.paid_amount) {
                        paymentMutation.mutate(paymentData);
                      } else {
                        toast.error("الرجاء إدخال التاريخ والمبلغ");
                      }
                    }}
                  >
                    تأكيد الدفع
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </DialogContent>
    </Dialog>
  );
}
