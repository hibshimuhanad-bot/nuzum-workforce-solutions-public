import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Eye, FileText, DollarSign, Clock, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";
import InvoiceUploadDialog from "./InvoiceUploadDialog";
import InvoiceDetailsDialog from "./InvoiceDetailsDialog";

export default function ProjectInvoicesList() {
  const { organizationId } = useOrganization();
  const queryClient = useQueryClient();
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);

  const { data: invoices = [], isLoading } = useQuery({
    queryKey: ["project_invoices", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("project_invoices")
        .select(`
          *,
          supplier:suppliers(name),
          project:fleet_projects(name)
        `)
        .eq("organization_id", organizationId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!organizationId,
  });

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string }> = {
      draft: { variant: "outline", label: "مسودة" },
      pending: { variant: "secondary", label: "قيد المراجعة" },
      approved: { variant: "default", label: "موافق عليها" },
      rejected: { variant: "destructive", label: "مرفوضة" },
      paid: { variant: "default", label: "مدفوعة" },
      partially_paid: { variant: "secondary", label: "مدفوعة جزئياً" },
      overdue: { variant: "destructive", label: "متأخرة" },
    };
    const config = variants[status] || variants.pending;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const filterInvoices = (status: string) => {
    if (status === "all") return invoices;
    return invoices.filter((inv) => inv.status === status);
  };

  const stats = {
    total: invoices.length,
    pending: invoices.filter((i) => i.status === "pending").length,
    approved: invoices.filter((i) => i.status === "approved").length,
    paid: invoices.filter((i) => i.status === "paid").length,
    totalAmount: invoices.reduce((sum, i) => sum + (Number(i.total_amount) || 0), 0),
    paidAmount: invoices.filter((i) => i.status === "paid").reduce((sum, i) => sum + (Number(i.paid_amount) || 0), 0),
  };

  const InvoicesTable = ({ invoices: data }: { invoices: any[] }) => (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>رقم الفاتورة</TableHead>
          <TableHead>المورد</TableHead>
          <TableHead>المشروع</TableHead>
          <TableHead>تاريخ الفاتورة</TableHead>
          <TableHead>تاريخ الاستحقاق</TableHead>
          <TableHead>المبلغ الإجمالي</TableHead>
          <TableHead>الحالة</TableHead>
          <TableHead>الإجراءات</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {data.map((invoice) => (
          <TableRow key={invoice.id}>
            <TableCell className="font-medium">{invoice.invoice_number}</TableCell>
            <TableCell>{invoice.supplier?.name || "-"}</TableCell>
            <TableCell>{invoice.project?.name || "-"}</TableCell>
            <TableCell>
              {format(new Date(invoice.invoice_date), "dd/MM/yyyy", { locale: ar })}
            </TableCell>
            <TableCell>
              {format(new Date(invoice.due_date), "dd/MM/yyyy", { locale: ar })}
            </TableCell>
            <TableCell className="font-bold">
              {Number(invoice.total_amount).toLocaleString()} ريال
            </TableCell>
            <TableCell>{getStatusBadge(invoice.status)}</TableCell>
            <TableCell>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setSelectedInvoice(invoice);
                  setDetailsDialogOpen(true);
                }}
              >
                <Eye className="h-4 w-4" />
              </Button>
            </TableCell>
          </TableRow>
        ))}
        {data.length === 0 && (
          <TableRow>
            <TableCell colSpan={8} className="text-center text-muted-foreground">
              لا توجد فواتير
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );

  if (isLoading) {
    return <div className="p-8">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">إدارة الفواتير</h1>
        <Button onClick={() => setUploadDialogOpen(true)}>
          <Plus className="ml-2 h-4 w-4" />
          إضافة فاتورة جديدة
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الفواتير</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">قيد المراجعة</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pending}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">المدفوعة</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.paid}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المبالغ</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalAmount.toLocaleString()} ريال</div>
            <p className="text-xs text-muted-foreground mt-1">
              مدفوع: {stats.paidAmount.toLocaleString()} ريال
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>الفواتير</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">الكل ({stats.total})</TabsTrigger>
              <TabsTrigger value="pending">قيد المراجعة ({stats.pending})</TabsTrigger>
              <TabsTrigger value="approved">موافق عليها ({stats.approved})</TabsTrigger>
              <TabsTrigger value="paid">مدفوعة ({stats.paid})</TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <InvoicesTable invoices={filterInvoices("all")} />
            </TabsContent>

            <TabsContent value="pending">
              <InvoicesTable invoices={filterInvoices("pending")} />
            </TabsContent>

            <TabsContent value="approved">
              <InvoicesTable invoices={filterInvoices("approved")} />
            </TabsContent>

            <TabsContent value="paid">
              <InvoicesTable invoices={filterInvoices("paid")} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <InvoiceUploadDialog
        open={uploadDialogOpen}
        onOpenChange={setUploadDialogOpen}
      />

      {selectedInvoice && (
        <InvoiceDetailsDialog
          open={detailsDialogOpen}
          onOpenChange={setDetailsDialogOpen}
          invoice={selectedInvoice}
        />
      )}
    </div>
  );
}
