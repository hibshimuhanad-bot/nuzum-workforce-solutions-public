import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, Upload } from "lucide-react";
import { differenceInDays } from "date-fns";
import { toast } from "sonner";

interface InvoiceUploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function InvoiceUploadDialog({ open, onOpenChange }: InvoiceUploadDialogProps) {
  const { organizationId } = useOrganization();
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    invoice_number: "",
    invoice_date: "",
    due_date: "",
    supplier_id: "",
    project_id: "",
    invoice_type: "on_demand",
    billing_period_start: "",
    billing_period_end: "",
    tax_amount: "",
    discount_amount: "",
    notes: "",
  });
  const [lineItems, setLineItems] = useState<any[]>([]);

  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("suppliers")
        .select("*")
        .eq("organization_id", organizationId)
        .eq("status", "active");
      if (error) throw error;
      return data || [];
    },
    enabled: !!organizationId,
  });

  const { data: projects = [] } = useQuery({
    queryKey: ["fleet_projects", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("fleet_projects")
        .select("*")
        .eq("organization_id", organizationId);
      if (error) throw error;
      return data || [];
    },
    enabled: !!organizationId,
  });

  const { data: rentalAgreements = [] } = useQuery({
    queryKey: ["rental_agreements", formData.project_id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vehicle_rental_agreements")
        .select(`
          *,
          vehicle:vehicles(plate_number, make, model)
        `)
        .eq("project_id", formData.project_id)
        .eq("status", "active");
      if (error) throw error;
      return data || [];
    },
    enabled: !!formData.project_id,
  });

  const addLineItem = () => {
    setLineItems([
      ...lineItems,
      {
        rental_agreement_id: "",
        description: "",
        start_date: "",
        end_date: "",
        days_count: 0,
        unit_price: "",
        penalty_amount: "",
        penalty_reason: "",
        line_total: 0,
      },
    ]);
  };

  const removeLineItem = (index: number) => {
    setLineItems(lineItems.filter((_, i) => i !== index));
  };

  const updateLineItem = (index: number, field: string, value: any) => {
    const updated = [...lineItems];
    updated[index] = { ...updated[index], [field]: value };

    // Auto-calculate days and total
    if (field === "start_date" || field === "end_date") {
      const start = updated[index].start_date;
      const end = updated[index].end_date;
      if (start && end) {
        updated[index].days_count = differenceInDays(new Date(end), new Date(start)) + 1;
      }
    }

    if (field === "rental_agreement_id") {
      const agreement = rentalAgreements.find((a) => a.id === value);
      if (agreement) {
        updated[index].unit_price = agreement.daily_rate;
        updated[index].description = `إيجار ${agreement.vehicle?.plate_number} - ${agreement.vehicle?.make} ${agreement.vehicle?.model}`;
      }
    }

    const days = updated[index].days_count || 0;
    const price = parseFloat(updated[index].unit_price) || 0;
    const penalty = parseFloat(updated[index].penalty_amount) || 0;
    updated[index].line_total = (days * price) + penalty;

    setLineItems(updated);
  };

  const calculateTotals = () => {
    const subtotal = lineItems.reduce((sum, item) => sum + (item.line_total || 0), 0);
    const tax = parseFloat(formData.tax_amount) || 0;
    const discount = parseFloat(formData.discount_amount) || 0;
    const total = subtotal + tax - discount;
    return { subtotal, total };
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.invoice_number || !formData.supplier_id || !formData.project_id) {
      toast.error("الرجاء إدخال جميع الحقول المطلوبة");
      return;
    }

    if (lineItems.length === 0) {
      toast.error("الرجاء إضافة بند واحد على الأقل");
      return;
    }

    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      let invoiceFilePath = null;

      // Upload file if exists
      if (file) {
        const fileExt = file.name.split(".").pop();
        const fileName = `${organizationId}/${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from("project-invoices")
          .upload(fileName, file);

        if (uploadError) throw uploadError;
        invoiceFilePath = fileName;
      }

      const { subtotal, total } = calculateTotals();

      // Insert invoice
      const { data: invoice, error: invoiceError } = await supabase
        .from("project_invoices")
        .insert([
          {
            organization_id: organizationId,
            user_id: user.id,
            invoice_number: formData.invoice_number,
            invoice_date: formData.invoice_date,
            due_date: formData.due_date,
            supplier_id: formData.supplier_id,
            project_id: formData.project_id,
            invoice_type: formData.invoice_type,
            billing_period_start: formData.billing_period_start || null,
            billing_period_end: formData.billing_period_end || null,
            subtotal: subtotal,
            tax_amount: parseFloat(formData.tax_amount) || 0,
            discount_amount: parseFloat(formData.discount_amount) || 0,
            total_amount: total,
            invoice_file: invoiceFilePath,
            notes: formData.notes,
          },
        ])
        .select()
        .single();

      if (invoiceError) throw invoiceError;

      // Insert line items
      const lineItemsData = lineItems.map((item) => ({
        organization_id: organizationId,
        invoice_id: invoice.id,
        vehicle_id: rentalAgreements.find((a) => a.id === item.rental_agreement_id)?.vehicle_id,
        rental_agreement_id: item.rental_agreement_id,
        description: item.description,
        start_date: item.start_date,
        end_date: item.end_date,
        days_count: item.days_count,
        unit_price: parseFloat(item.unit_price),
        penalty_amount: parseFloat(item.penalty_amount) || 0,
        penalty_reason: item.penalty_reason,
        line_total: item.line_total,
      }));

      const { error: itemsError } = await supabase
        .from("invoice_line_items")
        .insert(lineItemsData);

      if (itemsError) throw itemsError;

      queryClient.invalidateQueries({ queryKey: ["project_invoices"] });
      toast.success("تم إضافة الفاتورة بنجاح");
      onOpenChange(false);
    } catch (error: any) {
      toast.error("فشل حفظ الفاتورة: " + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const { subtotal, total } = calculateTotals();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>إضافة فاتورة جديدة</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="invoice_number">رقم الفاتورة *</Label>
                  <Input
                    id="invoice_number"
                    value={formData.invoice_number}
                    onChange={(e) => setFormData({ ...formData, invoice_number: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="supplier_id">المورد *</Label>
                  <Select
                    value={formData.supplier_id}
                    onValueChange={(value) => setFormData({ ...formData, supplier_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر المورد" />
                    </SelectTrigger>
                    <SelectContent>
                      {suppliers.map((supplier) => (
                        <SelectItem key={supplier.id} value={supplier.id}>
                          {supplier.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="project_id">المشروع *</Label>
                  <Select
                    value={formData.project_id}
                    onValueChange={(value) => setFormData({ ...formData, project_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر المشروع" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="invoice_type">نوع الفاتورة</Label>
                  <Select
                    value={formData.invoice_type}
                    onValueChange={(value) => setFormData({ ...formData, invoice_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="single_vehicle">سيارة واحدة</SelectItem>
                      <SelectItem value="multiple_vehicles">عدة سيارات</SelectItem>
                      <SelectItem value="monthly">شهرية</SelectItem>
                      <SelectItem value="on_demand">حسب الطلب</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="invoice_date">تاريخ الفاتورة *</Label>
                  <Input
                    id="invoice_date"
                    type="date"
                    value={formData.invoice_date}
                    onChange={(e) => setFormData({ ...formData, invoice_date: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="due_date">تاريخ الاستحقاق *</Label>
                  <Input
                    id="due_date"
                    type="date"
                    value={formData.due_date}
                    onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="file">ملف الفاتورة</Label>
                  <Input
                    id="file"
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={handleFileChange}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">بنود الفاتورة</h3>
                <Button type="button" onClick={addLineItem} size="sm">
                  <Plus className="ml-2 h-4 w-4" />
                  إضافة بند
                </Button>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>السيارة</TableHead>
                    <TableHead>من تاريخ</TableHead>
                    <TableHead>إلى تاريخ</TableHead>
                    <TableHead>الأيام</TableHead>
                    <TableHead>السعر</TableHead>
                    <TableHead>غرامة</TableHead>
                    <TableHead>الإجمالي</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {lineItems.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <Select
                          value={item.rental_agreement_id}
                          onValueChange={(value) => updateLineItem(index, "rental_agreement_id", value)}
                        >
                          <SelectTrigger className="w-[200px]">
                            <SelectValue placeholder="اختر السيارة" />
                          </SelectTrigger>
                          <SelectContent>
                            {rentalAgreements.map((agreement) => (
                              <SelectItem key={agreement.id} value={agreement.id}>
                                {agreement.vehicle?.plate_number}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Input
                          type="date"
                          value={item.start_date}
                          onChange={(e) => updateLineItem(index, "start_date", e.target.value)}
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="date"
                          value={item.end_date}
                          onChange={(e) => updateLineItem(index, "end_date", e.target.value)}
                        />
                      </TableCell>
                      <TableCell>{item.days_count}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={item.unit_price}
                          onChange={(e) => updateLineItem(index, "unit_price", e.target.value)}
                          className="w-24"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={item.penalty_amount}
                          onChange={(e) => updateLineItem(index, "penalty_amount", e.target.value)}
                          className="w-24"
                        />
                      </TableCell>
                      <TableCell className="font-bold">
                        {item.line_total.toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeLineItem(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tax_amount">ضريبة القيمة المضافة</Label>
                  <Input
                    id="tax_amount"
                    type="number"
                    step="0.01"
                    value={formData.tax_amount}
                    onChange={(e) => setFormData({ ...formData, tax_amount: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="discount_amount">الخصم</Label>
                  <Input
                    id="discount_amount"
                    type="number"
                    step="0.01"
                    value={formData.discount_amount}
                    onChange={(e) => setFormData({ ...formData, discount_amount: e.target.value })}
                  />
                </div>
              </div>

              <div className="mt-4 space-y-2 border-t pt-4">
                <div className="flex justify-between text-lg">
                  <span>المجموع الفرعي:</span>
                  <span className="font-bold">{subtotal.toLocaleString()} ريال</span>
                </div>
                <div className="flex justify-between text-xl font-bold">
                  <span>الإجمالي:</span>
                  <span>{total.toLocaleString()} ريال</span>
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <Label htmlFor="notes">ملاحظات</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              إلغاء
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "جاري الحفظ..." : "حفظ الفاتورة"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
