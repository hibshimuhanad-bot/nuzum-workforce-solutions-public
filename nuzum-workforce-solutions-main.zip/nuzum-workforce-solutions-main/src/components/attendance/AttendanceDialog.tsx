import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

interface AttendanceDialogProps {
  isOpen: boolean;
  onClose: () => void;
  attendance: any;
  onSuccess: () => void;
}

export default function AttendanceDialog({
  isOpen,
  onClose,
  attendance,
  onSuccess,
}: AttendanceDialogProps) {
  const [formData, setFormData] = useState({
    employee_id: "",
    check_in: "",
    check_out: "",
    work_hours: "",
    overtime_hours: "",
    notes: "",
  });

  const { data: employees } = useQuery({
    queryKey: ["employees-dropdown"],
    queryFn: async () => {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return [];

      const { data, error } = await supabase
        .from("employees")
        .select("id, name, position")
        .eq("user_id", session.session.user.id)
        .eq("status", "active")
        .order("name");

      if (error) throw error;
      return data || [];
    },
  });

  useEffect(() => {
    if (attendance) {
      setFormData({
        employee_id: attendance.employee_id,
        check_in: attendance.check_in.slice(0, 16),
        check_out: attendance.check_out ? attendance.check_out.slice(0, 16) : "",
        work_hours: attendance.work_hours?.toString() || "",
        overtime_hours: attendance.overtime_hours?.toString() || "",
        notes: attendance.notes || "",
      });
    } else {
      const now = new Date();
      setFormData({
        employee_id: "",
        check_in: now.toISOString().slice(0, 16),
        check_out: "",
        work_hours: "",
        overtime_hours: "",
        notes: "",
      });
    }
  }, [attendance]);

  const calculateWorkHours = () => {
    if (!formData.check_in || !formData.check_out) return;

    const checkIn = new Date(formData.check_in);
    const checkOut = new Date(formData.check_out);
    const diff = (checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60);
    
    const workHours = Math.max(0, diff);
    const overtimeHours = Math.max(0, workHours - 8);

    setFormData({
      ...formData,
      work_hours: workHours.toFixed(2),
      overtime_hours: overtimeHours.toFixed(2),
    });
  };

  useEffect(() => {
    if (formData.check_in && formData.check_out) {
      calculateWorkHours();
    }
  }, [formData.check_in, formData.check_out]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: session } = await supabase.auth.getSession();
    if (!session?.session?.user?.id) return;

    const payload = {
      employee_id: formData.employee_id,
      check_in: new Date(formData.check_in).toISOString(),
      check_out: formData.check_out ? new Date(formData.check_out).toISOString() : null,
      work_hours: formData.work_hours ? parseFloat(formData.work_hours) : null,
      overtime_hours: formData.overtime_hours ? parseFloat(formData.overtime_hours) : 0,
      notes: formData.notes,
      user_id: session.session.user.id,
    };

    if (attendance) {
      const { error } = await supabase
        .from("attendance_records")
        .update(payload)
        .eq("id", attendance.id);

      if (!error) {
        onSuccess();
        onClose();
      }
    } else {
      const { error } = await supabase
        .from("attendance_records")
        .insert([payload]);

      if (!error) {
        onSuccess();
        onClose();
      }
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {attendance ? "Edit Attendance" : "Add Attendance"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="employee">Employee *</Label>
            <Select
              value={formData.employee_id}
              onValueChange={(value) =>
                setFormData({ ...formData, employee_id: value })
              }
              disabled={!!attendance}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select employee" />
              </SelectTrigger>
              <SelectContent>
                {employees?.map((emp: any) => (
                  <SelectItem key={emp.id} value={emp.id}>
                    {emp.name} - {emp.position}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="check_in">Check In *</Label>
              <Input
                type="datetime-local"
                value={formData.check_in}
                onChange={(e) =>
                  setFormData({ ...formData, check_in: e.target.value })
                }
                required
              />
            </div>

            <div>
              <Label htmlFor="check_out">Check Out</Label>
              <Input
                type="datetime-local"
                value={formData.check_out}
                onChange={(e) =>
                  setFormData({ ...formData, check_out: e.target.value })
                }
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="work_hours">Work Hours</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.work_hours}
                onChange={(e) =>
                  setFormData({ ...formData, work_hours: e.target.value })
                }
                readOnly
              />
            </div>

            <div>
              <Label htmlFor="overtime_hours">Overtime Hours</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.overtime_hours}
                onChange={(e) =>
                  setFormData({ ...formData, overtime_hours: e.target.value })
                }
                readOnly
              />
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              {attendance ? "Update" : "Add"} Attendance
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
