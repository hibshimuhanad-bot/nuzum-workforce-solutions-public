import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Clock, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import AttendanceDialog from "./AttendanceDialog";

export default function AttendanceList() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedAttendance, setSelectedAttendance] = useState(null);
  const { toast } = useToast();

  const { data: attendanceRecords, isLoading, refetch } = useQuery({
    queryKey: ["attendance-records"],
    queryFn: async () => {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return [];

      const { data, error } = await supabase
        .from("attendance_records")
        .select(`
          *,
          employees (name, email, position)
        `)
        .eq("user_id", session.session.user.id)
        .order("check_in", { ascending: false })
        .limit(100);

      if (error) throw error;
      return data || [];
    },
  });

  const handleEdit = (attendance: any) => {
    setSelectedAttendance(attendance);
    setIsDialogOpen(true);
  };

  const handleAdd = () => {
    setSelectedAttendance(null);
    setIsDialogOpen(true);
  };

  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Attendance Tracking</h2>
          <p className="text-muted-foreground">Track employee attendance and work hours</p>
        </div>
        <Button onClick={handleAdd}>
          <Plus className="mr-2 h-4 w-4" />
          Add Attendance
        </Button>
      </div>

      <Card className="p-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Employee</TableHead>
              <TableHead>
                <Calendar className="inline mr-2 h-4 w-4" />
                Date
              </TableHead>
              <TableHead>
                <Clock className="inline mr-2 h-4 w-4" />
                Check In
              </TableHead>
              <TableHead>Check Out</TableHead>
              <TableHead>Work Hours</TableHead>
              <TableHead>Overtime</TableHead>
              <TableHead>Notes</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {attendanceRecords?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                  No attendance records found. Click "Add Attendance" to create one.
                </TableCell>
              </TableRow>
            ) : (
              attendanceRecords?.map((attendance: any) => (
                <TableRow key={attendance.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{attendance.employees.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {attendance.employees.position}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{formatDate(attendance.check_in)}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{formatTime(attendance.check_in)}</Badge>
                  </TableCell>
                  <TableCell>
                    {attendance.check_out ? (
                      <Badge variant="outline">{formatTime(attendance.check_out)}</Badge>
                    ) : (
                      <Badge variant="secondary">In Progress</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {attendance.work_hours ? `${attendance.work_hours}h` : "-"}
                  </TableCell>
                  <TableCell>
                    {attendance.overtime_hours > 0 ? (
                      <Badge variant="default">{attendance.overtime_hours}h</Badge>
                    ) : (
                      "-"
                    )}
                  </TableCell>
                  <TableCell className="max-w-xs truncate">
                    {attendance.notes || "-"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(attendance)}
                    >
                      Edit
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      <AttendanceDialog
        isOpen={isDialogOpen}
        onClose={() => {
          setIsDialogOpen(false);
          setSelectedAttendance(null);
        }}
        attendance={selectedAttendance}
        onSuccess={() => {
          refetch();
          toast({
            title: "Success",
            description: "Attendance record saved successfully",
          });
        }}
      />
    </div>
  );
}
