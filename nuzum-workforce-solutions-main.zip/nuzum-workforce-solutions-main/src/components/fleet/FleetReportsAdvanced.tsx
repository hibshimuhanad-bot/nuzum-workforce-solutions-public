import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { Download, FileSpreadsheet } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import * as XLSX from "xlsx";

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"];

export const FleetReportsAdvanced = () => {
  const { toast } = useToast();
  const [reportType, setReportType] = useState("maintenance_costs");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  const { data: maintenanceData } = useQuery({
    queryKey: ["maintenance_report", dateFrom, dateTo],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      let query = supabase
        .from("vehicle_maintenance")
        .select("*, vehicles(plate_number, make, model)")
        .eq("user_id", user.id);

      if (dateFrom) query = query.gte("maintenance_date", dateFrom);
      if (dateTo) query = query.lte("maintenance_date", dateTo);

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  const { data: fuelData } = useQuery({
    queryKey: ["fuel_report", dateFrom, dateTo],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      let query = supabase
        .from("fuel_logs")
        .select("*, vehicles(plate_number, make, model)")
        .eq("user_id", user.id);

      if (dateFrom) query = query.gte("fuel_date", dateFrom);
      if (dateTo) query = query.lte("fuel_date", dateTo);

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  const { data: assignmentsData } = useQuery({
    queryKey: ["assignments_report", dateFrom, dateTo],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      let query = supabase
        .from("vehicle_assignments")
        .select("*, vehicles(plate_number, make, model), employees(name)")
        .eq("user_id", user.id);

      if (dateFrom) query = query.gte("assigned_date", dateFrom);
      if (dateTo) query = query.lte("assigned_date", dateTo);

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  const getMaintenanceCostsByVehicle = () => {
    if (!maintenanceData) return [];
    
    const costsByVehicle = maintenanceData.reduce((acc: any, item: any) => {
      const vehicleKey = `${item.vehicles.plate_number} - ${item.vehicles.make} ${item.vehicles.model}`;
      if (!acc[vehicleKey]) {
        acc[vehicleKey] = 0;
      }
      acc[vehicleKey] += parseFloat(item.cost || 0);
      return acc;
    }, {});

    return Object.entries(costsByVehicle).map(([vehicle, cost]) => ({
      vehicle,
      cost: parseFloat(cost as string).toFixed(2),
    }));
  };

  const getFuelCostsByVehicle = () => {
    if (!fuelData) return [];
    
    const costsByVehicle = fuelData.reduce((acc: any, item: any) => {
      const vehicleKey = `${item.vehicles.plate_number}`;
      if (!acc[vehicleKey]) {
        acc[vehicleKey] = { cost: 0, liters: 0 };
      }
      acc[vehicleKey].cost += parseFloat(item.cost || 0);
      acc[vehicleKey].liters += parseFloat(item.liters || 0);
      return acc;
    }, {});

    return Object.entries(costsByVehicle).map(([vehicle, data]: [string, any]) => ({
      vehicle,
      cost: data.cost.toFixed(2),
      liters: data.liters.toFixed(2),
      avgCostPerLiter: (data.cost / data.liters).toFixed(2),
    }));
  };

  const getMaintenanceByCategory = () => {
    if (!maintenanceData) return [];
    
    const categories = maintenanceData.reduce((acc: any, item: any) => {
      const category = item.maintenance_category || "other";
      if (!acc[category]) {
        acc[category] = { count: 0, cost: 0 };
      }
      acc[category].count += 1;
      acc[category].cost += parseFloat(item.cost || 0);
      return acc;
    }, {});

    return Object.entries(categories).map(([name, data]: [string, any]) => ({
      name: name === "preventive" ? "وقائية" : name === "corrective" ? "إصلاحية" : "طارئة",
      count: data.count,
      cost: data.cost.toFixed(2),
    }));
  };

  const exportToExcel = () => {
    const wb = XLSX.utils.book_new();

    // Maintenance costs sheet
    if (maintenanceData && maintenanceData.length > 0) {
      const maintenanceSheet = maintenanceData.map((item: any) => ({
        "المركبة": `${item.vehicles.plate_number} - ${item.vehicles.make} ${item.vehicles.model}`,
        "نوع الصيانة": item.maintenance_type,
        "التصنيف": item.maintenance_category,
        "التاريخ": item.maintenance_date,
        "التكلفة": item.cost,
        "الحالة": item.status,
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(maintenanceSheet), "الصيانة");
    }

    // Fuel costs sheet
    if (fuelData && fuelData.length > 0) {
      const fuelSheet = fuelData.map((item: any) => ({
        "المركبة": item.vehicles.plate_number,
        "التاريخ": item.fuel_date,
        "اللترات": item.liters,
        "التكلفة": item.cost,
        "المحطة": item.station_name,
        "قراءة العداد": item.mileage,
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(fuelSheet), "الوقود");
    }

    // Assignments sheet
    if (assignmentsData && assignmentsData.length > 0) {
      const assignmentsSheet = assignmentsData.map((item: any) => ({
        "المركبة": `${item.vehicles.plate_number}`,
        "الموظف": item.employees.name,
        "تاريخ التسليم": item.assigned_date,
        "تاريخ الاستلام": item.return_date || "مستمر",
        "الحالة": item.status,
        "ملاحظات": item.notes,
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(assignmentsSheet), "التكليفات");
    }

    XLSX.writeFile(wb, `fleet_report_${new Date().toISOString().split('T')[0]}.xlsx`);

    toast({
      title: "نجح",
      description: "تم تصدير التقرير بنجاح",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">التقارير المتقدمة</h2>
        <Button onClick={exportToExcel}>
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          تصدير Excel
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>خيارات التقرير</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>نوع التقرير</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="maintenance_costs">تكاليف الصيانة</SelectItem>
                  <SelectItem value="fuel_costs">تكاليف الوقود</SelectItem>
                  <SelectItem value="maintenance_category">الصيانة حسب التصنيف</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>من تاريخ</Label>
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>إلى تاريخ</Label>
              <Input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {reportType === "maintenance_costs" && (
        <Card>
          <CardHeader>
            <CardTitle>تكاليف الصيانة حسب المركبة</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={getMaintenanceCostsByVehicle()}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="vehicle" angle={-45} textAnchor="end" height={100} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="cost" fill="#8884d8" name="التكلفة (ر.س)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {reportType === "fuel_costs" && (
        <Card>
          <CardHeader>
            <CardTitle>تكاليف الوقود حسب المركبة</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={getFuelCostsByVehicle()}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="vehicle" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="cost" fill="#82ca9d" name="التكلفة (ر.س)" />
                <Bar dataKey="liters" fill="#8884d8" name="اللترات" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {reportType === "maintenance_category" && (
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>الصيانة حسب التصنيف - العدد</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={getMaintenanceByCategory()}
                    dataKey="count"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label
                  >
                    {getMaintenanceByCategory().map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>الصيانة حسب التصنيف - التكلفة</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={getMaintenanceByCategory()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="cost" fill="#8884d8" name="التكلفة (ر.س)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};
