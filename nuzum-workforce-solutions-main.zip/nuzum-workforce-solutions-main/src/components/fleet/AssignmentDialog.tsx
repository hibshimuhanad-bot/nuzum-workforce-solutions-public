import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";

interface AssignmentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  assignment: any | null;
  onSuccess: () => void;
}

export const AssignmentDialog = ({ isOpen, onClose, assignment, onSuccess }: AssignmentDialogProps) => {
  const [formData, setFormData] = useState({
    vehicle_id: "",
    employee_id: "",
    assigned_date: new Date().toISOString().split('T')[0],
    return_date: "",
    notes: ""
  });

  const [vehicles, setVehicles] = useState<any[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);

  useEffect(() => {
    fetchVehicles();
    fetchEmployees();
  }, []);

  useEffect(() => {
    if (assignment) {
      setFormData({
        vehicle_id: assignment.vehicle_id || "",
        employee_id: assignment.employee_id || "",
        assigned_date: assignment.assigned_date?.split('T')[0] || new Date().toISOString().split('T')[0],
        return_date: assignment.return_date?.split('T')[0] || "",
        notes: assignment.notes || ""
      });
    } else {
      setFormData({
        vehicle_id: "",
        employee_id: "",
        assigned_date: new Date().toISOString().split('T')[0],
        return_date: "",
        notes: ""
      });
    }
  }, [assignment]);

  const fetchVehicles = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("vehicles")
      .select("*")
      .eq("user_id", user.id)
      .eq("status", "active")
      .order("plate_number");

    setVehicles(data || []);
  };

  const fetchEmployees = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("employees")
      .select("*")
      .eq("user_id", user.id)
      .eq("status", "active")
      .order("name");

    setEmployees(data || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: profile } = await supabase
      .from("profiles")
      .select("organization_id")
      .eq("id", user.id)
      .single();

    const payload = {
      vehicle_id: formData.vehicle_id,
      employee_id: formData.employee_id,
      assigned_date: formData.assigned_date,
      return_date: formData.return_date || null,
      notes: formData.notes || null,
      user_id: user.id,
      organization_id: profile?.organization_id
    };

    if (assignment) {
      await supabase
        .from("vehicle_assignments")
        .update(payload)
        .eq("id", assignment.id);
    } else {
      await supabase
        .from("vehicle_assignments")
        .insert(payload);
    }

    onSuccess();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{assignment ? "Edit Vehicle Assignment" : "Assign Vehicle"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="vehicle_id">Vehicle *</Label>
            <Select
              value={formData.vehicle_id}
              onValueChange={(value) => setFormData({ ...formData, vehicle_id: value })}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select vehicle" />
              </SelectTrigger>
              <SelectContent>
                {vehicles.map((vehicle) => (
                  <SelectItem key={vehicle.id} value={vehicle.id}>
                    {vehicle.plate_number} - {vehicle.make} {vehicle.model}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="employee_id">Employee *</Label>
            <Select
              value={formData.employee_id}
              onValueChange={(value) => setFormData({ ...formData, employee_id: value })}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select employee" />
              </SelectTrigger>
              <SelectContent>
                {employees.map((employee) => (
                  <SelectItem key={employee.id} value={employee.id}>
                    {employee.name} - {employee.position}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="assigned_date">Assigned Date *</Label>
              <Input
                id="assigned_date"
                type="date"
                value={formData.assigned_date}
                onChange={(e) => setFormData({ ...formData, assigned_date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="return_date">Return Date</Label>
              <Input
                id="return_date"
                type="date"
                value={formData.return_date}
                onChange={(e) => setFormData({ ...formData, return_date: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Additional notes about this assignment..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              {assignment ? "Update" : "Assign"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};