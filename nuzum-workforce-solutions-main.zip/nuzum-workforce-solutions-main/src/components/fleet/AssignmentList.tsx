import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AssignmentDialog } from "./AssignmentDialog";
import { Plus, UserCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export const AssignmentList = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<any>(null);
  const { toast } = useToast();

  const { data: assignments, isLoading, refetch } = useQuery({
    queryKey: ["vehicle_assignments"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from("vehicle_assignments")
        .select(`
          *,
          vehicles (
            plate_number,
            make,
            model
          ),
          employees (
            name,
            position
          )
        `)
        .eq("user_id", user.id)
        .order("assigned_date", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const handleEdit = (assignment: any) => {
    setSelectedAssignment(assignment);
    setIsDialogOpen(true);
  };

  const handleAdd = () => {
    setSelectedAssignment(null);
    setIsDialogOpen(true);
  };

  if (isLoading) {
    return <div>Loading vehicle assignments...</div>;
  }

  const activeAssignments = assignments?.filter(a => !a.return_date) || [];
  const completedAssignments = assignments?.filter(a => a.return_date) || [];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <UserCheck className="h-6 w-6" />
            Vehicle Assignments
          </h2>
          <p className="text-muted-foreground">Manage vehicle assignments to employees</p>
        </div>
        <Button onClick={handleAdd}>
          <Plus className="mr-2 h-4 w-4" />
          New Assignment
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Total Assignments</div>
          <div className="text-2xl font-bold">{assignments?.length || 0}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Active</div>
          <div className="text-2xl font-bold text-green-600">{activeAssignments.length}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Completed</div>
          <div className="text-2xl font-bold">{completedAssignments.length}</div>
        </Card>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Vehicle</TableHead>
              <TableHead>Employee</TableHead>
              <TableHead>Assigned Date</TableHead>
              <TableHead>Return Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Notes</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assignments && assignments.length > 0 ? (
              assignments.map((assignment) => (
                <TableRow key={assignment.id}>
                  <TableCell>
                    {assignment.vehicles?.plate_number}<br />
                    <span className="text-sm text-muted-foreground">
                      {assignment.vehicles?.make} {assignment.vehicles?.model}
                    </span>
                  </TableCell>
                  <TableCell>
                    {assignment.employees?.name}<br />
                    <span className="text-sm text-muted-foreground">
                      {assignment.employees?.position}
                    </span>
                  </TableCell>
                  <TableCell>{format(new Date(assignment.assigned_date), "MMM dd, yyyy")}</TableCell>
                  <TableCell>
                    {assignment.return_date 
                      ? format(new Date(assignment.return_date), "MMM dd, yyyy")
                      : '-'}
                  </TableCell>
                  <TableCell>
                    <Badge variant={assignment.return_date ? "secondary" : "default"}>
                      {assignment.return_date ? "Returned" : "Active"}
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-xs truncate">{assignment.notes || '-'}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => handleEdit(assignment)}>
                      Edit
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground">
                  No vehicle assignments found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>

      <AssignmentDialog
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        assignment={selectedAssignment}
        onSuccess={() => {
          refetch();
          toast({
            title: "Success",
            description: "Vehicle assignment saved successfully",
          });
        }}
      />
    </div>
  );
};