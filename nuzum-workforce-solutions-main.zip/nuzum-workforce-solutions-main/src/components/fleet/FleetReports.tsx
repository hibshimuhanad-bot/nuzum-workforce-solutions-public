import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileText, Download } from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths } from "date-fns";

export const FleetReports = () => {
  const [reportType, setReportType] = useState<string>("monthly-costs");
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toISOString().split('T')[0].substring(0, 7));

  const { data: vehicles } = useQuery({
    queryKey: ["vehicles_reports"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("vehicles")
        .select("*")
        .eq("user_id", user.id);

      return data || [];
    },
  });

  const { data: maintenanceRecords } = useQuery({
    queryKey: ["maintenance_reports", selectedMonth],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const monthStart = startOfMonth(new Date(selectedMonth));
      const monthEnd = endOfMonth(new Date(selectedMonth));

      const { data } = await supabase
        .from("vehicle_maintenance")
        .select(`
          *,
          vehicles (
            plate_number,
            make,
            model
          )
        `)
        .eq("user_id", user.id)
        .gte("maintenance_date", monthStart.toISOString())
        .lte("maintenance_date", monthEnd.toISOString());

      return data || [];
    },
  });

  const { data: fuelLogs } = useQuery({
    queryKey: ["fuel_reports", selectedMonth],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const monthStart = startOfMonth(new Date(selectedMonth));
      const monthEnd = endOfMonth(new Date(selectedMonth));

      const { data } = await supabase
        .from("fuel_logs")
        .select(`
          *,
          vehicles (
            plate_number,
            make,
            model
          )
        `)
        .eq("user_id", user.id)
        .gte("fuel_date", monthStart.toISOString())
        .lte("fuel_date", monthEnd.toISOString());

      return data || [];
    },
  });

  const generateMonthlyReport = (): Array<{vehicle: any, maintenance: number, fuel: number, total: number}> => {
    const vehicleCosts: Record<string, {vehicle: any, maintenance: number, fuel: number, total: number}> = {};

    vehicles?.forEach(vehicle => {
      vehicleCosts[vehicle.id] = {
        vehicle,
        maintenance: 0,
        fuel: 0,
        total: 0
      };
    });

    maintenanceRecords?.forEach(record => {
      if (vehicleCosts[record.vehicle_id]) {
        vehicleCosts[record.vehicle_id].maintenance += record.cost || 0;
      }
    });

    fuelLogs?.forEach(log => {
      if (vehicleCosts[log.vehicle_id]) {
        vehicleCosts[log.vehicle_id].fuel += log.cost || 0;
      }
    });

    Object.values(vehicleCosts).forEach((vc) => {
      vc.total = vc.maintenance + vc.fuel;
    });

    return Object.values(vehicleCosts);
  };

  const generateUtilizationReport = () => {
    return vehicles?.map(vehicle => {
      const vehicleFuelLogs = fuelLogs?.filter(log => log.vehicle_id === vehicle.id) || [];
      const totalLiters = vehicleFuelLogs.reduce((sum, log) => sum + (log.liters || 0), 0);
      const totalDistance = vehicleFuelLogs.length > 0 
        ? Math.max(...vehicleFuelLogs.map(log => log.mileage)) - Math.min(...vehicleFuelLogs.map(log => log.mileage))
        : 0;
      const efficiency = totalDistance > 0 ? (totalDistance / totalLiters) : 0;

      return {
        vehicle,
        totalLiters,
        totalDistance,
        efficiency: efficiency.toFixed(2),
        fuelCount: vehicleFuelLogs.length
      };
    }) || [];
  };

  const monthlyData = generateMonthlyReport();
  const utilizationData = generateUtilizationReport();

  const totalMaintenance = monthlyData.reduce((sum: number, v) => sum + v.maintenance, 0);
  const totalFuel = monthlyData.reduce((sum: number, v) => sum + v.fuel, 0);
  const grandTotal = totalMaintenance + totalFuel;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <FileText className="h-6 w-6" />
            Fleet Reports
          </h2>
          <p className="text-muted-foreground">Detailed fleet analytics and reports</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <label className="text-sm font-medium">Report Type</label>
          <Select value={reportType} onValueChange={setReportType}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="monthly-costs">Monthly Costs by Vehicle</SelectItem>
              <SelectItem value="utilization">Vehicle Utilization</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Month</label>
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          />
        </div>
      </div>

      {reportType === "monthly-costs" && (
        <Card>
          <div className="p-4 border-b flex justify-between items-center">
            <h3 className="font-semibold">Monthly Costs Report - {format(new Date(selectedMonth), "MMMM yyyy")}</h3>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Vehicle</TableHead>
                <TableHead>Maintenance</TableHead>
                <TableHead>Fuel</TableHead>
                <TableHead>Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {monthlyData.map((item) => (
                <TableRow key={item.vehicle.id}>
                  <TableCell>
                    {item.vehicle.plate_number}<br />
                    <span className="text-sm text-muted-foreground">
                      {item.vehicle.make} {item.vehicle.model}
                    </span>
                  </TableCell>
                  <TableCell>{item.maintenance.toFixed(2)} SAR</TableCell>
                  <TableCell>{item.fuel.toFixed(2)} SAR</TableCell>
                  <TableCell className="font-semibold">{item.total.toFixed(2)} SAR</TableCell>
                </TableRow>
              ))}
              <TableRow className="bg-muted/50 font-semibold">
                <TableCell>TOTAL</TableCell>
                <TableCell>{totalMaintenance.toFixed(2)} SAR</TableCell>
                <TableCell>{totalFuel.toFixed(2)} SAR</TableCell>
                <TableCell>{grandTotal.toFixed(2)} SAR</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </Card>
      )}

      {reportType === "utilization" && (
        <Card>
          <div className="p-4 border-b flex justify-between items-center">
            <h3 className="font-semibold">Vehicle Utilization Report - {format(new Date(selectedMonth), "MMMM yyyy")}</h3>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Vehicle</TableHead>
                <TableHead>Total Distance (km)</TableHead>
                <TableHead>Total Fuel (L)</TableHead>
                <TableHead>Efficiency (km/L)</TableHead>
                <TableHead>Fuel Entries</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {utilizationData.map((item: any) => (
                <TableRow key={item.vehicle.id}>
                  <TableCell>
                    {item.vehicle.plate_number}<br />
                    <span className="text-sm text-muted-foreground">
                      {item.vehicle.make} {item.vehicle.model}
                    </span>
                  </TableCell>
                  <TableCell>{item.totalDistance.toLocaleString()}</TableCell>
                  <TableCell>{item.totalLiters.toFixed(2)}</TableCell>
                  <TableCell>{item.efficiency}</TableCell>
                  <TableCell>{item.fuelCount}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
};