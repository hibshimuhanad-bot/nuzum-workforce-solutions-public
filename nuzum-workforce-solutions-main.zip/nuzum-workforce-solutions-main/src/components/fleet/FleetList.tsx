import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FleetDashboard } from "./FleetDashboard";
import { MaintenanceList } from "./MaintenanceList";
import { FuelList } from "./FuelList";
import { AssignmentList } from "./AssignmentList";
import { FleetReports } from "./FleetReports";
import { VehicleList } from "./VehicleList";
import { ProjectList } from "./ProjectList";
import { WorkshopsList } from "./WorkshopsList";
import { AllVehicleDocumentsList } from "./AllVehicleDocumentsList";
import SuppliersList from "@/components/suppliers/SuppliersList";
import ProjectInvoicesList from "@/components/invoices/ProjectInvoicesList";
import RentalAgreementsList from "@/components/rentals/RentalAgreementsList";

const FleetList = () => {
  return (
    <Tabs defaultValue="dashboard" className="space-y-6">
      <TabsList className="grid w-full grid-cols-6 lg:grid-cols-12">
        <TabsTrigger value="dashboard">لوحة التحكم</TabsTrigger>
        <TabsTrigger value="vehicles">السيارات</TabsTrigger>
        <TabsTrigger value="maintenance">الصيانة</TabsTrigger>
        <TabsTrigger value="fuel">الوقود</TabsTrigger>
        <TabsTrigger value="assignments">التعيينات</TabsTrigger>
        <TabsTrigger value="projects">المشاريع</TabsTrigger>
        <TabsTrigger value="suppliers">الموردين</TabsTrigger>
        <TabsTrigger value="invoices">الفواتير</TabsTrigger>
        <TabsTrigger value="rentals">الإيجارات</TabsTrigger>
        <TabsTrigger value="documents">الوثائق</TabsTrigger>
        <TabsTrigger value="workshops">الورش</TabsTrigger>
        <TabsTrigger value="reports">التقارير</TabsTrigger>
      </TabsList>

      <TabsContent value="dashboard">
        <FleetDashboard />
      </TabsContent>

      <TabsContent value="vehicles">
        <VehicleList />
      </TabsContent>

      <TabsContent value="maintenance">
        <MaintenanceList />
      </TabsContent>

      <TabsContent value="fuel">
        <FuelList />
      </TabsContent>

      <TabsContent value="assignments">
        <AssignmentList />
      </TabsContent>

      <TabsContent value="projects">
        <ProjectList />
      </TabsContent>

      <TabsContent value="suppliers">
        <SuppliersList />
      </TabsContent>

      <TabsContent value="invoices">
        <ProjectInvoicesList />
      </TabsContent>

      <TabsContent value="rentals">
        <RentalAgreementsList />
      </TabsContent>

      <TabsContent value="documents">
        <AllVehicleDocumentsList />
      </TabsContent>

      <TabsContent value="workshops">
        <WorkshopsList />
      </TabsContent>

      <TabsContent value="reports">
        <FleetReports />
      </TabsContent>
    </Tabs>
  );
};

export default FleetList;