import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { VehicleAttendanceDialog } from "./VehicleAttendanceDialog";
import { LogIn, LogOut, Calendar, Car } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export const VehicleAttendanceList = () => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<any>(null);

  const { data: records, isLoading, refetch } = useQuery({
    queryKey: ["vehicle-attendance"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("vehicle_check_in_out")
        .select(`
          *,
          vehicles(plate_number, make, model),
          employees(name)
        `)
        .eq("user_id", user.id)
        .order("check_in", { ascending: false });

      return data || [];
    },
  });

  const handleCheckOut = (record: any) => {
    setSelectedRecord(record);
    setDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <Calendar className="h-8 w-8" />
            حضور وانصراف السيارات
          </h2>
          <p className="text-muted-foreground mt-2">
            تتبع حركة السيارات وحالتها
          </p>
        </div>
        <Button
          onClick={() => {
            setSelectedRecord(null);
            setDialogOpen(true);
          }}
        >
          <LogIn className="h-4 w-4 mr-2" />
          تسجيل حضور
        </Button>
      </div>

      <Card className="p-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>السيارة</TableHead>
              <TableHead>السائق</TableHead>
              <TableHead>وقت الحضور</TableHead>
              <TableHead>وقت الانصراف</TableHead>
              <TableHead>المسافة المقطوعة</TableHead>
              <TableHead>الحالة</TableHead>
              <TableHead className="text-left">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {records?.map((record: any) => {
              const distanceTraveled = record.odometer_out
                ? record.odometer_out - record.odometer_in
                : null;

              return (
                <TableRow key={record.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <Car className="h-4 w-4" />
                      {record.vehicles?.plate_number || "غير معروف"}
                    </div>
                  </TableCell>
                  <TableCell>
                    {record.employees?.name || "لا يوجد"}
                  </TableCell>
                  <TableCell>
                    {format(new Date(record.check_in), "dd/MM/yyyy HH:mm", {
                      locale: ar,
                    })}
                  </TableCell>
                  <TableCell>
                    {record.check_out ? (
                      format(new Date(record.check_out), "dd/MM/yyyy HH:mm", {
                        locale: ar,
                      })
                    ) : (
                      <Badge variant="secondary">لم تنصرف</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {distanceTraveled ? `${distanceTraveled} كم` : "-"}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        record.condition_in === "excellent"
                          ? "default"
                          : record.condition_in === "good"
                          ? "secondary"
                          : "destructive"
                      }
                    >
                      {record.condition_in === "excellent"
                        ? "ممتازة"
                        : record.condition_in === "good"
                        ? "جيدة"
                        : record.condition_in === "needs_maintenance"
                        ? "تحتاج صيانة"
                        : "تالفة"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-left">
                    {!record.check_out && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleCheckOut(record)}
                      >
                        <LogOut className="h-4 w-4 mr-2" />
                        تسجيل انصراف
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>

        {records?.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            لا توجد سجلات حضور وانصراف بعد
          </div>
        )}
      </Card>

      <VehicleAttendanceDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSuccess={refetch}
        record={selectedRecord}
      />
    </div>
  );
};