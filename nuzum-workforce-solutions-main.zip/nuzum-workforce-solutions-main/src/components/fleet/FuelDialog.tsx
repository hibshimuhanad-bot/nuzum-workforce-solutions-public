import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";

interface FuelDialogProps {
  isOpen: boolean;
  onClose: () => void;
  fuelLog: any | null;
  onSuccess: () => void;
}

export const FuelDialog = ({ isOpen, onClose, fuelLog, onSuccess }: FuelDialogProps) => {
  const [formData, setFormData] = useState({
    vehicle_id: "",
    fuel_date: new Date().toISOString().split('T')[0],
    liters: "",
    cost: "",
    mileage: "",
    station_name: "",
    notes: ""
  });

  const [vehicles, setVehicles] = useState<any[]>([]);

  useEffect(() => {
    fetchVehicles();
  }, []);

  useEffect(() => {
    if (fuelLog) {
      setFormData({
        vehicle_id: fuelLog.vehicle_id || "",
        fuel_date: fuelLog.fuel_date?.split('T')[0] || new Date().toISOString().split('T')[0],
        liters: fuelLog.liters?.toString() || "",
        cost: fuelLog.cost?.toString() || "",
        mileage: fuelLog.mileage?.toString() || "",
        station_name: fuelLog.station_name || "",
        notes: fuelLog.notes || ""
      });
    } else {
      setFormData({
        vehicle_id: "",
        fuel_date: new Date().toISOString().split('T')[0],
        liters: "",
        cost: "",
        mileage: "",
        station_name: "",
        notes: ""
      });
    }
  }, [fuelLog]);

  const fetchVehicles = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("vehicles")
      .select("*")
      .eq("user_id", user.id)
      .order("plate_number");

    setVehicles(data || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: profile } = await supabase
      .from("profiles")
      .select("organization_id")
      .eq("id", user.id)
      .single();

    const payload = {
      vehicle_id: formData.vehicle_id,
      fuel_date: formData.fuel_date,
      liters: parseFloat(formData.liters),
      cost: parseFloat(formData.cost),
      mileage: parseInt(formData.mileage),
      station_name: formData.station_name || null,
      notes: formData.notes || null,
      user_id: user.id,
      organization_id: profile?.organization_id
    };

    if (fuelLog) {
      await supabase
        .from("fuel_logs")
        .update(payload)
        .eq("id", fuelLog.id);
    } else {
      await supabase
        .from("fuel_logs")
        .insert(payload);
    }

    onSuccess();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{fuelLog ? "Edit Fuel Log" : "Add Fuel Log"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="vehicle_id">Vehicle *</Label>
            <Select
              value={formData.vehicle_id}
              onValueChange={(value) => setFormData({ ...formData, vehicle_id: value })}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select vehicle" />
              </SelectTrigger>
              <SelectContent>
                {vehicles.map((vehicle) => (
                  <SelectItem key={vehicle.id} value={vehicle.id}>
                    {vehicle.plate_number} - {vehicle.make} {vehicle.model}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fuel_date">Date *</Label>
              <Input
                id="fuel_date"
                type="date"
                value={formData.fuel_date}
                onChange={(e) => setFormData({ ...formData, fuel_date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="mileage">Mileage *</Label>
              <Input
                id="mileage"
                type="number"
                value={formData.mileage}
                onChange={(e) => setFormData({ ...formData, mileage: e.target.value })}
                placeholder="Current mileage"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="liters">Liters *</Label>
              <Input
                id="liters"
                type="number"
                step="0.01"
                value={formData.liters}
                onChange={(e) => setFormData({ ...formData, liters: e.target.value })}
                placeholder="0.00"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cost">Cost (SAR) *</Label>
              <Input
                id="cost"
                type="number"
                step="0.01"
                value={formData.cost}
                onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                placeholder="0.00"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="station_name">Station Name</Label>
            <Input
              id="station_name"
              value={formData.station_name}
              onChange={(e) => setFormData({ ...formData, station_name: e.target.value })}
              placeholder="Gas station name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Additional notes..."
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              {fuelLog ? "Update" : "Add"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};