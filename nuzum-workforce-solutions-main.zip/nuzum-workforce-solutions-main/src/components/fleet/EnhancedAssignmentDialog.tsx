import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { Camera, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface EnhancedAssignmentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  assignment?: any;
  onSuccess: () => void;
}

export const EnhancedAssignmentDialog = ({
  isOpen,
  onClose,
  assignment,
  onSuccess,
}: EnhancedAssignmentDialogProps) => {
  const { toast } = useToast();
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    vehicle_id: "",
    employee_id: "",
    assigned_date: "",
    return_date: "",
    delivery_condition: "",
    delivery_odometer: "",
    notes: "",
    checklist: {
      tires: false,
      brakes: false,
      lights: false,
      fluids: false,
      body: false,
      interior: false,
    },
  });
  const [deliveryPhotos, setDeliveryPhotos] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchVehicles();
    fetchEmployees();
  }, []);

  useEffect(() => {
    if (assignment) {
      setFormData({
        vehicle_id: assignment.vehicle_id || "",
        employee_id: assignment.employee_id || "",
        assigned_date: assignment.assigned_date?.split("T")[0] || "",
        return_date: assignment.return_date?.split("T")[0] || "",
        delivery_condition: assignment.delivery_condition || "",
        delivery_odometer: assignment.delivery_odometer || "",
        notes: assignment.notes || "",
        checklist: assignment.checklist || {
          tires: false,
          brakes: false,
          lights: false,
          fluids: false,
          body: false,
          interior: false,
        },
      });
    }
  }, [assignment]);

  const fetchVehicles = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("vehicles")
      .select("*")
      .eq("user_id", user.id)
      .eq("status", "active");

    if (data) setVehicles(data);
  };

  const fetchEmployees = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("employees")
      .select("*")
      .eq("user_id", user.id)
      .eq("status", "active");

    if (data) setEmployees(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: profile } = await supabase
        .from("profiles")
        .select("organization_id")
        .eq("id", user.id)
        .single();

      if (!profile?.organization_id) throw new Error("Organization not found");

      // Upload photos if any
      let photoUrls: string[] = [];
      if (deliveryPhotos.length > 0) {
        for (const photo of deliveryPhotos) {
          const fileExt = photo.name.split(".").pop();
          const fileName = `${user.id}/assignments/${Date.now()}-${Math.random()}.${fileExt}`;

          const { error: uploadError } = await supabase.storage
            .from("vehicle-documents")
            .upload(fileName, photo);

          if (!uploadError) {
            photoUrls.push(fileName);
          }
        }
      }

      const assignmentData = {
        vehicle_id: formData.vehicle_id,
        employee_id: formData.employee_id,
        assigned_date: formData.assigned_date,
        return_date: formData.return_date || null,
        delivery_condition: formData.delivery_condition,
        delivery_odometer: formData.delivery_odometer ? parseInt(formData.delivery_odometer) : null,
        delivery_photos: photoUrls.length > 0 ? photoUrls : null,
        notes: formData.notes || null,
        checklist: formData.checklist,
        status: "active",
        organization_id: profile.organization_id,
        user_id: user.id,
      };

      if (assignment) {
        const { error } = await supabase
          .from("vehicle_assignments")
          .update(assignmentData)
          .eq("id", assignment.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("vehicle_assignments")
          .insert([assignmentData]);

        if (error) throw error;
      }

      onSuccess();
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{assignment ? "تعديل التسليم" : "تسليم مركبة جديد"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="vehicle_id">المركبة *</Label>
              <Select
                value={formData.vehicle_id}
                onValueChange={(value) => setFormData({ ...formData, vehicle_id: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر المركبة" />
                </SelectTrigger>
                <SelectContent>
                  {vehicles.map((vehicle) => (
                    <SelectItem key={vehicle.id} value={vehicle.id}>
                      {vehicle.plate_number} - {vehicle.make} {vehicle.model}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="employee_id">الموظف *</Label>
              <Select
                value={formData.employee_id}
                onValueChange={(value) => setFormData({ ...formData, employee_id: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر الموظف" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((employee) => (
                    <SelectItem key={employee.id} value={employee.id}>
                      {employee.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="assigned_date">تاريخ التسليم *</Label>
              <Input
                id="assigned_date"
                type="date"
                value={formData.assigned_date}
                onChange={(e) => setFormData({ ...formData, assigned_date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="return_date">تاريخ الاستلام المتوقع</Label>
              <Input
                id="return_date"
                type="date"
                value={formData.return_date}
                onChange={(e) => setFormData({ ...formData, return_date: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="delivery_odometer">قراءة العداد *</Label>
              <Input
                id="delivery_odometer"
                type="number"
                value={formData.delivery_odometer}
                onChange={(e) => setFormData({ ...formData, delivery_odometer: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="delivery_condition">حالة المركبة *</Label>
              <Select
                value={formData.delivery_condition}
                onValueChange={(value) => setFormData({ ...formData, delivery_condition: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="excellent">ممتازة</SelectItem>
                  <SelectItem value="good">جيدة</SelectItem>
                  <SelectItem value="fair">متوسطة</SelectItem>
                  <SelectItem value="poor">سيئة</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-3">
            <Label>قائمة الفحص</Label>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(formData.checklist).map(([key, value]) => (
                <div key={key} className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox
                    id={key}
                    checked={value}
                    onCheckedChange={(checked) =>
                      setFormData({
                        ...formData,
                        checklist: { ...formData.checklist, [key]: checked as boolean },
                      })
                    }
                  />
                  <Label htmlFor={key} className="cursor-pointer">
                    {key === "tires" && "الإطارات"}
                    {key === "brakes" && "الفرامل"}
                    {key === "lights" && "الأضواء"}
                    {key === "fluids" && "السوائل"}
                    {key === "body" && "الهيكل"}
                    {key === "interior" && "الداخلية"}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="photos">صور المركبة</Label>
            <div className="flex items-center gap-2">
              <Input
                id="photos"
                type="file"
                accept="image/*"
                multiple
                onChange={(e) => setDeliveryPhotos(Array.from(e.target.files || []))}
              />
              <Camera className="h-4 w-4 text-muted-foreground" />
            </div>
            <p className="text-xs text-muted-foreground">
              يمكنك رفع عدة صور (من زوايا مختلفة)
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">ملاحظات</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              placeholder="أي ملاحظات أو أضرار موجودة..."
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              إلغاء
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "جاري الحفظ..." : assignment ? "تحديث" : "تسليم"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
