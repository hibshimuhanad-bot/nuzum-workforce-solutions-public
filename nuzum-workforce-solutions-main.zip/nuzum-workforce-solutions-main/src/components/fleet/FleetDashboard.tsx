import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Car, Wrench, Fuel, DollarSign, TrendingUp, AlertTriangle } from "lucide-react";
import { FleetAlerts } from "./FleetAlerts";

export const FleetDashboard = () => {
  const { data: vehicles } = useQuery({
    queryKey: ["vehicles_dashboard"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("vehicles")
        .select("*")
        .eq("user_id", user.id);

      return data || [];
    },
  });

  const { data: maintenanceRecords } = useQuery({
    queryKey: ["maintenance_dashboard"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("vehicle_maintenance")
        .select("*")
        .eq("user_id", user.id);

      return data || [];
    },
  });

  const { data: fuelLogs } = useQuery({
    queryKey: ["fuel_dashboard"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("fuel_logs")
        .select("*")
        .eq("user_id", user.id);

      return data || [];
    },
  });

  const { data: assignments } = useQuery({
    queryKey: ["assignments_dashboard"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("vehicle_assignments")
        .select("*")
        .eq("user_id", user.id);

      return data || [];
    },
  });

  // Calculate statistics
  const totalVehicles = vehicles?.length || 0;
  const activeVehicles = vehicles?.filter(v => v.status === 'active').length || 0;
  const inMaintenance = vehicles?.filter(v => v.status === 'maintenance').length || 0;
  
  const totalMaintenanceCost = maintenanceRecords?.reduce((sum, r) => sum + (r.cost || 0), 0) || 0;
  const totalFuelCost = fuelLogs?.reduce((sum, l) => sum + (l.cost || 0), 0) || 0;
  const totalOperatingCost = totalMaintenanceCost + totalFuelCost;

  const activeAssignments = assignments?.filter(a => !a.return_date).length || 0;

  // Get current month data
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const thisMonthMaintenance = maintenanceRecords?.filter(r => {
    const date = new Date(r.maintenance_date);
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
  }).reduce((sum, r) => sum + (r.cost || 0), 0) || 0;

  const thisMonthFuel = fuelLogs?.filter(l => {
    const date = new Date(l.fuel_date);
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
  }).reduce((sum, l) => sum + (l.cost || 0), 0) || 0;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Fleet Dashboard</h2>
        <p className="text-muted-foreground">Overview of your fleet operations</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">Total Vehicles</div>
              <div className="text-3xl font-bold">{totalVehicles}</div>
              <div className="text-xs text-muted-foreground mt-1">
                {activeVehicles} active, {inMaintenance} in maintenance
              </div>
            </div>
            <Car className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">Active Assignments</div>
              <div className="text-3xl font-bold">{activeAssignments}</div>
              <div className="text-xs text-muted-foreground mt-1">
                Vehicles currently assigned
              </div>
            </div>
            <TrendingUp className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">This Month Costs</div>
              <div className="text-3xl font-bold">{(thisMonthMaintenance + thisMonthFuel).toFixed(0)}</div>
              <div className="text-xs text-muted-foreground mt-1">
                SAR (Fuel + Maintenance)
              </div>
            </div>
            <DollarSign className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">Total Operating Cost</div>
              <div className="text-3xl font-bold">{totalOperatingCost.toFixed(0)}</div>
              <div className="text-xs text-muted-foreground mt-1">
                SAR (All time)
              </div>
            </div>
            <DollarSign className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Wrench className="h-5 w-5" />
            Maintenance Overview
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total Records:</span>
              <span className="font-semibold">{maintenanceRecords?.length || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total Cost:</span>
              <span className="font-semibold">{totalMaintenanceCost.toFixed(2)} SAR</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">This Month:</span>
              <span className="font-semibold">{thisMonthMaintenance.toFixed(2)} SAR</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Avg per Vehicle:</span>
              <span className="font-semibold">
                {totalVehicles > 0 ? (totalMaintenanceCost / totalVehicles).toFixed(2) : 0} SAR
              </span>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Fuel className="h-5 w-5" />
            Fuel Overview
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total Logs:</span>
              <span className="font-semibold">{fuelLogs?.length || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total Cost:</span>
              <span className="font-semibold">{totalFuelCost.toFixed(2)} SAR</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">This Month:</span>
              <span className="font-semibold">{thisMonthFuel.toFixed(2)} SAR</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total Liters:</span>
              <span className="font-semibold">
                {fuelLogs?.reduce((sum, l) => sum + (l.liters || 0), 0).toFixed(2) || 0} L
              </span>
            </div>
          </div>
        </Card>
      </div>

      <FleetAlerts />
    </div>
  );
};