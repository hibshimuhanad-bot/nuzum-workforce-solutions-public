import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { MaintenanceDialog } from "./MaintenanceDialog";
import { Plus, Wrench } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export const MaintenanceList = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedMaintenance, setSelectedMaintenance] = useState<any>(null);
  const { toast } = useToast();

  const { data: maintenanceRecords, isLoading, refetch } = useQuery({
    queryKey: ["vehicle_maintenance"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from("vehicle_maintenance")
        .select(`
          *,
          vehicles (
            plate_number,
            make,
            model
          )
        `)
        .eq("user_id", user.id)
        .order("maintenance_date", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const handleEdit = (maintenance: any) => {
    setSelectedMaintenance(maintenance);
    setIsDialogOpen(true);
  };

  const handleAdd = () => {
    setSelectedMaintenance(null);
    setIsDialogOpen(true);
  };

  if (isLoading) {
    return <div>Loading maintenance records...</div>;
  }

  const totalCost = maintenanceRecords?.reduce((sum, record) => sum + (record.cost || 0), 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Wrench className="h-6 w-6" />
            Maintenance Records
          </h2>
          <p className="text-muted-foreground">Track all vehicle maintenance activities</p>
        </div>
        <Button onClick={handleAdd}>
          <Plus className="mr-2 h-4 w-4" />
          Add Maintenance
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Total Records</div>
          <div className="text-2xl font-bold">{maintenanceRecords?.length || 0}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Total Maintenance Cost</div>
          <div className="text-2xl font-bold">{totalCost.toFixed(2)} SAR</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">This Month</div>
          <div className="text-2xl font-bold">
            {maintenanceRecords?.filter(r => {
              const date = new Date(r.maintenance_date);
              const now = new Date();
              return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
            }).length || 0}
          </div>
        </Card>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Vehicle</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Cost</TableHead>
              <TableHead>Mileage</TableHead>
              <TableHead>Performed By</TableHead>
              <TableHead>Next Service</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {maintenanceRecords && maintenanceRecords.length > 0 ? (
              maintenanceRecords.map((record) => (
                <TableRow key={record.id}>
                  <TableCell>{format(new Date(record.maintenance_date), "MMM dd, yyyy")}</TableCell>
                  <TableCell>
                    {record.vehicles?.plate_number}<br />
                    <span className="text-sm text-muted-foreground">
                      {record.vehicles?.make} {record.vehicles?.model}
                    </span>
                  </TableCell>
                  <TableCell>{record.maintenance_type}</TableCell>
                  <TableCell>{record.cost ? `${record.cost} SAR` : '-'}</TableCell>
                  <TableCell>{record.mileage ? record.mileage.toLocaleString() : '-'}</TableCell>
                  <TableCell>{record.performed_by || '-'}</TableCell>
                  <TableCell>
                    {record.next_maintenance_date 
                      ? format(new Date(record.next_maintenance_date), "MMM dd, yyyy")
                      : '-'}
                  </TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => handleEdit(record)}>
                      Edit
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center text-muted-foreground">
                  No maintenance records found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>

      <MaintenanceDialog
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        maintenance={selectedMaintenance}
        onSuccess={() => {
          refetch();
          toast({
            title: "Success",
            description: "Maintenance record saved successfully",
          });
        }}
      />
    </div>
  );
};