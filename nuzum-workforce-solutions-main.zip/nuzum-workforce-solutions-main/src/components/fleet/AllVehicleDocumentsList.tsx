import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileText, Download, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export const AllVehicleDocumentsList = () => {
  const { organizationId } = useOrganization();
  const { toast } = useToast();

  const { data: documents, isLoading } = useQuery({
    queryKey: ["all_vehicle_documents", organizationId],
    queryFn: async () => {
      const { data: docs, error: docsError } = await supabase
        .from("vehicle_documents")
        .select("*")
        .eq("organization_id", organizationId)
        .order("created_at", { ascending: false });

      if (docsError) throw docsError;

      // Fetch vehicle details separately
      const vehicleIds = [...new Set(docs?.map(d => d.vehicle_id))];
      const { data: vehicles, error: vehiclesError } = await supabase
        .from("vehicles")
        .select("id, plate_number, make, model")
        .in("id", vehicleIds);

      if (vehiclesError) throw vehiclesError;

      // Merge data
      const vehicleMap = new Map(vehicles?.map(v => [v.id, v]));
      return docs?.map(doc => ({
        ...doc,
        vehicle: vehicleMap.get(doc.vehicle_id)
      }));
    },
    enabled: !!organizationId,
  });

  const getStatusBadge = (expiryDate: string | null) => {
    if (!expiryDate) return <Badge variant="secondary">لا يوجد تاريخ انتهاء</Badge>;
    
    const expiry = new Date(expiryDate);
    const now = new Date();
    const daysUntilExpiry = Math.floor((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    if (daysUntilExpiry < 0) {
      return <Badge variant="destructive">منتهية</Badge>;
    } else if (daysUntilExpiry <= 30) {
      return <Badge className="bg-orange-500">قريبة الانتهاء ({daysUntilExpiry} يوم)</Badge>;
    }
    return <Badge className="bg-green-500">سارية</Badge>;
  };

  const handleDownload = async (filePath: string, documentName: string) => {
    try {
      const { data, error } = await supabase.storage
        .from("vehicle-documents")
        .download(filePath);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = documentName;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: "تم التنزيل بنجاح",
        description: "تم تنزيل الوثيقة",
      });
    } catch (error) {
      toast({
        title: "خطأ",
        description: "فشل تنزيل الوثيقة",
        variant: "destructive",
      });
    }
  };

  const expiringDocs = documents?.filter((doc) => {
    if (!doc.expiry_date) return false;
    const expiry = new Date(doc.expiry_date);
    const now = new Date();
    const daysUntilExpiry = Math.floor((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry >= 0 && daysUntilExpiry <= 30;
  });

  const expiredDocs = documents?.filter((doc) => {
    if (!doc.expiry_date) return false;
    const expiry = new Date(doc.expiry_date);
    const now = new Date();
    return expiry < now;
  });

  if (isLoading) {
    return <div className="p-8">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">وثائق السيارات</h1>
      </div>

      {(expiringDocs && expiringDocs.length > 0) || (expiredDocs && expiredDocs.length > 0) ? (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <AlertCircle className="h-5 w-5" />
              تنبيهات الوثائق
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {expiredDocs && expiredDocs.length > 0 && (
              <div className="text-sm text-red-800">
                <strong>{expiredDocs.length}</strong> وثيقة منتهية
              </div>
            )}
            {expiringDocs && expiringDocs.length > 0 && (
              <div className="text-sm text-orange-800">
                <strong>{expiringDocs.length}</strong> وثيقة قريبة الانتهاء (خلال 30 يوم)
              </div>
            )}
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>قائمة الوثائق</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>اسم الوثيقة</TableHead>
                <TableHead>السيارة</TableHead>
                <TableHead>النوع</TableHead>
                <TableHead>رقم الوثيقة</TableHead>
                <TableHead>تاريخ الإصدار</TableHead>
                <TableHead>تاريخ الانتهاء</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {documents?.map((doc) => (
                <TableRow key={doc.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      {doc.document_name}
                    </div>
                  </TableCell>
                  <TableCell>
                    {doc.vehicle?.plate_number} - {doc.vehicle?.make} {doc.vehicle?.model}
                  </TableCell>
                  <TableCell>{doc.document_type}</TableCell>
                  <TableCell>{doc.document_number || "-"}</TableCell>
                  <TableCell>
                    {doc.issue_date ? format(new Date(doc.issue_date), "yyyy-MM-dd") : "-"}
                  </TableCell>
                  <TableCell>
                    {doc.expiry_date ? format(new Date(doc.expiry_date), "yyyy-MM-dd") : "-"}
                  </TableCell>
                  <TableCell>{getStatusBadge(doc.expiry_date)}</TableCell>
                  <TableCell>
                    {doc.file_path && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDownload(doc.file_path, doc.document_name)}
                      >
                        <Download className="h-4 w-4 mr-1" />
                        تنزيل
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {(!documents || documents.length === 0) && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground">
                    لا توجد وثائق مسجلة
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};
