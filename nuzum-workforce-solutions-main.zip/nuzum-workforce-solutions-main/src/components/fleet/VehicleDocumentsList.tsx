import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText, Plus, Download, AlertCircle } from "lucide-react";
import { VehicleDocumentsDialog } from "./VehicleDocumentsDialog";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface VehicleDocumentsListProps {
  vehicleId: string;
}

export const VehicleDocumentsList = ({ vehicleId }: VehicleDocumentsListProps) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<any>(null);
  const { toast } = useToast();

  const { data: documents, isLoading, refetch } = useQuery({
    queryKey: ["vehicle_documents", vehicleId],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("vehicle_documents")
        .select("*")
        .eq("vehicle_id", vehicleId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const getStatusBadge = (expiryDate: string | null) => {
    if (!expiryDate) return <Badge variant="secondary">لا يوجد تاريخ انتهاء</Badge>;
    
    const expiry = new Date(expiryDate);
    const now = new Date();
    const daysUntilExpiry = Math.floor((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    if (daysUntilExpiry < 0) {
      return <Badge variant="destructive">منتهية</Badge>;
    } else if (daysUntilExpiry <= 30) {
      return <Badge className="bg-orange-500">قريبة الانتهاء ({daysUntilExpiry} يوم)</Badge>;
    }
    return <Badge className="bg-green-500">سارية</Badge>;
  };

  const handleDownload = async (filePath: string, documentName: string) => {
    try {
      const { data, error } = await supabase.storage
        .from("vehicle-documents")
        .download(filePath);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = documentName;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: "تم التنزيل بنجاح",
        description: "تم تنزيل الوثيقة",
      });
    } catch (error) {
      toast({
        title: "خطأ",
        description: "فشل تنزيل الوثيقة",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">وثائق المركبة</h3>
        <Button onClick={() => {
          setSelectedDocument(null);
          setIsDialogOpen(true);
        }}>
          <Plus className="mr-2 h-4 w-4" />
          إضافة وثيقة
        </Button>
      </div>

      {!documents || documents.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            لا توجد وثائق مسجلة
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {documents.map((doc) => (
            <Card key={doc.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    <CardTitle className="text-base">{doc.document_name}</CardTitle>
                  </div>
                  {getStatusBadge(doc.expiry_date)}
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">النوع:</span>
                    <p className="font-medium">{doc.document_type}</p>
                  </div>
                  {doc.document_number && (
                    <div>
                      <span className="text-muted-foreground">الرقم:</span>
                      <p className="font-medium">{doc.document_number}</p>
                    </div>
                  )}
                  {doc.issue_date && (
                    <div>
                      <span className="text-muted-foreground">تاريخ الإصدار:</span>
                      <p className="font-medium">{format(new Date(doc.issue_date), "yyyy-MM-dd")}</p>
                    </div>
                  )}
                  {doc.expiry_date && (
                    <div>
                      <span className="text-muted-foreground">تاريخ الانتهاء:</span>
                      <p className="font-medium">{format(new Date(doc.expiry_date), "yyyy-MM-dd")}</p>
                    </div>
                  )}
                </div>
                {doc.notes && (
                  <div className="text-sm">
                    <span className="text-muted-foreground">ملاحظات:</span>
                    <p className="text-muted-foreground">{doc.notes}</p>
                  </div>
                )}
                <div className="flex gap-2 pt-2">
                  {doc.file_path && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDownload(doc.file_path, doc.document_name)}
                    >
                      <Download className="h-4 w-4 mr-1" />
                      تنزيل
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSelectedDocument(doc);
                      setIsDialogOpen(true);
                    }}
                  >
                    تعديل
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <VehicleDocumentsDialog
        isOpen={isDialogOpen}
        onClose={() => {
          setIsDialogOpen(false);
          setSelectedDocument(null);
        }}
        vehicleId={vehicleId}
        document={selectedDocument}
        onSuccess={() => {
          refetch();
          setIsDialogOpen(false);
          setSelectedDocument(null);
          toast({
            title: "نجح",
            description: selectedDocument ? "تم تحديث الوثيقة" : "تمت إضافة الوثيقة",
          });
        }}
      />
    </div>
  );
};
