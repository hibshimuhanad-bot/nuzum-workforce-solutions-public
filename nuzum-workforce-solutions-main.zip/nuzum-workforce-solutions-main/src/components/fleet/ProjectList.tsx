import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Edit, Trash2, Eye, Car } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ProjectDialog } from "./ProjectDialog";
import { ProjectVehicles } from "./ProjectVehicles";
import { useOrganization } from "@/hooks/useOrganization";

export function ProjectList() {
  const { organizationId } = useOrganization();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [vehiclesDialogOpen, setVehiclesDialogOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<any>(null);

  const { data: projects, isLoading, refetch } = useQuery({
    queryKey: ["fleet_projects", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("fleet_projects")
        .select("*")
        .eq("organization_id", organizationId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      
      // Fetch vehicle counts for all projects
      if (!data || data.length === 0) return [];
      
      const projectIds = data.map(p => p.id);
      const { data: assignments } = await supabase
        .from("vehicle_project_assignments")
        .select("project_id")
        .in("project_id", projectIds)
        .eq("organization_id", organizationId);
      
      // Count vehicles per project
      const vehicleCounts = (assignments || []).reduce((acc: Record<string, number>, curr) => {
        acc[curr.project_id] = (acc[curr.project_id] || 0) + 1;
        return acc;
      }, {});
      
      // Add actual vehicle count to each project
      return data.map(project => ({
        ...project,
        actual_vehicles_count: vehicleCounts[project.id] || 0
      }));
    },
    enabled: !!organizationId,
  });

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا المشروع؟")) return;

    try {
      const { error } = await supabase
        .from("fleet_projects")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast.success("تم حذف المشروع بنجاح");
      refetch();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: any }> = {
      active: { label: "نشط", variant: "default" },
      completed: { label: "مكتمل", variant: "secondary" },
      on_hold: { label: "معلق", variant: "outline" },
      cancelled: { label: "ملغي", variant: "destructive" },
    };
    const statusInfo = statusMap[status] || statusMap.active;
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>;
  };

  const stats = {
    total: projects?.length || 0,
    active: projects?.filter(p => p.status === 'active').length || 0,
    completed: projects?.filter(p => p.status === 'completed').length || 0,
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المشاريع</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">المشاريع النشطة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.active}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">المشاريع المكتملة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.completed}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>المشاريع</CardTitle>
          <Button onClick={() => { setSelectedProject(null); setDialogOpen(true); }}>
            <Plus className="h-4 w-4 ml-2" />
            إضافة مشروع
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">جاري التحميل...</div>
          ) : !projects || projects.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد مشاريع. ابدأ بإضافة مشروع جديد!
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم المشروع</TableHead>
                  <TableHead>الموقع</TableHead>
                  <TableHead>تاريخ البداية</TableHead>
                  <TableHead>تاريخ النهاية</TableHead>
                  <TableHead>الميزانية</TableHead>
                  <TableHead>السيارات</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {projects.map((project) => (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">{project.name}</TableCell>
                    <TableCell>{project.location || "-"}</TableCell>
                    <TableCell>{new Date(project.start_date).toLocaleDateString('ar-SA')}</TableCell>
                    <TableCell>
                      {project.end_date ? new Date(project.end_date).toLocaleDateString('ar-SA') : "-"}
                    </TableCell>
                    <TableCell>{project.budget ? `${project.budget} ريال` : "-"}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={project.actual_vehicles_count >= project.vehicles_count ? "default" : "secondary"}
                        className="gap-1"
                      >
                        <Car className="h-3 w-3" />
                        {project.actual_vehicles_count} / {project.vehicles_count || 0}
                      </Badge>
                    </TableCell>
                    <TableCell>{getStatusBadge(project.status)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setSelectedProject(project);
                            setVehiclesDialogOpen(true);
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setSelectedProject(project);
                            setDialogOpen(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(project.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <ProjectDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        project={selectedProject}
        onSuccess={refetch}
      />

      {selectedProject && (
        <ProjectVehicles
          open={vehiclesDialogOpen}
          onOpenChange={setVehiclesDialogOpen}
          project={selectedProject}
        />
      )}
    </div>
  );
}