import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Wrench } from "lucide-react";
import { WorkshopDialog } from "./WorkshopDialog";
import { useToast } from "@/hooks/use-toast";

export const WorkshopsList = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedWorkshop, setSelectedWorkshop] = useState<any>(null);
  const { toast } = useToast();

  const { data: workshops, isLoading, refetch } = useQuery({
    queryKey: ["maintenance_workshops"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("maintenance_workshops")
        .select("*")
        .eq("user_id", user.id)
        .order("name");

      if (error) throw error;
      return data;
    },
  });

  if (isLoading) {
    return <div className="text-center py-8">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">الورش</h2>
          <p className="text-muted-foreground">إدارة ورش الصيانة</p>
        </div>
        <Button onClick={() => {
          setSelectedWorkshop(null);
          setIsDialogOpen(true);
        }}>
          <Plus className="mr-2 h-4 w-4" />
          إضافة ورشة
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wrench className="h-5 w-5" />
            قائمة الورش
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!workshops || workshops.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد ورش مسجلة
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم الورشة</TableHead>
                  <TableHead>التخصص</TableHead>
                  <TableHead>الهاتف</TableHead>
                  <TableHead>العنوان</TableHead>
                  <TableHead>التقييم</TableHead>
                  <TableHead>عدد الخدمات</TableHead>
                  <TableHead>الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {workshops.map((workshop) => (
                  <TableRow key={workshop.id}>
                    <TableCell className="font-medium">{workshop.name}</TableCell>
                    <TableCell>{workshop.specialization || "-"}</TableCell>
                    <TableCell>{workshop.phone || "-"}</TableCell>
                    <TableCell>{workshop.address || "-"}</TableCell>
                    <TableCell>
                      {workshop.rating ? `⭐ ${workshop.rating.toFixed(1)}` : "-"}
                    </TableCell>
                    <TableCell>{workshop.total_services || 0}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedWorkshop(workshop);
                          setIsDialogOpen(true);
                        }}
                      >
                        تعديل
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <WorkshopDialog
        isOpen={isDialogOpen}
        onClose={() => {
          setIsDialogOpen(false);
          setSelectedWorkshop(null);
        }}
        workshop={selectedWorkshop}
        onSuccess={() => {
          refetch();
          setIsDialogOpen(false);
          setSelectedWorkshop(null);
          toast({
            title: "نجح",
            description: selectedWorkshop ? "تم تحديث الورشة" : "تمت إضافة الورشة",
          });
        }}
      />
    </div>
  );
};
