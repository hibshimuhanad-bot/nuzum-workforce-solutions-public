import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Car, User } from "lucide-react";

const checkInSchema = z.object({
  vehicle_id: z.string().min(1, "يجب اختيار السيارة"),
  driver_id: z.string().optional(),
  odometer_in: z.number().min(0, "يجب أن يكون الرقم موجباً"),
  fuel_level_in: z.number().min(0).max(100, "يجب أن يكون بين 0 و 100"),
  condition_in: z.string().min(1, "يجب اختيار حالة السيارة"),
  notes: z.string().optional(),
});

type CheckInFormValues = z.infer<typeof checkInSchema>;

interface VehicleAttendanceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  record?: any;
}

export const VehicleAttendanceDialog = ({
  open,
  onOpenChange,
  onSuccess,
  record,
}: VehicleAttendanceDialogProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const isCheckOut = record && !record.check_out;

  const { data: vehicles } = useQuery({
    queryKey: ["vehicles-list"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("vehicles")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active");

      return data || [];
    },
  });

  const { data: drivers } = useQuery({
    queryKey: ["drivers-list"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("employees")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active");

      return data || [];
    },
  });

  const form = useForm<CheckInFormValues>({
    resolver: zodResolver(checkInSchema),
    defaultValues: {
      vehicle_id: record?.vehicle_id || "",
      driver_id: record?.driver_id || "",
      odometer_in: record?.odometer_in || 0,
      fuel_level_in: record?.fuel_level_in || 0,
      condition_in: record?.condition_in || "excellent",
      notes: record?.notes || "",
    },
  });

  const onSubmit = async (values: CheckInFormValues) => {
    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("لم يتم العثور على المستخدم");

      const { data: profile } = await supabase
        .from("profiles")
        .select("organization_id")
        .eq("id", user.id)
        .single();

      if (!profile?.organization_id) throw new Error("لم يتم العثور على المنظمة");

      if (isCheckOut) {
        // Update check-out
        const { error } = await supabase
          .from("vehicle_check_in_out")
          .update({
            check_out: new Date().toISOString(),
            odometer_out: values.odometer_in,
            fuel_level_out: values.fuel_level_in,
            condition_out: values.condition_in,
            notes: values.notes,
          })
          .eq("id", record.id);

        if (error) throw error;

        toast({
          title: "تم الانصراف",
          description: "تم تسجيل انصراف السيارة بنجاح",
        });
      } else {
        // Create check-in
        const { error } = await supabase
          .from("vehicle_check_in_out")
          .insert({
            vehicle_id: values.vehicle_id,
            driver_id: values.driver_id || null,
            odometer_in: values.odometer_in,
            fuel_level_in: values.fuel_level_in,
            condition_in: values.condition_in,
            notes: values.notes,
            organization_id: profile.organization_id,
            user_id: user.id,
          });

        if (error) throw error;

        toast({
          title: "تم الحضور",
          description: "تم تسجيل حضور السيارة بنجاح",
        });
      }

      form.reset();
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Car className="h-5 w-5" />
            {isCheckOut ? "تسجيل انصراف السيارة" : "تسجيل حضور السيارة"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="vehicle_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>السيارة</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      disabled={isCheckOut}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر السيارة" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {vehicles?.map((vehicle) => (
                          <SelectItem key={vehicle.id} value={vehicle.id}>
                            {vehicle.plate_number} - {vehicle.make} {vehicle.model}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="driver_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>السائق</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      disabled={isCheckOut}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر السائق (اختياري)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {drivers?.map((driver) => (
                          <SelectItem key={driver.id} value={driver.id}>
                            {driver.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="odometer_in"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {isCheckOut ? "عداد المسافات (خروج)" : "عداد المسافات (دخول)"}
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="fuel_level_in"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {isCheckOut ? "مستوى الوقود % (خروج)" : "مستوى الوقود % (دخول)"}
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="condition_in"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {isCheckOut ? "حالة السيارة (خروج)" : "حالة السيارة (دخول)"}
                    </FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر الحالة" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="excellent">ممتازة</SelectItem>
                        <SelectItem value="good">جيدة</SelectItem>
                        <SelectItem value="needs_maintenance">تحتاج صيانة</SelectItem>
                        <SelectItem value="damaged">تالفة</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>ملاحظات</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="أي ملاحظات عن حالة السيارة..."
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                إلغاء
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading
                  ? "جاري الحفظ..."
                  : isCheckOut
                  ? "تسجيل الانصراف"
                  : "تسجيل الحضور"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};