import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface VehicleDocumentsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  vehicleId: string;
  document?: any;
  onSuccess: () => void;
}

export const VehicleDocumentsDialog = ({
  isOpen,
  onClose,
  vehicleId,
  document,
  onSuccess,
}: VehicleDocumentsDialogProps) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    document_name: "",
    document_type: "",
    document_number: "",
    issue_date: "",
    expiry_date: "",
    notes: "",
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (document) {
      setFormData({
        document_name: document.document_name || "",
        document_type: document.document_type || "",
        document_number: document.document_number || "",
        issue_date: document.issue_date ? document.issue_date.split("T")[0] : "",
        expiry_date: document.expiry_date ? document.expiry_date.split("T")[0] : "",
        notes: document.notes || "",
      });
    } else {
      setFormData({
        document_name: "",
        document_type: "",
        document_number: "",
        issue_date: "",
        expiry_date: "",
        notes: "",
      });
    }
    setSelectedFile(null);
  }, [document, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: profile } = await supabase
        .from("profiles")
        .select("organization_id")
        .eq("id", user.id)
        .single();

      if (!profile?.organization_id) throw new Error("Organization not found");

      let filePath = document?.file_path;

      // Upload file if selected
      if (selectedFile) {
        const fileExt = selectedFile.name.split(".").pop();
        const fileName = `${user.id}/${vehicleId}/${Date.now()}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from("vehicle-documents")
          .upload(fileName, selectedFile);

        if (uploadError) throw uploadError;
        filePath = fileName;
      }

      const documentData = {
        vehicle_id: vehicleId,
        document_name: formData.document_name,
        document_type: formData.document_type,
        document_number: formData.document_number || null,
        issue_date: formData.issue_date || null,
        expiry_date: formData.expiry_date || null,
        file_path: filePath,
        notes: formData.notes || null,
        organization_id: profile.organization_id,
        user_id: user.id,
      };

      if (document) {
        const { error } = await supabase
          .from("vehicle_documents")
          .update(documentData)
          .eq("id", document.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("vehicle_documents")
          .insert([documentData]);

        if (error) throw error;
      }

      onSuccess();
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{document ? "تعديل الوثيقة" : "إضافة وثيقة جديدة"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="document_name">اسم الوثيقة *</Label>
              <Input
                id="document_name"
                value={formData.document_name}
                onChange={(e) => setFormData({ ...formData, document_name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="document_type">نوع الوثيقة *</Label>
              <Select
                value={formData.document_type}
                onValueChange={(value) => setFormData({ ...formData, document_type: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر النوع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="registration">رخصة السير</SelectItem>
                  <SelectItem value="insurance">التأمين</SelectItem>
                  <SelectItem value="inspection">الفحص الدوري</SelectItem>
                  <SelectItem value="authorization">تفويض</SelectItem>
                  <SelectItem value="lease">عقد إيجار</SelectItem>
                  <SelectItem value="other">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="document_number">رقم الوثيقة</Label>
              <Input
                id="document_number"
                value={formData.document_number}
                onChange={(e) => setFormData({ ...formData, document_number: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="issue_date">تاريخ الإصدار</Label>
              <Input
                id="issue_date"
                type="date"
                value={formData.issue_date}
                onChange={(e) => setFormData({ ...formData, issue_date: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="expiry_date">تاريخ الانتهاء</Label>
              <Input
                id="expiry_date"
                type="date"
                value={formData.expiry_date}
                onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="file">رفع ملف</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="file"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                  className="flex-1"
                />
                <Upload className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className="text-xs text-muted-foreground">PDF, JPG, PNG (max 5MB)</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">ملاحظات</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              إلغاء
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "جاري الحفظ..." : document ? "تحديث" : "إضافة"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
