import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";

interface MaintenanceDialogProps {
  isOpen: boolean;
  onClose: () => void;
  maintenance: any | null;
  onSuccess: () => void;
}

const maintenanceTypes = [
  "Oil Change",
  "Tire Rotation",
  "Brake Service",
  "Engine Repair",
  "Transmission Service",
  "AC Service",
  "Battery Replacement",
  "Other"
];

export const MaintenanceDialog = ({ isOpen, onClose, maintenance, onSuccess }: MaintenanceDialogProps) => {
  const [formData, setFormData] = useState({
    vehicle_id: "",
    maintenance_type: "",
    maintenance_date: new Date().toISOString().split('T')[0],
    cost: "",
    mileage: "",
    performed_by: "",
    description: "",
    next_maintenance_date: ""
  });

  const [vehicles, setVehicles] = useState<any[]>([]);

  useEffect(() => {
    fetchVehicles();
  }, []);

  useEffect(() => {
    if (maintenance) {
      setFormData({
        vehicle_id: maintenance.vehicle_id || "",
        maintenance_type: maintenance.maintenance_type || "",
        maintenance_date: maintenance.maintenance_date?.split('T')[0] || new Date().toISOString().split('T')[0],
        cost: maintenance.cost?.toString() || "",
        mileage: maintenance.mileage?.toString() || "",
        performed_by: maintenance.performed_by || "",
        description: maintenance.description || "",
        next_maintenance_date: maintenance.next_maintenance_date?.split('T')[0] || ""
      });
    } else {
      setFormData({
        vehicle_id: "",
        maintenance_type: "",
        maintenance_date: new Date().toISOString().split('T')[0],
        cost: "",
        mileage: "",
        performed_by: "",
        description: "",
        next_maintenance_date: ""
      });
    }
  }, [maintenance]);

  const fetchVehicles = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("vehicles")
      .select("*")
      .eq("user_id", user.id)
      .order("plate_number");

    setVehicles(data || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: profile } = await supabase
      .from("profiles")
      .select("organization_id")
      .eq("id", user.id)
      .single();

    const payload = {
      vehicle_id: formData.vehicle_id,
      maintenance_type: formData.maintenance_type,
      maintenance_date: formData.maintenance_date,
      cost: formData.cost ? parseFloat(formData.cost) : null,
      mileage: formData.mileage ? parseInt(formData.mileage) : null,
      performed_by: formData.performed_by || null,
      description: formData.description || null,
      next_maintenance_date: formData.next_maintenance_date || null,
      user_id: user.id,
      organization_id: profile?.organization_id
    };

    if (maintenance) {
      await supabase
        .from("vehicle_maintenance")
        .update(payload)
        .eq("id", maintenance.id);
    } else {
      await supabase
        .from("vehicle_maintenance")
        .insert(payload);
    }

    onSuccess();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{maintenance ? "Edit Maintenance Record" : "Add Maintenance Record"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="vehicle_id">Vehicle *</Label>
            <Select
              value={formData.vehicle_id}
              onValueChange={(value) => setFormData({ ...formData, vehicle_id: value })}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select vehicle" />
              </SelectTrigger>
              <SelectContent>
                {vehicles.map((vehicle) => (
                  <SelectItem key={vehicle.id} value={vehicle.id}>
                    {vehicle.plate_number} - {vehicle.make} {vehicle.model}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maintenance_type">Type *</Label>
              <Select
                value={formData.maintenance_type}
                onValueChange={(value) => setFormData({ ...formData, maintenance_type: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {maintenanceTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="maintenance_date">Date *</Label>
              <Input
                id="maintenance_date"
                type="date"
                value={formData.maintenance_date}
                onChange={(e) => setFormData({ ...formData, maintenance_date: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cost">Cost</Label>
              <Input
                id="cost"
                type="number"
                step="0.01"
                value={formData.cost}
                onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="mileage">Mileage</Label>
              <Input
                id="mileage"
                type="number"
                value={formData.mileage}
                onChange={(e) => setFormData({ ...formData, mileage: e.target.value })}
                placeholder="Current mileage"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="performed_by">Performed By</Label>
            <Input
              id="performed_by"
              value={formData.performed_by}
              onChange={(e) => setFormData({ ...formData, performed_by: e.target.value })}
              placeholder="Mechanic/Workshop name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="next_maintenance_date">Next Maintenance Date</Label>
            <Input
              id="next_maintenance_date"
              type="date"
              value={formData.next_maintenance_date}
              onChange={(e) => setFormData({ ...formData, next_maintenance_date: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Maintenance details..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              {maintenance ? "Update" : "Add"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};