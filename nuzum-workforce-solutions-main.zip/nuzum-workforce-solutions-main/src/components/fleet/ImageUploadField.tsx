import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { X, Upload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ImageUploadFieldProps {
  label: string;
  existingImages?: string[];
  onImagesChange: (images: string[]) => void;
  bucketName?: string;
  folderPath: string;
  maxImages?: number;
}

export const ImageUploadField = ({
  label,
  existingImages = [],
  onImagesChange,
  bucketName = "vehicle-documents",
  folderPath,
  maxImages = 10,
}: ImageUploadFieldProps) => {
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);
  const [images, setImages] = useState<string[]>(existingImages);
  const [previewUrls, setPreviewUrls] = useState<{ [key: string]: string }>({});

  // Generate preview URLs for existing images
  useState(() => {
    const urls: { [key: string]: string } = {};
    existingImages.forEach((path) => {
      const { data } = supabase.storage.from(bucketName).getPublicUrl(path);
      urls[path] = data.publicUrl;
    });
    setPreviewUrls(urls);
  });

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (images.length + files.length > maxImages) {
      toast({
        title: "تحذير",
        description: `الحد الأقصى ${maxImages} صور`,
        variant: "destructive",
      });
      return;
    }

    setUploading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const uploadedPaths: string[] = [];

      for (const file of Array.from(files)) {
        // Validate file type
        if (!file.type.startsWith("image/")) {
          toast({
            title: "خطأ",
            description: "الرجاء اختيار ملفات صور فقط",
            variant: "destructive",
          });
          continue;
        }

        // Validate file size (5MB max)
        if (file.size > 5 * 1024 * 1024) {
          toast({
            title: "خطأ",
            description: "حجم الصورة يجب أن لا يتجاوز 5 ميجابايت",
            variant: "destructive",
          });
          continue;
        }

        const fileExt = file.name.split(".").pop();
        const fileName = `${folderPath}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

        const { error } = await supabase.storage.from(bucketName).upload(fileName, file);

        if (error) throw error;

        uploadedPaths.push(fileName);

        // Generate preview URL
        const { data } = supabase.storage.from(bucketName).getPublicUrl(fileName);
        setPreviewUrls((prev) => ({ ...prev, [fileName]: data.publicUrl }));
      }

      const newImages = [...images, ...uploadedPaths];
      setImages(newImages);
      onImagesChange(newImages);

      toast({
        title: "نجاح",
        description: `تم رفع ${uploadedPaths.length} صورة بنجاح`,
      });
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveImage = async (imagePath: string) => {
    try {
      // Only delete from storage if it's not an existing image
      if (!existingImages.includes(imagePath)) {
        const { error } = await supabase.storage.from(bucketName).remove([imagePath]);
        if (error) throw error;
      }

      const newImages = images.filter((img) => img !== imagePath);
      setImages(newImages);
      onImagesChange(newImages);

      const newPreviewUrls = { ...previewUrls };
      delete newPreviewUrls[imagePath];
      setPreviewUrls(newPreviewUrls);

      toast({
        title: "نجاح",
        description: "تم حذف الصورة",
      });
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex items-center gap-2">
        <Input
          type="file"
          accept="image/*"
          multiple
          onChange={handleFileChange}
          disabled={uploading || images.length >= maxImages}
          className="cursor-pointer"
        />
        <Button
          type="button"
          variant="outline"
          size="icon"
          disabled={uploading || images.length >= maxImages}
        >
          <Upload className="h-4 w-4" />
        </Button>
      </div>

      {images.length > 0 && (
        <div className="grid grid-cols-4 gap-2 mt-2">
          {images.map((imagePath) => (
            <div key={imagePath} className="relative group">
              <img
                src={previewUrls[imagePath]}
                alt="Preview"
                className="w-full h-24 object-cover rounded border"
              />
              <Button
                type="button"
                variant="destructive"
                size="icon"
                className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => handleRemoveImage(imagePath)}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <p className="text-sm text-muted-foreground">
        {images.length}/{maxImages} صور • الحد الأقصى 5 ميجابايت لكل صورة
      </p>
    </div>
  );
};
