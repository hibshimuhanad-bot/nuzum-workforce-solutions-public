import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useOrganization } from "@/hooks/useOrganization";
import * as XLSX from "xlsx";
import { Upload, Download, FileSpreadsheet } from "lucide-react";

interface ProjectVehicleImportExportProps {
  projectId: string;
  onImportComplete?: () => void;
}

export function ProjectVehicleImportExport({ projectId, onImportComplete }: ProjectVehicleImportExportProps) {
  const { organizationId } = useOrganization();
  const [importing, setImporting] = useState(false);

  const handleExportTemplate = () => {
    const templateData = [{
      "رقم اللوحة": "",
      "الصانع": "",
      "الموديل": "",
      "السنة": "",
      "اللون": "",
      "رقم الشاصي VIN": "",
      "تاريخ التسجيل (YYYY-MM-DD)": "",
      "تاريخ انتهاء التأمين (YYYY-MM-DD)": "",
      "الكيلومترات الحالية": "",
      "الحالة": "active",
      "ملاحظات": ""
    }];
    
    const ws = XLSX.utils.json_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "قالب السيارات");
    XLSX.writeFile(wb, "vehicle_template.xlsx");
    toast.success("تم تحميل قالب السيارات");
  };

  const handleExportVehicles = async () => {
    try {
      const { data: assignments, error } = await supabase
        .from("vehicle_project_assignments")
        .select(`
          vehicle_id,
          vehicles (
            plate_number,
            make,
            model,
            year,
            color,
            vin,
            registration_date,
            insurance_expiry,
            current_mileage,
            status,
            notes
          )
        `)
        .eq("project_id", projectId)
        .eq("organization_id", organizationId);

      if (error) throw error;

      if (!assignments || assignments.length === 0) {
        toast.error("لا توجد سيارات في هذا المشروع");
        return;
      }

      const exportData = assignments.map((assignment: any) => {
        const vehicle = assignment.vehicles;
        return {
          "رقم اللوحة": vehicle.plate_number,
          "الصانع": vehicle.make,
          "الموديل": vehicle.model,
          "السنة": vehicle.year,
          "اللون": vehicle.color || "",
          "رقم الشاصي VIN": vehicle.vin || "",
          "تاريخ التسجيل": vehicle.registration_date?.split('T')[0] || "",
          "تاريخ انتهاء التأمين": vehicle.insurance_expiry?.split('T')[0] || "",
          "الكيلومترات الحالية": vehicle.current_mileage || 0,
          "الحالة": vehicle.status,
          "ملاحظات": vehicle.notes || ""
        };
      });

      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "السيارات");
      XLSX.writeFile(wb, `project_vehicles_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success(`تم تصدير ${exportData.length} سيارة بنجاح`);
    } catch (error: any) {
      toast.error("حدث خطأ أثناء التصدير: " + error.message);
    }
  };

  const handleImportVehicles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImporting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || !organizationId) {
        toast.error("يجب تسجيل الدخول أولاً");
        return;
      }

      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      if (jsonData.length === 0) {
        toast.error("الملف فارغ");
        return;
      }

      // Validate and prepare data
      const vehiclesToImport = jsonData.map((row: any) => {
        const plateNumber = row["رقم اللوحة"]?.toString().trim();
        const make = row["الصانع"]?.toString().trim();
        const model = row["الموديل"]?.toString().trim();
        const year = parseInt(row["السنة"]);

        if (!plateNumber || !make || !model || !year) {
          throw new Error("يجب أن تحتوي جميع الصفوف على: رقم اللوحة، الصانع، الموديل، والسنة");
        }

        return {
          plate_number: plateNumber,
          make,
          model,
          year,
          color: row["اللون"]?.toString().trim() || null,
          vin: row["رقم الشاصي VIN"]?.toString().trim() || null,
          registration_date: row["تاريخ التسجيل (YYYY-MM-DD)"] || row["تاريخ التسجيل"] || new Date().toISOString(),
          insurance_expiry: row["تاريخ انتهاء التأمين (YYYY-MM-DD)"] || row["تاريخ انتهاء التأمين"] || null,
          current_mileage: parseInt(row["الكيلومترات الحالية"]) || 0,
          status: (row["الحالة"] || "active") as "active" | "maintenance" | "retired",
          notes: row["ملاحظات"]?.toString().trim() || null,
          organization_id: organizationId,
          user_id: user.id
        };
      });

      // Check for existing vehicles
      const plateNumbers = vehiclesToImport.map(v => v.plate_number);
      const { data: existingVehicles, error: checkError } = await supabase
        .from("vehicles")
        .select("id, plate_number")
        .eq("organization_id", organizationId)
        .in("plate_number", plateNumbers);

      if (checkError) throw checkError;

      const existingPlates = new Set(existingVehicles?.map(v => v.plate_number) || []);
      const newVehicles = vehiclesToImport.filter(v => !existingPlates.has(v.plate_number));
      const existingVehicleIds = existingVehicles?.map(v => v.id) || [];

      let newVehicleIds: string[] = [];

      // Insert new vehicles
      if (newVehicles.length > 0) {
        const { data: insertedVehicles, error: insertError } = await supabase
          .from("vehicles")
          .insert(newVehicles)
          .select("id");

        if (insertError) throw insertError;
        newVehicleIds = insertedVehicles?.map(v => v.id) || [];
      }

      // Combine all vehicle IDs
      const allVehicleIds = [...existingVehicleIds, ...newVehicleIds];

      // Create project assignments
      const assignments = allVehicleIds.map(vehicleId => ({
        project_id: projectId,
        vehicle_id: vehicleId,
        organization_id: organizationId,
        user_id: user.id,
        assigned_date: new Date().toISOString()
      }));

      const { error: assignError } = await supabase
        .from("vehicle_project_assignments")
        .insert(assignments);

      if (assignError) throw assignError;

      toast.success(
        `تم استيراد ${allVehicleIds.length} سيارة بنجاح:\n` +
        `• ${newVehicles.length} سيارات جديدة تم إضافتها\n` +
        `• ${existingVehicleIds.length} سيارات موجودة تم ربطها بالمشروع\n\n` +
        `⚠️ يمكنك رفع الصور لاحقاً من صفحة تفاصيل السيارة`,
        { duration: 6000 }
      );

      if (onImportComplete) {
        onImportComplete();
      }

      // Reset input
      e.target.value = "";
    } catch (error: any) {
      toast.error("حدث خطأ أثناء الاستيراد: " + error.message);
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <Label htmlFor="import-vehicles" className="sr-only">استيراد سيارات</Label>
          <Input
            id="import-vehicles"
            type="file"
            accept=".xlsx,.xls"
            onChange={handleImportVehicles}
            disabled={importing}
            className="hidden"
          />
          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={() => document.getElementById("import-vehicles")?.click()}
            disabled={importing}
          >
            <Upload className="h-4 w-4 ml-2" />
            {importing ? "جاري الاستيراد..." : "استيراد سيارات"}
          </Button>
        </div>

        <Button
          type="button"
          variant="outline"
          className="w-full"
          onClick={handleExportTemplate}
        >
          <FileSpreadsheet className="h-4 w-4 ml-2" />
          تحميل القالب
        </Button>

        <Button
          type="button"
          variant="outline"
          className="w-full"
          onClick={handleExportVehicles}
        >
          <Download className="h-4 w-4 ml-2" />
          تصدير السيارات
        </Button>
      </div>
    </div>
  );
}