import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, Calendar, Wrench } from "lucide-react";
import { format, differenceInDays, addMonths } from "date-fns";

export const FleetAlerts = () => {
  const { data: vehicles } = useQuery({
    queryKey: ["vehicles_alerts"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("vehicles")
        .select("*")
        .eq("user_id", user.id);

      return data || [];
    },
  });

  const { data: maintenanceRecords } = useQuery({
    queryKey: ["maintenance_alerts"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data } = await supabase
        .from("vehicle_maintenance")
        .select(`
          *,
          vehicles (
            plate_number,
            make,
            model
          )
        `)
        .eq("user_id", user.id)
        .not("next_maintenance_date", "is", null);

      return data || [];
    },
  });

  const today = new Date();
  const alerts: any[] = [];

  // Check insurance expiry
  vehicles?.forEach(vehicle => {
    if (vehicle.insurance_expiry) {
      const expiryDate = new Date(vehicle.insurance_expiry);
      const daysUntilExpiry = differenceInDays(expiryDate, today);

      if (daysUntilExpiry <= 30 && daysUntilExpiry >= 0) {
        alerts.push({
          type: "warning",
          title: "Insurance Expiring Soon",
          description: `${vehicle.plate_number} insurance expires in ${daysUntilExpiry} days (${format(expiryDate, "MMM dd, yyyy")})`,
          icon: AlertTriangle,
          severity: daysUntilExpiry <= 7 ? "high" : "medium"
        });
      } else if (daysUntilExpiry < 0) {
        alerts.push({
          type: "error",
          title: "Insurance Expired",
          description: `${vehicle.plate_number} insurance expired ${Math.abs(daysUntilExpiry)} days ago`,
          icon: AlertTriangle,
          severity: "critical"
        });
      }
    }
  });

  // Check upcoming maintenance
  maintenanceRecords?.forEach(record => {
    if (record.next_maintenance_date) {
      const maintenanceDate = new Date(record.next_maintenance_date);
      const daysUntilMaintenance = differenceInDays(maintenanceDate, today);

      if (daysUntilMaintenance <= 14 && daysUntilMaintenance >= 0) {
        alerts.push({
          type: "info",
          title: "Maintenance Due Soon",
          description: `${record.vehicles?.plate_number} - ${record.maintenance_type} due in ${daysUntilMaintenance} days (${format(maintenanceDate, "MMM dd, yyyy")})`,
          icon: Wrench,
          severity: daysUntilMaintenance <= 3 ? "medium" : "low"
        });
      } else if (daysUntilMaintenance < 0) {
        alerts.push({
          type: "warning",
          title: "Maintenance Overdue",
          description: `${record.vehicles?.plate_number} - ${record.maintenance_type} overdue by ${Math.abs(daysUntilMaintenance)} days`,
          icon: Wrench,
          severity: "high"
        });
      }
    }
  });

  // Sort alerts by severity
  const severityOrder: any = { critical: 0, high: 1, medium: 2, low: 3 };
  alerts.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);

  if (alerts.length === 0) {
    return (
      <Card className="p-6">
        <div className="text-center text-muted-foreground">
          <Calendar className="h-12 w-12 mx-auto mb-2 opacity-50" />
          <p>No alerts at this time. All vehicles are in good standing!</p>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold flex items-center gap-2">
        <AlertTriangle className="h-6 w-6" />
        Fleet Alerts
      </h2>
      <div className="space-y-3">
        {alerts.map((alert, index) => (
          <Alert 
            key={index}
            variant={alert.type === "error" ? "destructive" : "default"}
            className={
              alert.severity === "critical" ? "border-red-500" :
              alert.severity === "high" ? "border-orange-500" :
              alert.severity === "medium" ? "border-yellow-500" :
              "border-blue-500"
            }
          >
            <alert.icon className="h-4 w-4" />
            <AlertTitle>{alert.title}</AlertTitle>
            <AlertDescription>{alert.description}</AlertDescription>
          </Alert>
        ))}
      </div>
    </div>
  );
};