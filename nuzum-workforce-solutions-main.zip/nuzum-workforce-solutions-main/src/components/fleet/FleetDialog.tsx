import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ImageUploadField } from "./ImageUploadField";

interface FleetDialogProps {
  isOpen: boolean;
  onClose: () => void;
  vehicle: any;
  onSuccess: () => void;
}

export default function FleetDialog({
  isOpen,
  onClose,
  vehicle,
  onSuccess,
}: FleetDialogProps) {
  const [formData, setFormData] = useState({
    plate_number: "",
    make: "",
    model: "",
    year: new Date().getFullYear(),
    color: "",
    vin: "",
    registration_date: new Date().toISOString().split("T")[0],
    insurance_expiry: "",
    status: "active",
    current_mileage: "0",
    notes: "",
  });
  const [vehicleImages, setVehicleImages] = useState<string[]>([]);

  useEffect(() => {
    if (vehicle) {
      setFormData({
        plate_number: vehicle.plate_number,
        make: vehicle.make,
        model: vehicle.model,
        year: vehicle.year,
        color: vehicle.color || "",
        vin: vehicle.vin || "",
        registration_date: vehicle.registration_date.split("T")[0],
        insurance_expiry: vehicle.insurance_expiry
          ? vehicle.insurance_expiry.split("T")[0]
          : "",
        status: vehicle.status,
        current_mileage: vehicle.current_mileage.toString(),
        notes: vehicle.notes || "",
      });
      setVehicleImages(vehicle.images || []);
    }
  }, [vehicle]);

  const [userId, setUserId] = useState<string>("");

  useEffect(() => {
    const getUserId = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) setUserId(user.id);
    };
    getUserId();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: session } = await supabase.auth.getSession();
    if (!session?.session?.user?.id) return;

    const payload = {
      ...formData,
      year: parseInt(formData.year.toString()),
      current_mileage: parseInt(formData.current_mileage),
      insurance_expiry: formData.insurance_expiry || null,
      status: formData.status as "active" | "maintenance" | "retired",
      images: vehicleImages,
      user_id: session.session.user.id,
    };

    if (vehicle) {
      const { error } = await supabase
        .from("vehicles")
        .update(payload)
        .eq("id", vehicle.id);

      if (!error) {
        onSuccess();
        onClose();
      }
    } else {
      const { error } = await supabase.from("vehicles").insert([payload]);

      if (!error) {
        onSuccess();
        onClose();
      }
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{vehicle ? "Edit Vehicle" : "Add Vehicle"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="plate_number">Plate Number *</Label>
              <Input
                value={formData.plate_number}
                onChange={(e) =>
                  setFormData({ ...formData, plate_number: e.target.value })
                }
                required
              />
            </div>

            <div>
              <Label htmlFor="make">Make *</Label>
              <Input
                value={formData.make}
                onChange={(e) =>
                  setFormData({ ...formData, make: e.target.value })
                }
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="model">Model *</Label>
              <Input
                value={formData.model}
                onChange={(e) =>
                  setFormData({ ...formData, model: e.target.value })
                }
                required
              />
            </div>

            <div>
              <Label htmlFor="year">Year *</Label>
              <Input
                type="number"
                value={formData.year}
                onChange={(e) =>
                  setFormData({ ...formData, year: parseInt(e.target.value) })
                }
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="color">Color</Label>
              <Input
                value={formData.color}
                onChange={(e) =>
                  setFormData({ ...formData, color: e.target.value })
                }
              />
            </div>

            <div>
              <Label htmlFor="vin">VIN</Label>
              <Input
                value={formData.vin}
                onChange={(e) =>
                  setFormData({ ...formData, vin: e.target.value })
                }
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="registration_date">Registration Date *</Label>
              <Input
                type="date"
                value={formData.registration_date}
                onChange={(e) =>
                  setFormData({ ...formData, registration_date: e.target.value })
                }
                required
              />
            </div>

            <div>
              <Label htmlFor="insurance_expiry">Insurance Expiry</Label>
              <Input
                type="date"
                value={formData.insurance_expiry}
                onChange={(e) =>
                  setFormData({ ...formData, insurance_expiry: e.target.value })
                }
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) =>
                  setFormData({ ...formData, status: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="retired">Retired</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="current_mileage">Current Mileage (km)</Label>
              <Input
                type="number"
                value={formData.current_mileage}
                onChange={(e) =>
                  setFormData({ ...formData, current_mileage: e.target.value })
                }
              />
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) =>
                setFormData({ ...formData, notes: e.target.value })
              }
              rows={3}
            />
          </div>

          <ImageUploadField
            label="صور المركبة"
            existingImages={vehicleImages}
            onImagesChange={setVehicleImages}
            folderPath={`${userId}/vehicles/${vehicle?.id || 'new'}`}
            maxImages={10}
          />

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">{vehicle ? "Update" : "Add"} Vehicle</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
