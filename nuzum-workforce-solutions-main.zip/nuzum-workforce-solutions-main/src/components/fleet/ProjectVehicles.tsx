import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useOrganization } from "@/hooks/useOrganization";
import { ProjectVehicleImportExport } from "./ProjectVehicleImportExport";
import { Separator } from "@/components/ui/separator";

interface ProjectVehiclesProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  project: any;
}

export function ProjectVehicles({ open, onOpenChange, project }: ProjectVehiclesProps) {
  const { organizationId } = useOrganization();
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState("");
  const [assignedDate, setAssignedDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [notes, setNotes] = useState("");

  const { data: assignments, refetch } = useQuery({
    queryKey: ["vehicle_project_assignments", project.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vehicle_project_assignments")
        .select(`
          *,
          vehicles (
            id,
            make,
            model,
            plate_number
          )
        `)
        .eq("project_id", project.id)
        .order("assigned_date", { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: open && !!project.id,
  });

  const { data: availableVehicles } = useQuery({
    queryKey: ["available_vehicles", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vehicles")
        .select("*")
        .eq("organization_id", organizationId)
        .eq("status", "active");

      if (error) throw error;
      return data;
    },
    enabled: open && !!organizationId,
  });

  const handleAddAssignment = async () => {
    if (!selectedVehicle || !assignedDate) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || !organizationId) {
        toast.error("يجب تسجيل الدخول أولاً");
        return;
      }

      const { error } = await supabase
        .from("vehicle_project_assignments")
        .insert([{
          vehicle_id: selectedVehicle,
          project_id: project.id,
          assigned_date: assignedDate,
          end_date: endDate || null,
          notes,
          organization_id: organizationId,
          user_id: user.id,
        }]);

      if (error) throw error;
      
      toast.success("تم تعيين السيارة للمشروع بنجاح");
      setShowAddForm(false);
      setSelectedVehicle("");
      setAssignedDate("");
      setEndDate("");
      setNotes("");
      refetch();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleRemoveAssignment = async (id: string) => {
    if (!confirm("هل أنت متأكد من إزالة هذه السيارة من المشروع؟")) return;

    try {
      const { error } = await supabase
        .from("vehicle_project_assignments")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast.success("تم إزالة السيارة من المشروع");
      refetch();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>سيارات المشروع: {project.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <ProjectVehicleImportExport 
            projectId={project.id} 
            onImportComplete={refetch}
          />

          <Separator />

          {!showAddForm ? (
            <Button onClick={() => setShowAddForm(true)}>
              <Plus className="h-4 w-4 ml-2" />
              تعيين سيارة للمشروع
            </Button>
          ) : (
            <div className="border rounded-lg p-4 space-y-4">
              <h3 className="font-semibold">تعيين سيارة جديدة</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>السيارة *</Label>
                  <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر السيارة" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableVehicles?.map((vehicle) => (
                        <SelectItem key={vehicle.id} value={vehicle.id}>
                          {vehicle.make} {vehicle.model} - {vehicle.plate_number}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>تاريخ التعيين *</Label>
                  <Input
                    type="date"
                    value={assignedDate}
                    onChange={(e) => setAssignedDate(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>تاريخ الإنهاء</Label>
                  <Input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>ملاحظات</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={handleAddAssignment}>إضافة</Button>
                <Button variant="outline" onClick={() => setShowAddForm(false)}>إلغاء</Button>
              </div>
            </div>
          )}

          {assignments && assignments.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>السيارة</TableHead>
                  <TableHead>رقم اللوحة</TableHead>
                  <TableHead>تاريخ التعيين</TableHead>
                  <TableHead>تاريخ الإنهاء</TableHead>
                  <TableHead>ملاحظات</TableHead>
                  <TableHead>الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assignments.map((assignment: any) => (
                  <TableRow key={assignment.id}>
                    <TableCell>
                      {assignment.vehicles.make} {assignment.vehicles.model}
                    </TableCell>
                    <TableCell>{assignment.vehicles.plate_number}</TableCell>
                    <TableCell>
                      {new Date(assignment.assigned_date).toLocaleDateString('ar-SA')}
                    </TableCell>
                    <TableCell>
                      {assignment.end_date ? new Date(assignment.end_date).toLocaleDateString('ar-SA') : "مستمر"}
                    </TableCell>
                    <TableCell>{assignment.notes || "-"}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveAssignment(assignment.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد سيارات معينة لهذا المشروع
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}