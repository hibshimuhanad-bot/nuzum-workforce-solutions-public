import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FuelDialog } from "./FuelDialog";
import { Plus, Fuel } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export const FuelList = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedFuelLog, setSelectedFuelLog] = useState<any>(null);
  const { toast } = useToast();

  const { data: fuelLogs, isLoading, refetch } = useQuery({
    queryKey: ["fuel_logs"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from("fuel_logs")
        .select(`
          *,
          vehicles (
            plate_number,
            make,
            model
          )
        `)
        .eq("user_id", user.id)
        .order("fuel_date", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const handleEdit = (fuelLog: any) => {
    setSelectedFuelLog(fuelLog);
    setIsDialogOpen(true);
  };

  const handleAdd = () => {
    setSelectedFuelLog(null);
    setIsDialogOpen(true);
  };

  if (isLoading) {
    return <div>Loading fuel logs...</div>;
  }

  const totalCost = fuelLogs?.reduce((sum, log) => sum + (log.cost || 0), 0) || 0;
  const totalLiters = fuelLogs?.reduce((sum, log) => sum + (log.liters || 0), 0) || 0;
  const avgPricePerLiter = totalLiters > 0 ? totalCost / totalLiters : 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Fuel className="h-6 w-6" />
            Fuel Logs
          </h2>
          <p className="text-muted-foreground">Track fuel consumption and costs</p>
        </div>
        <Button onClick={handleAdd}>
          <Plus className="mr-2 h-4 w-4" />
          Add Fuel Log
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Total Logs</div>
          <div className="text-2xl font-bold">{fuelLogs?.length || 0}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Total Cost</div>
          <div className="text-2xl font-bold">{totalCost.toFixed(2)} SAR</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Total Liters</div>
          <div className="text-2xl font-bold">{totalLiters.toFixed(2)} L</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Avg Price/Liter</div>
          <div className="text-2xl font-bold">{avgPricePerLiter.toFixed(2)} SAR</div>
        </Card>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Vehicle</TableHead>
              <TableHead>Liters</TableHead>
              <TableHead>Cost</TableHead>
              <TableHead>Price/L</TableHead>
              <TableHead>Mileage</TableHead>
              <TableHead>Station</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {fuelLogs && fuelLogs.length > 0 ? (
              fuelLogs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell>{format(new Date(log.fuel_date), "MMM dd, yyyy")}</TableCell>
                  <TableCell>
                    {log.vehicles?.plate_number}<br />
                    <span className="text-sm text-muted-foreground">
                      {log.vehicles?.make} {log.vehicles?.model}
                    </span>
                  </TableCell>
                  <TableCell>{log.liters} L</TableCell>
                  <TableCell>{log.cost} SAR</TableCell>
                  <TableCell>{(log.cost / log.liters).toFixed(2)} SAR</TableCell>
                  <TableCell>{log.mileage.toLocaleString()}</TableCell>
                  <TableCell>{log.station_name || '-'}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => handleEdit(log)}>
                      Edit
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center text-muted-foreground">
                  No fuel logs found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>

      <FuelDialog
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        fuelLog={selectedFuelLog}
        onSuccess={() => {
          refetch();
          toast({
            title: "Success",
            description: "Fuel log saved successfully",
          });
        }}
      />
    </div>
  );
};