import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { ImageUploadField } from "./ImageUploadField";

interface MaintenanceItem {
  item_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  notes: string;
}

interface EnhancedMaintenanceDialogProps {
  isOpen: boolean;
  onClose: () => void;
  maintenance?: any;
  onSuccess: () => void;
}

export const EnhancedMaintenanceDialog = ({
  isOpen,
  onClose,
  maintenance,
  onSuccess,
}: EnhancedMaintenanceDialogProps) => {
  const { toast } = useToast();
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [workshops, setWorkshops] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    vehicle_id: "",
    maintenance_type: "",
    maintenance_category: "corrective",
    maintenance_date: "",
    next_maintenance_date: "",
    mileage: "",
    city: "",
    cost: "",
    workshop_id: "",
    invoice_number: "",
    status: "pending",
    rating: "",
    performed_by: "",
    description: "",
  });
  const [items, setItems] = useState<MaintenanceItem[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [beforePhotos, setBeforePhotos] = useState<string[]>([]);
  const [afterPhotos, setAfterPhotos] = useState<string[]>([]);
  const [userId, setUserId] = useState<string>("");

  useEffect(() => {
    const getUserId = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) setUserId(user.id);
    };
    getUserId();
    fetchVehicles();
    fetchWorkshops();
  }, []);

  useEffect(() => {
    if (maintenance) {
      setFormData({
        vehicle_id: maintenance.vehicle_id || "",
        maintenance_type: maintenance.maintenance_type || "",
        maintenance_category: maintenance.maintenance_category || "corrective",
        maintenance_date: maintenance.maintenance_date?.split("T")[0] || "",
        next_maintenance_date: maintenance.next_maintenance_date?.split("T")[0] || "",
        mileage: maintenance.mileage || "",
        city: maintenance.city || "",
        cost: maintenance.cost || "",
        workshop_id: maintenance.workshop_id || "",
        invoice_number: maintenance.invoice_number || "",
        status: maintenance.status || "pending",
        rating: maintenance.rating || "",
        performed_by: maintenance.performed_by || "",
        description: maintenance.description || "",
      });
      setBeforePhotos(maintenance.before_photos || []);
      setAfterPhotos(maintenance.after_photos || []);
    }
  }, [maintenance]);

  const fetchVehicles = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("vehicles")
      .select("*")
      .eq("user_id", user.id);

    if (data) setVehicles(data);
  };

  const fetchWorkshops = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("maintenance_workshops")
      .select("*")
      .eq("user_id", user.id);

    if (data) setWorkshops(data);
  };

  const addItem = () => {
    setItems([...items, { item_name: "", quantity: 1, unit_price: 0, total_price: 0, notes: "" }]);
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const updateItem = (index: number, field: keyof MaintenanceItem, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    
    if (field === "quantity" || field === "unit_price") {
      newItems[index].total_price = newItems[index].quantity * newItems[index].unit_price;
    }
    
    setItems(newItems);
  };

  const calculateTotalCost = () => {
    return items.reduce((sum, item) => sum + item.total_price, 0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate workshop is selected
    if (!formData.workshop_id) {
      toast({
        title: "خطأ",
        description: "يجب اختيار ورشة الصيانة",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data: profile } = await supabase
        .from("profiles")
        .select("organization_id")
        .eq("id", user.id)
        .single();

      if (!profile?.organization_id) throw new Error("Organization not found");

      const totalCost = items.length > 0 ? calculateTotalCost() : parseFloat(formData.cost) || 0;

      const maintenanceData = {
        vehicle_id: formData.vehicle_id,
        maintenance_type: formData.maintenance_type,
        maintenance_category: formData.maintenance_category,
        maintenance_date: formData.maintenance_date,
        next_maintenance_date: formData.next_maintenance_date || null,
        mileage: formData.mileage ? parseInt(formData.mileage) : null,
        city: formData.city || null,
        cost: totalCost,
        workshop_id: formData.workshop_id,
        invoice_number: formData.invoice_number || null,
        status: formData.status,
        rating: formData.rating ? parseInt(formData.rating) : null,
        performed_by: formData.performed_by || null,
        description: formData.description || null,
        parts_details: items as any,
        before_photos: beforePhotos,
        after_photos: afterPhotos,
        organization_id: profile.organization_id,
        user_id: user.id,
      };

      let maintenanceId = maintenance?.id;

      if (maintenance) {
        const { error } = await supabase
          .from("vehicle_maintenance")
          .update(maintenanceData)
          .eq("id", maintenance.id);

        if (error) throw error;
      } else {
        const { data: newMaintenance, error } = await supabase
          .from("vehicle_maintenance")
          .insert([maintenanceData])
          .select()
          .single();

        if (error) throw error;
        maintenanceId = newMaintenance.id;
      }

      // Save maintenance items
      if (items.length > 0 && maintenanceId) {
        // Delete old items if updating
        if (maintenance) {
          await supabase
            .from("maintenance_items")
            .delete()
            .eq("maintenance_id", maintenanceId);
        }

        // Insert new items
        const itemsData = items.map(item => ({
          maintenance_id: maintenanceId,
          item_name: item.item_name,
          quantity: item.quantity,
          unit_price: item.unit_price,
          total_price: item.total_price,
          notes: item.notes || null,
          organization_id: profile.organization_id,
          user_id: user.id,
        }));

        const { error: itemsError } = await supabase
          .from("maintenance_items")
          .insert(itemsData);

        if (itemsError) throw itemsError;
      }

      onSuccess();
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{maintenance ? "تعديل الصيانة" : "إضافة صيانة جديدة"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="vehicle_id">المركبة *</Label>
              <Select
                value={formData.vehicle_id}
                onValueChange={(value) => setFormData({ ...formData, vehicle_id: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر المركبة" />
                </SelectTrigger>
                <SelectContent>
                  {vehicles.map((vehicle) => (
                    <SelectItem key={vehicle.id} value={vehicle.id}>
                      {vehicle.plate_number} - {vehicle.make} {vehicle.model}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="maintenance_type">نوع الصيانة *</Label>
              <Input
                id="maintenance_type"
                value={formData.maintenance_type}
                onChange={(e) => setFormData({ ...formData, maintenance_type: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maintenance_category">تصنيف الصيانة *</Label>
              <Select
                value={formData.maintenance_category}
                onValueChange={(value) => setFormData({ ...formData, maintenance_category: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="preventive">وقائية</SelectItem>
                  <SelectItem value="corrective">إصلاحية</SelectItem>
                  <SelectItem value="emergency">طارئة</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">الحالة *</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({ ...formData, status: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">معلقة</SelectItem>
                  <SelectItem value="in_progress">جارية</SelectItem>
                  <SelectItem value="completed">مكتملة</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="maintenance_date">تاريخ الصيانة *</Label>
              <Input
                id="maintenance_date"
                type="date"
                value={formData.maintenance_date}
                onChange={(e) => setFormData({ ...formData, maintenance_date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="next_maintenance_date">تاريخ الصيانة القادمة</Label>
              <Input
                id="next_maintenance_date"
                type="date"
                value={formData.next_maintenance_date}
                onChange={(e) => setFormData({ ...formData, next_maintenance_date: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="mileage">قراءة العداد</Label>
              <Input
                id="mileage"
                type="number"
                value={formData.mileage}
                onChange={(e) => setFormData({ ...formData, mileage: e.target.value })}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="city">المدينة</Label>
              <Input
                id="city"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                placeholder="مثال: الرياض، جدة، الدمام"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="workshop_id">الورشة *</Label>
              <Select
                value={formData.workshop_id}
                onValueChange={(value) => setFormData({ ...formData, workshop_id: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر الورشة" />
                </SelectTrigger>
                <SelectContent>
                  {workshops.length === 0 ? (
                    <div className="p-2 text-sm text-muted-foreground text-center">
                      لا توجد ورش مسجلة
                    </div>
                  ) : (
                    workshops.map((workshop) => (
                      <SelectItem key={workshop.id} value={workshop.id}>
                        {workshop.name}
                        {workshop.rating > 0 && ` - ${'⭐'.repeat(Math.round(workshop.rating))}`}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="invoice_number">رقم الفاتورة</Label>
              <Input
                id="invoice_number"
                value={formData.invoice_number}
                onChange={(e) => setFormData({ ...formData, invoice_number: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="performed_by">اسم الفني</Label>
              <Input
                id="performed_by"
                value={formData.performed_by}
                onChange={(e) => setFormData({ ...formData, performed_by: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="rating">التقييم (1-5)</Label>
              <Input
                id="rating"
                type="number"
                min="1"
                max="5"
                value={formData.rating}
                onChange={(e) => setFormData({ ...formData, rating: e.target.value })}
              />
            </div>

            {items.length === 0 && (
              <div className="space-y-2">
                <Label htmlFor="cost">التكلفة الإجمالية</Label>
                <Input
                  id="cost"
                  type="number"
                  step="0.01"
                  value={formData.cost}
                  onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">الوصف</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label>القطع والمواد المستخدمة</Label>
              <Button type="button" variant="outline" size="sm" onClick={addItem}>
                <Plus className="h-4 w-4 mr-1" />
                إضافة قطعة
              </Button>
            </div>

            {items.map((item, index) => (
              <Card key={index}>
                <CardContent className="pt-4">
                  <div className="grid grid-cols-5 gap-2">
                    <div className="space-y-2">
                      <Label>اسم القطعة</Label>
                      <Input
                        value={item.item_name}
                        onChange={(e) => updateItem(index, "item_name", e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>الكمية</Label>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateItem(index, "quantity", parseFloat(e.target.value) || 0)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>سعر الوحدة</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={item.unit_price}
                        onChange={(e) => updateItem(index, "unit_price", parseFloat(e.target.value) || 0)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>الإجمالي</Label>
                      <Input
                        type="number"
                        value={item.total_price}
                        disabled
                      />
                    </div>
                    <div className="space-y-2 flex items-end">
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        onClick={() => removeItem(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="mt-2">
                    <Input
                      placeholder="ملاحظات"
                      value={item.notes}
                      onChange={(e) => updateItem(index, "notes", e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            ))}

            {items.length > 0 && (
              <div className="text-right font-semibold">
                التكلفة الإجمالية: {calculateTotalCost().toFixed(2)} ر.س
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <ImageUploadField
              label="صور قبل الصيانة 🔧"
              existingImages={beforePhotos}
              onImagesChange={setBeforePhotos}
              folderPath={`${userId}/maintenance/${maintenance?.id || 'new'}/before`}
              maxImages={8}
            />

            <ImageUploadField
              label="صور بعد الصيانة ✅"
              existingImages={afterPhotos}
              onImagesChange={setAfterPhotos}
              folderPath={`${userId}/maintenance/${maintenance?.id || 'new'}/after`}
              maxImages={8}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              إلغاء
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "جاري الحفظ..." : maintenance ? "تحديث" : "إضافة"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
