import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useOrganization } from "@/hooks/useOrganization";
import { ProjectVehicleImportExport } from "./ProjectVehicleImportExport";
import { useQuery } from "@tanstack/react-query";
import { Car } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ProjectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  project?: any;
  onSuccess: () => void;
}

export function ProjectDialog({ open, onOpenChange, project, onSuccess }: ProjectDialogProps) {
  const { organizationId } = useOrganization();
  const [loading, setLoading] = useState(false);

  // Fetch actual vehicle count
  const { data: actualVehicleCount = 0 } = useQuery({
    queryKey: ["project-vehicles-count", project?.id],
    queryFn: async () => {
      if (!project?.id) return 0;
      const { count } = await supabase
        .from("vehicle_project_assignments")
        .select("*", { count: "exact", head: true })
        .eq("project_id", project.id)
        .eq("organization_id", organizationId);
      return count || 0;
    },
    enabled: !!project?.id && !!organizationId,
  });
  const [formData, setFormData] = useState({
    name: project?.name || "",
    description: project?.description || "",
    location: project?.location || "",
    start_date: project?.start_date?.split('T')[0] || "",
    end_date: project?.end_date?.split('T')[0] || "",
    budget: project?.budget || "",
    status: project?.status || "active",
    vehicles_count: project?.vehicles_count || 0,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || !organizationId) {
        toast.error("يجب تسجيل الدخول أولاً");
        return;
      }

      const projectData = {
        ...formData,
        budget: formData.budget ? parseFloat(formData.budget) : null,
        vehicles_count: parseInt(formData.vehicles_count.toString()) || 0,
        organization_id: organizationId,
        user_id: user.id,
      };

      if (project) {
        const { error } = await supabase
          .from("fleet_projects")
          .update(projectData)
          .eq("id", project.id);

        if (error) throw error;
        toast.success("تم تحديث المشروع بنجاح");
      } else {
        const { error } = await supabase
          .from("fleet_projects")
          .insert([projectData]);

        if (error) throw error;
        toast.success("تم إضافة المشروع بنجاح");
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{project ? "تعديل المشروع" : "إضافة مشروع جديد"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">اسم المشروع *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">الموقع</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">الوصف</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="start_date">تاريخ البداية *</Label>
              <Input
                id="start_date"
                type="date"
                value={formData.start_date}
                onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="end_date">تاريخ النهاية</Label>
              <Input
                id="end_date"
                type="date"
                value={formData.end_date}
                onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="budget">الميزانية</Label>
              <Input
                id="budget"
                type="number"
                step="0.01"
                value={formData.budget}
                onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">الحالة *</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">نشط</SelectItem>
                  <SelectItem value="completed">مكتمل</SelectItem>
                  <SelectItem value="on_hold">معلق</SelectItem>
                  <SelectItem value="cancelled">ملغي</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="vehicles_count">عدد السيارات المطلوبة</Label>
            <Input
              id="vehicles_count"
              type="number"
              min="0"
              value={formData.vehicles_count}
              onChange={(e) => setFormData({ ...formData, vehicles_count: parseInt(e.target.value) || 0 })}
            />
            {project && (
              <div className="bg-muted p-3 rounded-md">
                <div className="flex items-center gap-2">
                  <Car className="h-4 w-4" />
                  <p className="text-sm">
                    <strong>السيارات الحالية:</strong>
                  </p>
                  <Badge variant={actualVehicleCount >= formData.vehicles_count ? "default" : "secondary"}>
                    {actualVehicleCount} / {formData.vehicles_count || 0}
                  </Badge>
                </div>
                {actualVehicleCount < formData.vehicles_count && (
                  <p className="text-xs text-orange-600 mt-2">
                    ⚠️ ينقص {formData.vehicles_count - actualVehicleCount} سيارة
                  </p>
                )}
              </div>
            )}
          </div>

          {project && (
            <div className="space-y-2">
              <Label>إدارة السيارات</Label>
              <ProjectVehicleImportExport 
                projectId={project.id} 
                onImportComplete={onSuccess}
              />
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              إلغاء
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "جاري الحفظ..." : project ? "تحديث" : "إضافة"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}