import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, TrendingUp, AlertCircle, CheckCircle, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface AIInsightsProps {
  analytics: any;
}

export const AIInsights = ({ analytics }: AIInsightsProps) => {
  // Generate AI-powered insights based on data patterns
  const generateInsights = () => {
    const insights = [];

    // Payroll trend analysis
    const payrollChange = parseFloat(analytics?.payroll.change || 0);
    if (payrollChange > 10) {
      insights.push({
        type: "warning",
        icon: AlertCircle,
        title: "High Payroll Increase",
        description: `Payroll increased by ${payrollChange}% this month. Consider reviewing recent hires or overtime costs.`,
        recommendation: "Review hiring strategy and overtime policies to maintain cost efficiency.",
        priority: "high"
      });
    } else if (payrollChange > 5) {
      insights.push({
        type: "info",
        icon: Info,
        title: "Moderate Payroll Growth",
        description: `Payroll grew by ${payrollChange}%. This is within normal growth range.`,
        recommendation: "Monitor for continued growth trends over the next quarter.",
        priority: "medium"
      });
    } else if (payrollChange < -5) {
      insights.push({
        type: "warning",
        icon: AlertCircle,
        title: "Payroll Decrease Detected",
        description: `Payroll decreased by ${Math.abs(payrollChange)}%. This may indicate staff reduction.`,
        recommendation: "Ensure adequate staffing levels for operational needs.",
        priority: "high"
      });
    }

    // Leave backlog analysis
    const pendingLeaves = analytics?.leaves.pending || 0;
    if (pendingLeaves > 5) {
      insights.push({
        type: "warning",
        icon: AlertCircle,
        title: "Leave Request Backlog",
        description: `You have ${pendingLeaves} pending leave requests awaiting approval.`,
        recommendation: "Review and process pending leave requests to maintain employee satisfaction.",
        priority: "high"
      });
    }

    // Overtime analysis
    const overtimeHours = analytics?.overtime.hours || 0;
    const avgEmployees = analytics?.employees.active || 1;
    const overtimePerEmployee = overtimeHours / avgEmployees;
    
    if (overtimePerEmployee > 10) {
      insights.push({
        type: "warning",
        icon: AlertCircle,
        title: "High Overtime Detected",
        description: `Average overtime is ${overtimePerEmployee.toFixed(1)} hours per employee this month.`,
        recommendation: "Consider hiring additional staff or redistributing workload to reduce burnout risk.",
        priority: "high"
      });
    }

    // Attendance insights
    const avgWorkHours = parseFloat(analytics?.attendance.avgHours || '0');
    if (avgWorkHours < 7 && avgWorkHours > 0) {
      insights.push({
        type: "info",
        icon: Info,
        title: "Below Average Work Hours",
        description: `Average work hours are ${avgWorkHours} per day, below typical 8-hour standard.`,
        recommendation: "Review attendance policies and employee scheduling.",
        priority: "medium"
      });
    } else if (avgWorkHours > 9) {
      insights.push({
        type: "success",
        icon: CheckCircle,
        title: "High Productivity",
        description: `Employees are averaging ${avgWorkHours} work hours per day.`,
        recommendation: "Monitor for potential overwork and ensure work-life balance.",
        priority: "low"
      });
    }

    // Vehicle utilization
    const vehicleUtilization = analytics?.vehicles.total > 0 
      ? ((analytics?.vehicles.active / analytics?.vehicles.total) * 100)
      : 0;
    
    if (vehicleUtilization < 70 && analytics?.vehicles.total > 0) {
      insights.push({
        type: "info",
        icon: Info,
        title: "Low Fleet Utilization",
        description: `Only ${vehicleUtilization.toFixed(0)}% of your fleet is actively in use.`,
        recommendation: "Consider optimizing fleet size or increasing vehicle assignments.",
        priority: "medium"
      });
    }

    // Workforce growth prediction
    const employeeGrowth = analytics?.employees.total || 0;
    if (employeeGrowth > 0) {
      const predictedGrowth = (employeeGrowth * 0.15).toFixed(0); // 15% growth prediction
      insights.push({
        type: "success",
        icon: TrendingUp,
        title: "Growth Forecast",
        description: `Based on current trends, you may need ${predictedGrowth} additional employees in the next quarter.`,
        recommendation: "Plan recruitment strategy and budget accordingly.",
        priority: "low"
      });
    }

    return insights.length > 0 ? insights : [{
      type: "success",
      icon: CheckCircle,
      title: "All Systems Optimal",
      description: "Your workforce metrics are within healthy ranges. Keep up the good work!",
      recommendation: "Continue monitoring key metrics for any changes.",
      priority: "low"
    }];
  };

  const insights = generateInsights();

  const getAlertVariant = (type: string) => {
    switch (type) {
      case "warning": return "destructive";
      case "success": return "default";
      default: return "default";
    }
  };

  const getPriorityBadge = (priority: string) => {
    const variants: Record<string, "destructive" | "default" | "secondary"> = {
      high: "destructive",
      medium: "default",
      low: "secondary"
    };
    return variants[priority] || "default";
  };

  return (
    <Card className="border-2">
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Brain className="w-5 h-5 text-primary" />
          </div>
          <div>
            <CardTitle>AI-Powered Insights</CardTitle>
            <p className="text-sm text-muted-foreground">Smart recommendations based on your data patterns</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {insights.map((insight, index) => (
          <Alert key={index} variant={getAlertVariant(insight.type)} className="border-2">
            <insight.icon className="h-4 w-4" />
            <AlertDescription>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-semibold">{insight.title}</h4>
                    <Badge variant={getPriorityBadge(insight.priority)}>
                      {insight.priority}
                    </Badge>
                  </div>
                  <p className="text-sm mb-2">{insight.description}</p>
                  <p className="text-sm font-medium">💡 {insight.recommendation}</p>
                </div>
              </div>
            </AlertDescription>
          </Alert>
        ))}
      </CardContent>
    </Card>
  );
};
