import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Bell, AlertTriangle, Info, CheckCircle, Zap } from "lucide-react";

interface SmartNotificationsProps {
  analytics: any;
}

export const SmartNotifications = ({ analytics }: SmartNotificationsProps) => {
  // Generate smart automated alerts
  const generateNotifications = () => {
    const notifications = [];
    const currentDate = new Date();

    // Critical: High pending leaves
    if (analytics?.leaves.pending > 5) {
      notifications.push({
        type: "critical",
        icon: AlertTriangle,
        title: "Action Required",
        message: `${analytics.leaves.pending} leave requests need your approval`,
        action: "Review Requests",
        timestamp: currentDate.toISOString()
      });
    }

    // Warning: High overtime
    const overtimeHours = analytics?.overtime.hours || 0;
    const avgEmployees = analytics?.employees.active || 1;
    if (overtimeHours / avgEmployees > 10) {
      notifications.push({
        type: "warning",
        icon: AlertTriangle,
        title: "High Overtime Alert",
        message: `Overtime is ${(overtimeHours / avgEmployees).toFixed(1)} hours per employee this month`,
        action: "View Details",
        timestamp: currentDate.toISOString()
      });
    }

    // Info: Payroll due
    const daysUntilPayroll = 30 - currentDate.getDate();
    if (daysUntilPayroll <= 5 && daysUntilPayroll > 0) {
      notifications.push({
        type: "info",
        icon: Info,
        title: "Payroll Reminder",
        message: `Payroll processing due in ${daysUntilPayroll} days`,
        action: "Prepare Payroll",
        timestamp: currentDate.toISOString()
      });
    }

    // Success: Attendance compliance
    const attendanceRecords = analytics?.attendance.records || 0;
    const expectedRecords = (analytics?.employees.active || 0) * 20; // ~20 working days
    if (attendanceRecords >= expectedRecords * 0.95) {
      notifications.push({
        type: "success",
        icon: CheckCircle,
        title: "Excellent Attendance",
        message: "95%+ attendance compliance this month",
        action: null,
        timestamp: currentDate.toISOString()
      });
    }

    // Smart: Low vehicle utilization
    const vehicleUtilization = analytics?.vehicles.total > 0 
      ? (analytics?.vehicles.active / analytics?.vehicles.total) * 100
      : 0;
    if (vehicleUtilization < 70 && analytics?.vehicles.total > 5) {
      notifications.push({
        type: "info",
        icon: Zap,
        title: "Fleet Optimization",
        message: `Only ${vehicleUtilization.toFixed(0)}% fleet utilization. Consider reassigning vehicles.`,
        action: "Optimize Fleet",
        timestamp: currentDate.toISOString()
      });
    }

    return notifications;
  };

  const notifications = generateNotifications();

  if (notifications.length === 0) {
    return null;
  }

  const getAlertVariant = (type: string) => {
    switch (type) {
      case "critical": return "destructive";
      case "warning": return "destructive";
      case "success": return "default";
      default: return "default";
    }
  };

  const getBadgeVariant = (type: string): "destructive" | "default" | "secondary" | "outline" => {
    switch (type) {
      case "critical": return "destructive";
      case "warning": return "destructive";
      case "success": return "default";
      default: return "secondary";
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Bell className="w-5 h-5 text-primary" />
        <h3 className="font-semibold">Smart Alerts</h3>
        <Badge variant="secondary">{notifications.length} active</Badge>
      </div>

      <div className="space-y-2">
        {notifications.map((notification, index) => (
          <Alert key={index} variant={getAlertVariant(notification.type)} className="border-2">
            <notification.icon className="h-4 w-4" />
            <AlertDescription>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-sm">{notification.title}</h4>
                    <Badge variant={getBadgeVariant(notification.type)} className="text-xs">
                      {notification.type}
                    </Badge>
                  </div>
                  <p className="text-sm">{notification.message}</p>
                </div>
                {notification.action && (
                  <button className="text-sm font-medium underline whitespace-nowrap">
                    {notification.action}
                  </button>
                )}
              </div>
            </AlertDescription>
          </Alert>
        ))}
      </div>
    </div>
  );
};
