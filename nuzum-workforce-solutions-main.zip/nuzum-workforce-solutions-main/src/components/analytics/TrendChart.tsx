import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, BarChart3, TrendingUp } from "lucide-react";

interface TrendChartProps {
  data: any;
}

export const TrendChart = ({ data }: TrendChartProps) => {
  // Process payroll data for trends
  const processPayrollTrends = () => {
    if (!data?.payroll) return [];
    
    // Group by month
    const monthlyData: Record<string, number> = {};
    data.payroll.forEach((record: any) => {
      const key = `${record.year}-${String(record.month).padStart(2, '0')}`;
      monthlyData[key] = (monthlyData[key] || 0) + parseFloat(record.net_salary || 0);
    });

    return Object.entries(monthlyData)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-6) // Last 6 months
      .map(([key, value]) => ({
        month: key,
        amount: value
      }));
  };

  // Process attendance trends
  const processAttendanceTrends = () => {
    if (!data?.attendance) return [];
    
    // Group by week
    const weeklyData: Record<string, { count: number; hours: number }> = {};
    data.attendance.forEach((record: any) => {
      const date = new Date(record.check_in);
      const weekStart = new Date(date);
      weekStart.setDate(date.getDate() - date.getDay());
      const key = weekStart.toISOString().split('T')[0];
      
      if (!weeklyData[key]) {
        weeklyData[key] = { count: 0, hours: 0 };
      }
      weeklyData[key].count++;
      weeklyData[key].hours += parseFloat(record.work_hours || 0);
    });

    return Object.entries(weeklyData)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-8) // Last 8 weeks
      .map(([key, value]) => ({
        week: key,
        count: value.count,
        avgHours: value.count > 0 ? (value.hours / value.count).toFixed(1) : 0
      }));
  };

  // Process employee growth
  const processEmployeeGrowth = () => {
    if (!data?.employees) return [];
    
    // Group by join month
    const monthlyGrowth: Record<string, number> = {};
    data.employees.forEach((emp: any) => {
      const date = emp.join_date ? new Date(emp.join_date) : new Date(emp.created_at);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      monthlyGrowth[key] = (monthlyGrowth[key] || 0) + 1;
    });

    return Object.entries(monthlyGrowth)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-6)
      .map(([key, value]) => ({
        month: key,
        hires: value
      }));
  };

  const payrollTrends = processPayrollTrends();
  const attendanceTrends = processAttendanceTrends();
  const employeeGrowth = processEmployeeGrowth();

  return (
    <Card className="border-2">
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-primary" />
          </div>
          <div>
            <CardTitle>Trend Analysis</CardTitle>
            <p className="text-sm text-muted-foreground">Historical data patterns and insights</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="payroll" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="payroll">Payroll Trends</TabsTrigger>
            <TabsTrigger value="attendance">Attendance</TabsTrigger>
            <TabsTrigger value="growth">Growth</TabsTrigger>
          </TabsList>

          <TabsContent value="payroll" className="space-y-4">
            {payrollTrends.length > 0 ? (
              <div className="space-y-3">
                {payrollTrends.map((trend, index) => {
                  const maxAmount = Math.max(...payrollTrends.map(t => t.amount));
                  const percentage = (trend.amount / maxAmount) * 100;
                  
                  return (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{trend.month}</span>
                        <span className="font-medium">SAR {trend.amount.toLocaleString()}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <BarChart3 className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No payroll data available yet</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="attendance" className="space-y-4">
            {attendanceTrends.length > 0 ? (
              <div className="space-y-3">
                {attendanceTrends.map((trend, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg border-2">
                    <div>
                      <p className="font-medium">Week of {trend.week}</p>
                      <p className="text-sm text-muted-foreground">{trend.count} records</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">{trend.avgHours}h</p>
                      <p className="text-xs text-muted-foreground">Avg per day</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <LineChart className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No attendance data available yet</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="growth" className="space-y-4">
            {employeeGrowth.length > 0 ? (
              <div className="space-y-3">
                {employeeGrowth.map((trend, index) => {
                  const maxHires = Math.max(...employeeGrowth.map(t => t.hires));
                  const percentage = (trend.hires / maxHires) * 100;
                  
                  return (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{trend.month}</span>
                        <span className="font-medium">{trend.hires} new hires</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-accent to-primary transition-all"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <TrendingUp className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No employee growth data available yet</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};
