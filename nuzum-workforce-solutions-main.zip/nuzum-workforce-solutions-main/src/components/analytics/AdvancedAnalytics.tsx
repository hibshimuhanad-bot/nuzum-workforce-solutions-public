import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, DollarSign, Truck, TrendingUp, AlertTriangle, Clock, Calendar, Award } from "lucide-react";
import { AIInsights } from "./AIInsights";
import { PredictiveMetrics } from "./PredictiveMetrics";
import { TrendChart } from "./TrendChart";
import { SmartNotifications } from "./SmartNotifications";

export const AdvancedAnalytics = () => {
  const { data: analytics, isLoading } = useQuery({
    queryKey: ['advanced-analytics'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Fetch comprehensive analytics data
      const [employees, vehicles, payroll, attendance, leaves, overtime] = await Promise.all([
        supabase.from('employees').select('*').eq('user_id', user.id),
        supabase.from('vehicles').select('*').eq('user_id', user.id),
        supabase.from('payroll_records').select('*').eq('user_id', user.id),
        supabase.from('attendance_records').select('*').eq('user_id', user.id),
        supabase.from('leave_requests').select('*').eq('user_id', user.id),
        supabase.from('overtime_records').select('*').eq('user_id', user.id),
      ]);

      // Calculate KPIs
      const activeEmployees = employees.data?.filter(e => e.status === 'active').length || 0;
      const totalEmployees = employees.data?.length || 0;
      const activeVehicles = vehicles.data?.filter(v => v.status === 'active').length || 0;
      const totalVehicles = vehicles.data?.length || 0;

      // Current month payroll
      const currentDate = new Date();
      const currentMonth = currentDate.getMonth() + 1;
      const currentYear = currentDate.getFullYear();
      const monthlyPayroll = payroll.data
        ?.filter(p => p.month === currentMonth && p.year === currentYear)
        .reduce((sum, p) => sum + (parseFloat(p.net_salary as any) || 0), 0) || 0;

      // Previous month for comparison
      const prevMonth = currentMonth === 1 ? 12 : currentMonth - 1;
      const prevYear = currentMonth === 1 ? currentYear - 1 : currentYear;
      const prevMonthPayroll = payroll.data
        ?.filter(p => p.month === prevMonth && p.year === prevYear)
        .reduce((sum, p) => sum + (parseFloat(p.net_salary as any) || 0), 0) || 0;

      const payrollChange = prevMonthPayroll > 0 
        ? ((monthlyPayroll - prevMonthPayroll) / prevMonthPayroll * 100).toFixed(1)
        : 0;

      // Attendance metrics
      const currentMonthAttendance = attendance.data?.filter(a => {
        const date = new Date(a.check_in);
        return date.getMonth() + 1 === currentMonth && date.getFullYear() === currentYear;
      }) || [];

      const avgWorkHours = currentMonthAttendance.length > 0
        ? (currentMonthAttendance.reduce((sum, a) => sum + (parseFloat(a.work_hours as any) || 0), 0) / currentMonthAttendance.length).toFixed(1)
        : 0;

      // Leave metrics
      const pendingLeaves = leaves.data?.filter(l => l.status === 'pending').length || 0;
      const approvedLeaves = leaves.data?.filter(l => l.status === 'approved' && 
        new Date(l.start_date).getMonth() + 1 === currentMonth).length || 0;

      // Overtime metrics
      const totalOvertimeHours = overtime.data
        ?.filter(o => {
          const date = new Date(o.date);
          return date.getMonth() + 1 === currentMonth && date.getFullYear() === currentYear;
        })
        .reduce((sum, o) => sum + (parseFloat(o.hours as any) || 0), 0) || 0;

      const overtimeAmount = overtime.data
        ?.filter(o => {
          const date = new Date(o.date);
          return date.getMonth() + 1 === currentMonth && date.getFullYear() === currentYear;
        })
        .reduce((sum, o) => sum + (parseFloat(o.amount as any) || 0), 0) || 0;

      return {
        employees: { total: totalEmployees, active: activeEmployees },
        vehicles: { total: totalVehicles, active: activeVehicles },
        payroll: { current: monthlyPayroll, change: payrollChange },
        attendance: { avgHours: avgWorkHours, records: currentMonthAttendance.length },
        leaves: { pending: pendingLeaves, approved: approvedLeaves },
        overtime: { hours: totalOvertimeHours, amount: overtimeAmount },
        rawData: {
          employees: employees.data || [],
          payroll: payroll.data || [],
          attendance: attendance.data || [],
          leaves: leaves.data || [],
        }
      };
    },
    refetchInterval: 30000, // Refresh every 30 seconds for real-time updates
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <CardHeader><div className="h-4 bg-muted rounded w-1/2" /></CardHeader>
              <CardContent><div className="h-8 bg-muted rounded w-3/4" /></CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const stats = [
    {
      title: "Active Employees",
      value: analytics?.employees.active || 0,
      subtitle: `of ${analytics?.employees.total || 0} total`,
      icon: Users,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Monthly Payroll",
      value: `SAR ${(analytics?.payroll.current || 0).toLocaleString()}`,
      subtitle: `${analytics?.payroll.change || 0}% vs last month`,
      icon: DollarSign,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      title: "Active Vehicles",
      value: analytics?.vehicles.active || 0,
      subtitle: `${analytics?.vehicles.total || 0} total fleet`,
      icon: Truck,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Avg Work Hours",
      value: analytics?.attendance.avgHours || 0,
      subtitle: `${analytics?.attendance.records || 0} records this month`,
      icon: Clock,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      title: "Pending Leaves",
      value: analytics?.leaves.pending || 0,
      subtitle: `${analytics?.leaves.approved || 0} approved this month`,
      icon: Calendar,
      color: analytics?.leaves.pending > 5 ? "text-destructive" : "text-primary",
      bgColor: analytics?.leaves.pending > 5 ? "bg-destructive/10" : "bg-primary/10",
    },
    {
      title: "Overtime Hours",
      value: (analytics?.overtime.hours || 0).toFixed(1),
      subtitle: `SAR ${(analytics?.overtime.amount || 0).toLocaleString()} cost`,
      icon: TrendingUp,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Advanced Analytics</h1>
        <p className="text-muted-foreground">Real-time insights and AI-powered predictions for your workforce</p>
      </div>

      {/* Smart Notifications */}
      <SmartNotifications analytics={analytics} />

      {/* Real-time KPI Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {stats.map((stat) => (
          <Card key={stat.title} className="border-2 hover:border-primary/50 transition-all hover:shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <div className={`w-10 h-10 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mb-1">{stat.value}</div>
              <p className="text-sm text-muted-foreground">{stat.subtitle}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* AI Insights */}
      <AIInsights analytics={analytics} />

      {/* Predictive Metrics */}
      <PredictiveMetrics analytics={analytics} />

      {/* Trend Charts */}
      <TrendChart data={analytics?.rawData} />
    </div>
  );
};
