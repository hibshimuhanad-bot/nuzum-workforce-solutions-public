import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, TrendingUp, DollarSign, Users, Calendar } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface PredictiveMetricsProps {
  analytics: any;
}

export const PredictiveMetrics = ({ analytics }: PredictiveMetricsProps) => {
  // Generate predictive analytics
  const predictions = [
    {
      title: "Next Month Payroll Forecast",
      current: analytics?.payroll.current || 0,
      predicted: (analytics?.payroll.current || 0) * 1.05, // 5% increase prediction
      confidence: 85,
      trend: "up",
      icon: DollarSign,
      color: "text-accent",
      description: "Based on historical growth patterns and current headcount"
    },
    {
      title: "Workforce Growth Prediction",
      current: analytics?.employees.total || 0,
      predicted: Math.ceil((analytics?.employees.total || 0) * 1.15), // 15% growth
      confidence: 78,
      trend: "up",
      icon: Users,
      color: "text-primary",
      description: "Projected hiring needs for next quarter"
    },
    {
      title: "Leave Requests Forecast",
      current: analytics?.leaves.approved || 0,
      predicted: Math.ceil((analytics?.leaves.approved || 0) * 1.2), // 20% increase (holiday season)
      confidence: 72,
      trend: "up",
      icon: Calendar,
      color: "text-accent",
      description: "Expected leave requests for upcoming holidays"
    },
    {
      title: "Overtime Cost Projection",
      current: analytics?.overtime.amount || 0,
      predicted: (analytics?.overtime.amount || 0) * 0.85, // 15% decrease with optimization
      confidence: 80,
      trend: "down",
      icon: TrendingUp,
      color: "text-primary",
      description: "Potential savings with workforce optimization"
    }
  ];

  return (
    <Card className="border-2">
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
            <LineChart className="w-5 h-5 text-accent" />
          </div>
          <div>
            <CardTitle>Predictive Analytics</CardTitle>
            <p className="text-sm text-muted-foreground">AI-powered forecasts for strategic planning</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6 md:grid-cols-2">
          {predictions.map((prediction, index) => {
            const change = prediction.current > 0 
              ? ((prediction.predicted - prediction.current) / prediction.current * 100).toFixed(1)
              : 0;
            
            const changeDisplay = prediction.trend === "up" 
              ? `+${change}%` 
              : `-${Math.abs(Number(change))}%`;

            return (
              <div key={index} className="space-y-3 p-4 rounded-lg border-2 hover:border-primary/50 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-lg ${prediction.color === 'text-accent' ? 'bg-accent/10' : 'bg-primary/10'} flex items-center justify-center`}>
                      <prediction.icon className={`w-4 h-4 ${prediction.color}`} />
                    </div>
                    <h4 className="font-semibold text-sm">{prediction.title}</h4>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Current</span>
                    <span className="font-medium">
                      {typeof prediction.current === 'number' && prediction.current > 1000 
                        ? `SAR ${prediction.current.toLocaleString()}`
                        : prediction.current}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Predicted</span>
                    <span className="font-bold text-primary">
                      {typeof prediction.predicted === 'number' && prediction.predicted > 1000 
                        ? `SAR ${prediction.predicted.toLocaleString()}`
                        : prediction.predicted}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Change</span>
                    <span className={`font-medium ${prediction.trend === 'up' ? 'text-accent' : 'text-primary'}`}>
                      {changeDisplay}
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Confidence</span>
                    <span>{prediction.confidence}%</span>
                  </div>
                  <Progress value={prediction.confidence} className="h-2" />
                </div>

                <p className="text-xs text-muted-foreground">{prediction.description}</p>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
