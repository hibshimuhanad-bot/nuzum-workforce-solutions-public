import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, DollarSign, Calendar, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import PayrollDialog from "./PayrollDialog";

export default function PayrollList() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedPayroll, setSelectedPayroll] = useState(null);
  const { toast } = useToast();

  const { data: payrollRecords, isLoading, refetch } = useQuery({
    queryKey: ["payroll-records"],
    queryFn: async () => {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return [];

      const { data, error } = await supabase
        .from("payroll_records")
        .select(`
          *,
          employees (name, email, position)
        `)
        .eq("user_id", session.session.user.id)
        .order("year", { ascending: false })
        .order("month", { ascending: false });

      if (error) throw error;
      return data || [];
    },
  });

  const handleEdit = (payroll: any) => {
    setSelectedPayroll(payroll);
    setIsDialogOpen(true);
  };

  const handleAdd = () => {
    setSelectedPayroll(null);
    setIsDialogOpen(true);
  };

  const getMonthName = (month: number) => {
    const months = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    return months[month - 1];
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Payroll Management</h2>
          <p className="text-muted-foreground">Manage employee salaries and payroll records</p>
        </div>
        <Button onClick={handleAdd}>
          <Plus className="mr-2 h-4 w-4" />
          Process Payroll
        </Button>
      </div>

      <Card className="p-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>
                <User className="inline mr-2 h-4 w-4" />
                Employee
              </TableHead>
              <TableHead>
                <Calendar className="inline mr-2 h-4 w-4" />
                Period
              </TableHead>
              <TableHead>Base Salary</TableHead>
              <TableHead>Allowances</TableHead>
              <TableHead>Deductions</TableHead>
              <TableHead>Overtime</TableHead>
              <TableHead>
                <DollarSign className="inline mr-2 h-4 w-4" />
                Net Salary
              </TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {payrollRecords?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                  No payroll records found. Click "Process Payroll" to create one.
                </TableCell>
              </TableRow>
            ) : (
              payrollRecords?.map((payroll: any) => (
                <TableRow key={payroll.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{payroll.employees.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {payroll.employees.position}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    {getMonthName(payroll.month)} {payroll.year}
                  </TableCell>
                  <TableCell>{payroll.base_salary.toLocaleString()} SAR</TableCell>
                  <TableCell>{payroll.total_allowances.toLocaleString()} SAR</TableCell>
                  <TableCell>{payroll.total_deductions.toLocaleString()} SAR</TableCell>
                  <TableCell>{payroll.overtime_amount.toLocaleString()} SAR</TableCell>
                  <TableCell className="font-bold">
                    {payroll.net_salary.toLocaleString()} SAR
                  </TableCell>
                  <TableCell>
                    <Badge variant={payroll.payment_date ? "default" : "secondary"}>
                      {payroll.payment_date ? "Paid" : "Pending"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(payroll)}
                    >
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      <PayrollDialog
        isOpen={isDialogOpen}
        onClose={() => {
          setIsDialogOpen(false);
          setSelectedPayroll(null);
        }}
        payroll={selectedPayroll}
        onSuccess={() => {
          refetch();
          toast({
            title: "Success",
            description: "Payroll record updated successfully",
          });
        }}
      />
    </div>
  );
}
