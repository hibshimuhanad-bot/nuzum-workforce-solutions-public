import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calculator } from "lucide-react";
import { toast } from "sonner";

interface PayrollDialogProps {
  isOpen: boolean;
  onClose: () => void;
  payroll: any;
  onSuccess: () => void;
}

export default function PayrollDialog({ isOpen, onClose, payroll, onSuccess }: PayrollDialogProps) {
  const [formData, setFormData] = useState({
    employee_id: "",
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    base_salary: "",
    total_allowances: "",
    total_deductions: "",
    overtime_amount: "",
    notes: "",
    gosi_employee: "",
    gosi_company: "",
    occupational_hazard: "",
    unpaid_leave_deduction: "",
  });

  const [isCalculating, setIsCalculating] = useState(false);

  const { data: employees } = useQuery({
    queryKey: ["employees-dropdown"],
    queryFn: async () => {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return [];

      const { data, error } = await supabase
        .from("employees")
        .select("id, name, position")
        .eq("user_id", session.session.user.id)
        .eq("status", "active")
        .order("name");

      if (error) throw error;
      return data || [];
    },
  });

  useEffect(() => {
    if (payroll) {
      setFormData({
        employee_id: payroll.employee_id,
        month: payroll.month,
        year: payroll.year,
        base_salary: payroll.base_salary.toString(),
        total_allowances: payroll.total_allowances.toString(),
        total_deductions: payroll.total_deductions.toString(),
        overtime_amount: payroll.overtime_amount.toString(),
        notes: payroll.notes || "",
        gosi_employee: payroll.gosi_employee?.toString() || "",
        gosi_company: payroll.gosi_company?.toString() || "",
        occupational_hazard: payroll.occupational_hazard?.toString() || "",
        unpaid_leave_deduction: payroll.unpaid_leave_deduction?.toString() || "",
      });
    }
  }, [payroll]);

  const calculateNetSalary = () => {
    const base = parseFloat(formData.base_salary) || 0;
    const allowances = parseFloat(formData.total_allowances) || 0;
    const deductions = parseFloat(formData.total_deductions) || 0;
    const overtime = parseFloat(formData.overtime_amount) || 0;
    const gosiEmployee = parseFloat(formData.gosi_employee) || 0;
    const unpaidLeave = parseFloat(formData.unpaid_leave_deduction) || 0;
    
    return base + allowances + overtime - deductions - gosiEmployee - unpaidLeave;
  };

  const handleAutoCalculate = async () => {
    if (!formData.employee_id) {
      toast.error("خطأ", {
        description: "الرجاء اختيار موظف أولاً",
      });
      return;
    }

    setIsCalculating(true);
    try {
      const { data, error } = await supabase.rpc('auto_calculate_payroll', {
        _employee_id: formData.employee_id,
        _month: formData.month,
        _year: formData.year,
      });

      if (error) throw error;

      if (data && typeof data === 'object') {
        const result = data as any;
        setFormData(prev => ({
          ...prev,
          base_salary: result.base_salary?.toString() || "",
          total_allowances: result.total_allowances?.toString() || "",
          total_deductions: result.total_deductions?.toString() || "",
          overtime_amount: result.overtime_amount?.toString() || "",
          gosi_employee: result.gosi_employee?.toString() || "",
          gosi_company: result.gosi_company?.toString() || "",
          occupational_hazard: result.occupational_hazard?.toString() || "",
          unpaid_leave_deduction: result.unpaid_leave_deduction?.toString() || "",
        }));

        toast.success("تم الحساب بنجاح", {
          description: `الصافي: ${result.net_salary?.toLocaleString()} ريال`,
        });
      }
    } catch (error: any) {
      toast.error("خطأ في الحساب التلقائي", {
        description: error.message,
      });
    } finally {
      setIsCalculating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: session } = await supabase.auth.getSession();
    if (!session?.session?.user?.id) return;

    const netSalary = calculateNetSalary();

    const payload = {
      employee_id: formData.employee_id,
      month: formData.month,
      year: formData.year,
      base_salary: parseFloat(formData.base_salary),
      total_allowances: parseFloat(formData.total_allowances) || 0,
      total_deductions: parseFloat(formData.total_deductions) || 0,
      overtime_amount: parseFloat(formData.overtime_amount) || 0,
      net_salary: netSalary,
      notes: formData.notes,
      user_id: session.session.user.id,
      gosi_employee: parseFloat(formData.gosi_employee) || 0,
      gosi_company: parseFloat(formData.gosi_company) || 0,
      occupational_hazard: parseFloat(formData.occupational_hazard) || 0,
      unpaid_leave_deduction: parseFloat(formData.unpaid_leave_deduction) || 0,
    };

    if (payroll) {
      const { error } = await supabase
        .from("payroll_records")
        .update(payload)
        .eq("id", payroll.id);

      if (!error) {
        toast.success("تم التحديث بنجاح");
        onSuccess();
        onClose();
      }
    } else {
      const { error } = await supabase
        .from("payroll_records")
        .insert([payload]);

      if (!error) {
        toast.success("تمت معالجة الراتب بنجاح");
        onSuccess();
        onClose();
      }
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>
              {payroll ? "تعديل راتب" : "معالجة راتب جديد"}
            </DialogTitle>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleAutoCalculate}
              disabled={isCalculating || !formData.employee_id}
            >
              <Calculator className="h-4 w-4 mr-2" />
              {isCalculating ? "جاري الحساب..." : "حساب تلقائي"}
            </Button>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="employee">الموظف</Label>
              <Select
                value={formData.employee_id}
                onValueChange={(value) => setFormData({ ...formData, employee_id: value })}
                disabled={!!payroll}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر موظف" />
                </SelectTrigger>
                <SelectContent>
                  {employees?.map((emp: any) => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.name} - {emp.position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="month">الشهر</Label>
              <Select
                value={formData.month.toString()}
                onValueChange={(value) => setFormData({ ...formData, month: parseInt(value) })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                    <SelectItem key={m} value={m.toString()}>
                      {new Date(2024, m - 1).toLocaleString("ar", { month: "long" })}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="year">السنة</Label>
              <Input
                type="number"
                value={formData.year}
                onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })}
              />
            </div>

            <div>
              <Label htmlFor="base_salary">الراتب الأساسي (ريال)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.base_salary}
                onChange={(e) => setFormData({ ...formData, base_salary: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="allowances">إجمالي البدلات (ريال)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.total_allowances}
                onChange={(e) => setFormData({ ...formData, total_allowances: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="deductions">إجمالي الخصومات (ريال)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.total_deductions}
                onChange={(e) => setFormData({ ...formData, total_deductions: e.target.value })}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="overtime">الوقت الإضافي (ريال)</Label>
            <Input
              type="number"
              step="0.01"
              value={formData.overtime_amount}
              onChange={(e) => setFormData({ ...formData, overtime_amount: e.target.value })}
            />
          </div>

          <div className="space-y-3 p-4 bg-muted/50 rounded-lg border">
            <h4 className="font-semibold text-sm flex items-center gap-2">
              <span className="h-1 w-1 rounded-full bg-primary" />
              تفاصيل التأمينات الاجتماعية (GOSI)
            </h4>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="gosi_employee" className="text-xs">خصم الموظف (10%)</Label>
                <Input
                  id="gosi_employee"
                  type="number"
                  step="0.01"
                  value={formData.gosi_employee}
                  onChange={(e) => setFormData({ ...formData, gosi_employee: e.target.value })}
                  className="text-sm bg-background"
                />
              </div>

              <div>
                <Label htmlFor="gosi_company" className="text-xs">حصة الشركة (12%)</Label>
                <Input
                  id="gosi_company"
                  type="number"
                  step="0.01"
                  value={formData.gosi_company}
                  onChange={(e) => setFormData({ ...formData, gosi_company: e.target.value })}
                  className="text-sm bg-background"
                />
              </div>

              <div>
                <Label htmlFor="occupational_hazard" className="text-xs">الأخطار المهنية (2%)</Label>
                <Input
                  id="occupational_hazard"
                  type="number"
                  step="0.01"
                  value={formData.occupational_hazard}
                  onChange={(e) => setFormData({ ...formData, occupational_hazard: e.target.value })}
                  className="text-sm bg-background"
                />
              </div>
            </div>
          </div>

          <div>
            <Label htmlFor="unpaid_leave_deduction">خصم الغياب بدون إجازة (ريال)</Label>
            <Input
              type="number"
              step="0.01"
              value={formData.unpaid_leave_deduction}
              onChange={(e) => setFormData({ ...formData, unpaid_leave_deduction: e.target.value })}
            />
          </div>

          <div className="p-4 bg-primary/10 rounded-lg border border-primary/20">
            <div className="text-lg font-bold text-primary">
              صافي الراتب: {calculateNetSalary().toLocaleString()} ريال
            </div>
          </div>

          <div>
            <Label htmlFor="notes">ملاحظات</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              إلغاء
            </Button>
            <Button type="submit">
              {payroll ? "تحديث" : "معالجة"} الراتب
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
