import { ReactNode, useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/usePermissions";
import { useModules, ModuleName } from "@/hooks/useModules";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface Props {
  children: ReactNode;
  requiredPermissions?: string[];
  requiredModule?: ModuleName;
  requireAll?: boolean;
}

export const ProtectedRouteWithPermission = ({
  children,
  requiredPermissions = [],
  requiredModule,
  requireAll = false,
}: Props) => {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const { 
    isSuperAdmin, 
    loading: permLoading,
    hasAnyPermission,
    hasAllPermissions 
  } = usePermissions();
  const { isModuleEnabled, isLoading: moduleLoading, limits } = useModules();
  
  const [hasAccess, setHasAccess] = useState<boolean | null>(null);
  
  // Check permissions
  useEffect(() => {
    const checkAccess = async () => {
      if (authLoading || permLoading || moduleLoading) return;
      
      // Super Admin bypasses everything
      if (isSuperAdmin) {
        setHasAccess(true);
        return;
      }
      
      // Check module access
      if (requiredModule && !isModuleEnabled(requiredModule)) {
        setHasAccess(false);
        toast.error(`الموديول "${requiredModule}" معطّل لمنظمتك`);
        return;
      }
      
      // Check permissions
      if (requiredPermissions.length > 0) {
        const checkFn = requireAll ? hasAllPermissions : hasAnyPermission;
        const result = await checkFn(requiredPermissions);
        setHasAccess(result);
        
        if (!result) {
          toast.error("ليس لديك الصلاحيات المطلوبة للوصول إلى هذه الصفحة");
        }
        return;
      }
      
      setHasAccess(true);
    };
    
    checkAccess();
  }, [
    authLoading, 
    permLoading, 
    moduleLoading, 
    isSuperAdmin, 
    requiredModule, 
    requiredPermissions,
    requireAll,
    isModuleEnabled,
    hasAnyPermission,
    hasAllPermissions
  ]);
  
  // Loading state
  if (authLoading || permLoading || moduleLoading || hasAccess === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  // Authentication check
  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }
  
  // Access denied - module disabled
  if (requiredModule && !isModuleEnabled(requiredModule)) {
    return (
      <div className="p-8 max-w-2xl mx-auto">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>الموديول معطّل</AlertTitle>
          <AlertDescription className="space-y-3">
            <p>هذا الموديول غير مفعّل لمنظمتك حالياً.</p>
            {limits && (
              <div className="text-sm bg-background/50 p-3 rounded-md">
                <strong>الحدود الحالية:</strong>
                <ul className="list-disc list-inside mt-1 space-y-1">
                  <li>عدد الموظفين: {limits.maxEmployees || 'غير محدد'}</li>
                  <li>عدد المركبات: {limits.maxVehicles || 'غير محدد'}</li>
                </ul>
              </div>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => window.location.href = '/settings'}
            >
              طلب تفعيل الموديول
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }
  
  // Access denied - insufficient permissions
  if (!hasAccess) {
    return (
      <div className="p-8 max-w-2xl mx-auto">
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>صلاحيات غير كافية</AlertTitle>
          <AlertDescription>
            <p>ليس لديك الصلاحيات المطلوبة للوصول إلى هذه الصفحة.</p>
            <p className="text-sm mt-2 text-muted-foreground">
              يرجى التواصل مع مدير النظام لطلب الصلاحيات المطلوبة.
            </p>
          </AlertDescription>
        </Alert>
      </div>
    );
  }
  
  return <>{children}</>;
};
