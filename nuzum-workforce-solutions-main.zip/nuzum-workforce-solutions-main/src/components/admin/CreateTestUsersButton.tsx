import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { UserPlus, Loader2 } from "lucide-react";

export const CreateTestUsersButton = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const createTestUsers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-test-users');

      if (error) throw error;

      if (data.success) {
        toast({
          title: "تم إنشاء المستخدمين بنجاح",
          description: `تم إنشاء ${data.results.filter((r: any) => r.status === 'success').length} مستخدمين`,
        });
        
        console.log('Created users:', data.results);
      } else {
        throw new Error(data.error || 'Failed to create users');
      }
    } catch (error: any) {
      console.error('Error creating test users:', error);
      toast({
        title: "خطأ في إنشاء المستخدمين",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      onClick={createTestUsers}
      disabled={loading}
      variant="outline"
      size="sm"
    >
      {loading ? (
        <>
          <Loader2 className="ml-2 h-4 w-4 animate-spin" />
          جاري الإنشاء...
        </>
      ) : (
        <>
          <UserPlus className="ml-2 h-4 w-4" />
          إنشاء مستخدمين تجريبيين
        </>
      )}
    </Button>
  );
};
