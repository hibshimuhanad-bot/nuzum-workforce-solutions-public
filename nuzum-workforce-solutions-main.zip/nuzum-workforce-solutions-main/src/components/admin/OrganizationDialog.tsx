import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

interface OrganizationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  organization?: any;
}

export const OrganizationDialog = ({
  open,
  onOpenChange,
  organization,
}: OrganizationDialogProps) => {
  const queryClient = useQueryClient();
  const { register, handleSubmit, reset, setValue, watch } = useForm({
    defaultValues: {
      name: "",
      owner_email: "",
      phone: "",
      address: "",
      subscription_tier: "free",
      max_employees: 10,
      max_vehicles: 5,
      expires_at: "",
    },
  });

  const subscriptionTier = watch("subscription_tier");

  useEffect(() => {
    if (organization) {
      reset({
        name: organization.name || "",
        owner_email: "",
        phone: organization.phone || "",
        address: organization.address || "",
        subscription_tier: organization.subscription_tier || "free",
        max_employees: organization.max_employees || 10,
        max_vehicles: organization.max_vehicles || 5,
        expires_at: organization.expires_at
          ? new Date(organization.expires_at).toISOString().split("T")[0]
          : "",
      });
    } else {
      reset({
        name: "",
        owner_email: "",
        phone: "",
        address: "",
        subscription_tier: "free",
        max_employees: 10,
        max_vehicles: 5,
        expires_at: "",
      });
    }
  }, [organization, reset]);

  useEffect(() => {
    // Auto-set limits based on subscription tier
    if (subscriptionTier === "free") {
      setValue("max_employees", 10);
      setValue("max_vehicles", 5);
    } else if (subscriptionTier === "premium") {
      setValue("max_employees", 50);
      setValue("max_vehicles", 30);
    } else if (subscriptionTier === "enterprise") {
      setValue("max_employees", 999999);
      setValue("max_vehicles", 999999);
    }
  }, [subscriptionTier, setValue]);

  const createOrUpdateMutation = useMutation({
    mutationFn: async (data: any) => {
      if (organization) {
        // Update existing organization
        const { error } = await supabase
          .from("organizations")
          .update({
            name: data.name,
            phone: data.phone,
            address: data.address,
            subscription_tier: data.subscription_tier,
            max_employees: data.max_employees,
            max_vehicles: data.max_vehicles,
            expires_at: data.expires_at || null,
          })
          .eq("id", organization.id);

        if (error) throw error;
      } else {
        // Create new organization
        // First, create the auth user for the owner
        const { data: authData, error: authError } =
          await supabase.auth.admin.createUser({
            email: data.owner_email,
            email_confirm: true,
          });

        if (authError) throw authError;

        // The trigger handle_new_user will create the organization and profile
        // We just need to update the organization with additional data
        const { data: profile } = await supabase
          .from("profiles")
          .select("organization_id")
          .eq("id", authData.user.id)
          .single();

        if (profile?.organization_id) {
          await supabase
            .from("organizations")
            .update({
              name: data.name,
              phone: data.phone,
              address: data.address,
              subscription_tier: data.subscription_tier,
              max_employees: data.max_employees,
              max_vehicles: data.max_vehicles,
              expires_at: data.expires_at || null,
            })
            .eq("id", profile.organization_id);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organizations-list"] });
      toast.success(
        organization
          ? "تم تحديث المنظمة بنجاح"
          : "تم إنشاء المنظمة بنجاح"
      );
      onOpenChange(false);
      reset();
    },
    onError: (error: any) => {
      toast.error("حدث خطأ: " + error.message);
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {organization ? "تعديل منظمة" : "إضافة منظمة جديدة"}
          </DialogTitle>
        </DialogHeader>

        <form
          onSubmit={handleSubmit((data) => createOrUpdateMutation.mutate(data))}
          className="space-y-4"
        >
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">اسم المنظمة *</Label>
              <Input id="name" {...register("name")} required />
            </div>

            {!organization && (
              <div className="space-y-2">
                <Label htmlFor="owner_email">البريد الإلكتروني للمالك *</Label>
                <Input
                  id="owner_email"
                  type="email"
                  {...register("owner_email")}
                  required
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="phone">رقم الهاتف</Label>
              <Input id="phone" {...register("phone")} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="subscription_tier">نوع الباقة *</Label>
              <Select
                value={subscriptionTier}
                onValueChange={(value) =>
                  setValue("subscription_tier", value)
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="free">مجاني</SelectItem>
                  <SelectItem value="premium">مميز</SelectItem>
                  <SelectItem value="enterprise">مؤسسي</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="max_employees">الحد الأقصى للموظفين</Label>
              <Input
                id="max_employees"
                type="number"
                {...register("max_employees", { valueAsNumber: true })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="max_vehicles">الحد الأقصى للسيارات</Label>
              <Input
                id="max_vehicles"
                type="number"
                {...register("max_vehicles", { valueAsNumber: true })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="expires_at">تاريخ الانتهاء</Label>
              <Input id="expires_at" type="date" {...register("expires_at")} />
            </div>

            <div className="space-y-2 col-span-2">
              <Label htmlFor="address">العنوان</Label>
              <Input id="address" {...register("address")} />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              إلغاء
            </Button>
            <Button type="submit" disabled={createOrUpdateMutation.isPending}>
              {createOrUpdateMutation.isPending
                ? "جاري الحفظ..."
                : organization
                ? "حفظ التغييرات"
                : "إنشاء المنظمة"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
