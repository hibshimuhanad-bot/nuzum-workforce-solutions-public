import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { OrganizationsList } from "./OrganizationsList";
import { CreateTestUsersButton } from "./CreateTestUsersButton";
import { Building2, Users, TrendingUp, AlertCircle } from "lucide-react";

export const SuperAdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("organizations");

  const { data: stats, isLoading } = useQuery({
    queryKey: ["super-admin-stats"],
    queryFn: async () => {
      const { data: orgs, error: orgsError } = await supabase
        .from("organizations")
        .select("*");

      if (orgsError) throw orgsError;

      const activeOrgs = orgs?.filter((o) => o.is_active).length || 0;
      const expiringSoon = orgs?.filter((o) => {
        if (!o.expires_at) return false;
        const daysUntilExpiry = Math.ceil(
          (new Date(o.expires_at).getTime() - new Date().getTime()) /
            (1000 * 60 * 60 * 24)
        );
        return daysUntilExpiry <= 7 && daysUntilExpiry > 0;
      }).length || 0;

      const { data: members } = await supabase
        .from("organization_members")
        .select("id");

      return {
        totalOrgs: orgs?.length || 0,
        activeOrgs,
        totalUsers: members?.length || 0,
        expiringSoon,
      };
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">لوحة Super Admin</h2>
        <p className="text-muted-foreground">إدارة جميع المنظمات والعملاء في النظام</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">إجمالي المنظمات</div>
              <div className="text-3xl font-bold">{stats?.totalOrgs || 0}</div>
            </div>
            <Building2 className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">المنظمات النشطة</div>
              <div className="text-3xl font-bold text-green-600">{stats?.activeOrgs || 0}</div>
            </div>
            <TrendingUp className="h-12 w-12 text-green-600 opacity-50" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">إجمالي المستخدمين</div>
              <div className="text-3xl font-bold">{stats?.totalUsers || 0}</div>
            </div>
            <Users className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">تنتهي قريباً</div>
              <div className="text-3xl font-bold text-orange-600">{stats?.expiringSoon || 0}</div>
            </div>
            <AlertCircle className="h-12 w-12 text-orange-600 opacity-50" />
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold">إدارة المنظمات</h3>
          <CreateTestUsersButton />
        </div>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-1">
            <TabsTrigger value="organizations">قائمة المنظمات</TabsTrigger>
          </TabsList>
          <TabsContent value="organizations" className="mt-6">
            <OrganizationsList />
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
};
