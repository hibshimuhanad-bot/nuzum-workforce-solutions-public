import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, Search, Filter } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function AuditLogViewer() {
  const { organizationId } = useOrganization();
  const [searchTerm, setSearchTerm] = useState("");
  const [entityTypeFilter, setEntityTypeFilter] = useState<string>("all");
  const [actionFilter, setActionFilter] = useState<string>("all");

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["audit_logs", organizationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("audit_logs")
        .select(`
          *,
          profiles:user_id (email)
        `)
        .eq("organization_id", organizationId)
        .order("created_at", { ascending: false })
        .limit(100);

      if (error) throw error;
      return data || [];
    },
    enabled: !!organizationId,
  });

  const filteredLogs = logs.filter((log) => {
    const matchesSearch = searchTerm === "" || 
      log.entity_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesEntityType = entityTypeFilter === "all" || log.entity_type === entityTypeFilter;
    const matchesAction = actionFilter === "all" || log.action === actionFilter;
    
    return matchesSearch && matchesEntityType && matchesAction;
  });

  const getActionBadge = (action: string) => {
    const variants: Record<string, any> = {
      INSERT: { variant: "default", label: "إضافة" },
      UPDATE: { variant: "secondary", label: "تعديل" },
      DELETE: { variant: "destructive", label: "حذف" },
    };
    const config = variants[action] || { variant: "secondary", label: action };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getEntityLabel = (entityType: string) => {
    const labels: Record<string, string> = {
      employees: "موظفين",
      vehicles: "سيارات",
      payroll_records: "رواتب",
      vehicle_maintenance: "صيانة",
      fleet_projects: "مشاريع",
      suppliers: "موردين",
      project_invoices: "فواتير",
      user_roles: "أدوار المستخدمين",
      leave_requests: "طلبات الإجازات",
      attendance_records: "الحضور",
    };
    return labels[entityType] || entityType;
  };

  const exportToCSV = () => {
    const csv = [
      ["التاريخ", "المستخدم", "الإجراء", "النوع", "حساس"].join(","),
      ...filteredLogs.map(log => [
        format(new Date(log.created_at), "yyyy-MM-dd HH:mm:ss"),
        (log.profiles as any)?.email || "غير معروف",
        log.action,
        log.entity_type,
        log.is_sensitive ? "نعم" : "لا"
      ].join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `audit-log-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
  };

  if (isLoading) {
    return <div className="p-8">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <FileText className="h-8 w-8" />
            سجل التدقيق
          </h1>
          <p className="text-muted-foreground mt-2">
            سجل شامل لجميع العمليات في النظام
          </p>
        </div>
        <Button onClick={exportToCSV} variant="outline">
          <Download className="ml-2 h-4 w-4" />
          تصدير CSV
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>الفلترة والبحث</CardTitle>
          <CardDescription>ابحث وفلتر السجلات حسب الحاجة</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="بحث..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            
            <Select value={entityTypeFilter} onValueChange={setEntityTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="نوع الكيان" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الأنواع</SelectItem>
                <SelectItem value="employees">موظفين</SelectItem>
                <SelectItem value="vehicles">سيارات</SelectItem>
                <SelectItem value="payroll_records">رواتب</SelectItem>
                <SelectItem value="vehicle_maintenance">صيانة</SelectItem>
                <SelectItem value="fleet_projects">مشاريع</SelectItem>
                <SelectItem value="suppliers">موردين</SelectItem>
                <SelectItem value="project_invoices">فواتير</SelectItem>
              </SelectContent>
            </Select>

            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger>
                <SelectValue placeholder="نوع الإجراء" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الإجراءات</SelectItem>
                <SelectItem value="INSERT">إضافة</SelectItem>
                <SelectItem value="UPDATE">تعديل</SelectItem>
                <SelectItem value="DELETE">حذف</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>السجلات ({filteredLogs.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>التاريخ</TableHead>
                  <TableHead>المستخدم</TableHead>
                  <TableHead>الإجراء</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>حساس</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <TableRow key={log.id} className={log.is_sensitive ? "bg-destructive/5" : ""}>
                    <TableCell className="font-mono text-sm">
                      {format(new Date(log.created_at), "dd/MM/yyyy HH:mm", { locale: ar })}
                    </TableCell>
                    <TableCell>{(log.profiles as any)?.email || "غير معروف"}</TableCell>
                    <TableCell>{getActionBadge(log.action)}</TableCell>
                    <TableCell>{getEntityLabel(log.entity_type)}</TableCell>
                    <TableCell>
                      {log.is_sensitive && (
                        <Badge variant="destructive">عملية حساسة</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
                {filteredLogs.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground">
                      لا توجد سجلات
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
