import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { usePermissions } from "@/hooks/usePermissions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Shield, Users, Lock, Globe, Building2 } from "lucide-react";

export default function AccessControlPanel() {
  const { organizationId } = useOrganization();
  const { isSuperAdmin } = usePermissions();
  const queryClient = useQueryClient();
  const [selectedRole, setSelectedRole] = useState<string>("employee");
  const [scope, setScope] = useState<"organization" | "global">("organization");

  // Fetch all permissions
  const { data: permissions = [], isLoading: permissionsLoading } = useQuery({
    queryKey: ["permissions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("permissions")
        .select("*")
        .eq("is_active", true)
        .order("category", { ascending: true });

      if (error) throw error;
      return data || [];
    },
  });

  // Fetch role permissions (both global and organization-specific)
  const { data: rolePermissionsData = { global: [], organization: [] } } = useQuery({
    queryKey: ["role_permissions", selectedRole, organizationId, scope],
    queryFn: async () => {
      // Fetch global permissions (organization_id = NULL)
      const { data: globalPerms, error: globalError } = await supabase
        .from("role_permissions")
        .select("permission_id")
        .eq("role", selectedRole as any)
        .is("organization_id", null);

      if (globalError) throw globalError;

      // Fetch organization-specific permissions
      const { data: orgPerms, error: orgError } = await supabase
        .from("role_permissions")
        .select("permission_id")
        .eq("role", selectedRole as any)
        .eq("organization_id", organizationId);

      if (orgError) throw orgError;

      return {
        global: globalPerms?.map(rp => rp.permission_id) || [],
        organization: orgPerms?.map(rp => rp.permission_id) || [],
      };
    },
    enabled: !!selectedRole && (scope === "global" ? isSuperAdmin : !!organizationId),
  });

  const togglePermissionMutation = useMutation({
    mutationFn: async ({ permissionId, hasPermission }: { permissionId: string; hasPermission: boolean }) => {
      const targetOrgId = scope === "global" ? null : organizationId;

      if (hasPermission) {
        // Remove permission
        let query = supabase
          .from("role_permissions")
          .delete()
          .eq("role", selectedRole as any)
          .eq("permission_id", permissionId);
        
        if (targetOrgId === null) {
          query = query.is("organization_id", null);
        } else {
          query = query.eq("organization_id", targetOrgId);
        }
        
        const { error } = await query;
        
        if (error) throw error;
      } else {
        // Add permission
        const { error } = await supabase
          .from("role_permissions")
          .insert({
            role: selectedRole as any,
            permission_id: permissionId,
            organization_id: targetOrgId,
          } as any);
        
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["role_permissions"] });
      toast.success("تم تحديث الصلاحيات");
    },
    onError: () => {
      toast.error("فشل تحديث الصلاحيات");
    },
  });

  const roles = [
    { value: "employee", label: "موظف", icon: Users },
    { value: "manager", label: "مدير", icon: Shield },
    { value: "hr", label: "موارد بشرية", icon: Users },
    { value: "org_admin", label: "مدير المنظمة", icon: Lock },
    ...(isSuperAdmin ? [{ value: "super_admin", label: "Super Admin", icon: Shield }] : []),
  ];

  const groupedPermissions = permissions.reduce((acc, permission) => {
    if (!acc[permission.category]) {
      acc[permission.category] = [];
    }
    acc[permission.category].push(permission);
    return acc;
  }, {} as Record<string, typeof permissions>);

  const categoryLabels: Record<string, string> = {
    employees: "الموظفين",
    fleet: "الفليت",
    system: "النظام",
  };

  // Get permission source (global, org, or none)
  const getPermissionSource = (permissionId: string) => {
    const hasGlobal = rolePermissionsData.global.includes(permissionId);
    const hasOrg = rolePermissionsData.organization.includes(permissionId);
    
    if (hasGlobal && hasOrg) return "both";
    if (hasGlobal) return "global";
    if (hasOrg) return "organization";
    return "none";
  };

  if (permissionsLoading) {
    return <div className="p-8">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Shield className="h-8 w-8" />
          إدارة الصلاحيات
        </h1>
        <p className="text-muted-foreground mt-2">
          تحكم في صلاحيات كل دور في النظام
        </p>
      </div>

      {isSuperAdmin && (
        <Card>
          <CardHeader>
            <CardTitle>نطاق التعديل</CardTitle>
            <CardDescription>
              اختر بين تعديل الصلاحيات العامة (افتراضي لكل المنظمات) أو الخاصة بمنظمتك
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch
                  id="scope-toggle"
                  checked={scope === "global"}
                  onCheckedChange={(checked) => setScope(checked ? "global" : "organization")}
                />
                <Label htmlFor="scope-toggle" className="flex items-center gap-2 cursor-pointer">
                  {scope === "global" ? (
                    <>
                      <Globe className="h-4 w-4" />
                      <span>عام (افتراضي)</span>
                    </>
                  ) : (
                    <>
                      <Building2 className="h-4 w-4" />
                      <span>منظمة</span>
                    </>
                  )}
                </Label>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>اختر الدور</CardTitle>
          <CardDescription>اختر الدور لتعديل صلاحياته</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {roles.map((role) => {
              const Icon = role.icon;
              return (
                <Button
                  key={role.value}
                  variant={selectedRole === role.value ? "default" : "outline"}
                  className="h-20 flex-col gap-2"
                  onClick={() => setSelectedRole(role.value)}
                >
                  <Icon className="h-6 w-6" />
                  <span>{role.label}</span>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>صلاحيات الدور: {roles.find(r => r.value === selectedRole)?.label}</CardTitle>
          <CardDescription>
            حدد الصلاحيات المتاحة لهذا الدور
            {isSuperAdmin && (
              <span className="block mt-1 text-xs">
                🌍 = عام | 🏢 = منظمة | ➕ = كلاهما
              </span>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="employees" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="employees">الموظفين</TabsTrigger>
              <TabsTrigger value="fleet">الفليت</TabsTrigger>
              <TabsTrigger value="system">النظام</TabsTrigger>
            </TabsList>

            {Object.entries(groupedPermissions).map(([category, perms]) => (
              <TabsContent key={category} value={category} className="space-y-4">
                <div className="grid gap-4">
                  {perms.map((permission) => {
                    const source = getPermissionSource(permission.id);
                    const isActive = scope === "global" 
                      ? rolePermissionsData.global.includes(permission.id)
                      : rolePermissionsData.organization.includes(permission.id);
                    
                    return (
                      <div
                        key={permission.id}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <Checkbox
                            checked={isActive}
                            onCheckedChange={() =>
                              togglePermissionMutation.mutate({
                                permissionId: permission.id,
                                hasPermission: isActive,
                              })
                            }
                          />
                          <div>
                            <div className="font-medium">{permission.description}</div>
                            <div className="text-sm text-muted-foreground">
                              {permission.name}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {isSuperAdmin && source !== "none" && (
                            <Badge variant="outline" className="text-xs">
                              {source === "global" && "🌍 عام"}
                              {source === "organization" && "🏢 منظمة"}
                              {source === "both" && "➕ كلاهما"}
                            </Badge>
                          )}
                          {isActive && (
                            <Badge variant="default">مفعّل</Badge>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
