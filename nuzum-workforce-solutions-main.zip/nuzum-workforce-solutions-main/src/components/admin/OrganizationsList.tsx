import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Plus,
  Search,
  Edit,
  Power,
  PowerOff,
  Settings,
  TrendingUp,
  Users,
  Database,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { OrganizationDialog } from "./OrganizationDialog";
import { ModulesSettingsPanel } from "./ModulesSettingsPanel";
import { OrganizationUsersPanel } from "./OrganizationUsersPanel";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export const OrganizationsList = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedOrg, setSelectedOrg] = useState<any>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [modulesDialogOpen, setModulesDialogOpen] = useState(false);
  const [usersDialogOpen, setUsersDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: organizations, isLoading } = useQuery({
    queryKey: ["organizations-list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("organizations_overview")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const { error } = await supabase
        .from("organizations")
        .update({ is_active: !isActive })
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organizations-list"] });
      toast.success("تم تحديث حالة المنظمة بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء تحديث حالة المنظمة");
    },
  });

  const createDemoMutation = useMutation({
    mutationFn: async (orgId: string) => {
      const { data, error } = await supabase.functions.invoke('create-demo-data', {
        body: { organization_id: orgId }
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organizations-list"] });
      toast.success("تم إنشاء بيانات الديمو بنجاح");
    },
    onError: (error: any) => {
      toast.error(error.message || "حدث خطأ أثناء إنشاء بيانات الديمو");
    },
  });

  const deleteDemoMutation = useMutation({
    mutationFn: async (orgId: string) => {
      const { data, error } = await supabase.functions.invoke('delete-demo-data', {
        body: { organization_id: orgId }
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organizations-list"] });
      toast.success("تم حذف بيانات الديمو بنجاح");
    },
    onError: (error: any) => {
      toast.error(error.message || "حدث خطأ أثناء حذف بيانات الديمو");
    },
  });

  const filteredOrgs = organizations?.filter((org) =>
    org.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getSubscriptionColor = (tier: string) => {
    switch (tier) {
      case "free":
        return "secondary";
      case "premium":
        return "default";
      case "enterprise":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const getExpiryStatus = (expiresAt: string | null) => {
    if (!expiresAt) return null;
    const daysUntilExpiry = Math.ceil(
      (new Date(expiresAt).getTime() - new Date().getTime()) /
        (1000 * 60 * 60 * 24)
    );
    
    if (daysUntilExpiry < 0) return { label: "منتهي", variant: "destructive" as const };
    if (daysUntilExpiry <= 7) return { label: `${daysUntilExpiry} أيام`, variant: "outline" as const };
    return null;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <>
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="البحث عن منظمة..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10"
            />
          </div>
          <Button
            onClick={() => {
              setSelectedOrg(null);
              setDialogOpen(true);
            }}
          >
            <Plus className="ml-2 h-4 w-4" />
            إضافة منظمة جديدة
          </Button>
        </div>

        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>اسم المنظمة</TableHead>
                <TableHead>الباقة</TableHead>
                <TableHead>المستخدمين</TableHead>
                <TableHead>الموظفين</TableHead>
                <TableHead>السيارات</TableHead>
                <TableHead>تاريخ الانتهاء</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrgs?.map((org) => {
                const expiryStatus = getExpiryStatus(org.expires_at);
                return (
                  <TableRow key={org.id}>
                    <TableCell className="font-medium">{org.name}</TableCell>
                    <TableCell>
                      <Badge variant={getSubscriptionColor(org.subscription_tier)}>
                        {org.subscription_tier === "free" && "مجاني"}
                        {org.subscription_tier === "premium" && "مميز"}
                        {org.subscription_tier === "enterprise" && "مؤسسي"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span>{org.members_count}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span>
                          {org.employees_count} / {org.max_employees}
                        </span>
                        {org.employees_count >= org.max_employees && (
                          <Badge variant="destructive" className="text-xs">
                            ممتلئ
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span>
                          {org.vehicles_count} / {org.max_vehicles}
                        </span>
                        {org.vehicles_count >= org.max_vehicles && (
                          <Badge variant="destructive" className="text-xs">
                            ممتلئ
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {org.expires_at ? (
                        <div className="flex items-center gap-2">
                          <span className="text-sm">
                            {format(new Date(org.expires_at), "dd/MM/yyyy", {
                              locale: ar,
                            })}
                          </span>
                          {expiryStatus && (
                            <Badge variant={expiryStatus.variant}>
                              {expiryStatus.label}
                            </Badge>
                          )}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">غير محدد</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={org.is_active ? "default" : "secondary"}>
                        {org.is_active ? "نشط" : "معطل"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setSelectedOrg(org);
                            setDialogOpen(true);
                          }}
                          title="تعديل"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setSelectedOrg(org);
                            setUsersDialogOpen(true);
                          }}
                          title="إدارة المستخدمين"
                        >
                          <Users className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setSelectedOrg(org);
                            setModulesDialogOpen(true);
                          }}
                          title="الموديلات"
                        >
                          <Settings className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => createDemoMutation.mutate(org.id)}
                          title="إنشاء ديمو"
                        >
                          <Database className="h-4 w-4 text-blue-600" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            if (confirm("هل أنت متأكد من حذف جميع بيانات الديمو؟")) {
                              deleteDemoMutation.mutate(org.id);
                            }
                          }}
                          title="حذف ديمو"
                        >
                          <Trash2 className="h-4 w-4 text-orange-600" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() =>
                            toggleActiveMutation.mutate({
                              id: org.id,
                              isActive: org.is_active,
                            })
                          }
                          title={org.is_active ? "تعطيل" : "تفعيل"}
                        >
                          {org.is_active ? (
                            <PowerOff className="h-4 w-4 text-destructive" />
                          ) : (
                            <Power className="h-4 w-4 text-green-600" />
                          )}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredOrgs?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8">
                    <p className="text-muted-foreground">لا توجد منظمات</p>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      <OrganizationDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        organization={selectedOrg}
      />

      <ModulesSettingsPanel
        open={modulesDialogOpen}
        onOpenChange={setModulesDialogOpen}
        organization={selectedOrg}
      />

      <OrganizationUsersPanel
        open={usersDialogOpen}
        onOpenChange={setUsersDialogOpen}
        organization={selectedOrg}
      />
    </>
  );
};
