import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import {
  Users,
  Truck,
  Wallet,
  Clock,
  Calendar,
  BarChart3,
  FileText,
} from "lucide-react";

interface ModulesSettingsPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  organization?: any;
}

const modules = [
  {
    key: "employees",
    label: "إدارة الموظفين",
    icon: Users,
    description: "تفعيل موديول الموظفين والرواتب",
  },
  {
    key: "fleet",
    label: "إدارة الأسطول",
    icon: Truck,
    description: "تفعيل موديول السيارات والمشاريع",
  },
  {
    key: "payroll",
    label: "الرواتب",
    icon: Wallet,
    description: "تفعيل موديول إدارة الرواتب",
  },
  {
    key: "attendance",
    label: "الحضور والانصراف",
    icon: Clock,
    description: "تفعيل موديول تسجيل الحضور",
  },
  {
    key: "leave",
    label: "الإجازات",
    icon: Calendar,
    description: "تفعيل موديول طلبات الإجازات",
  },
  {
    key: "analytics",
    label: "التحليلات",
    icon: BarChart3,
    description: "تفعيل موديول التحليلات والإحصائيات",
  },
  {
    key: "reports",
    label: "التقارير",
    icon: FileText,
    description: "تفعيل موديول التقارير",
  },
];

export const ModulesSettingsPanel = ({
  open,
  onOpenChange,
  organization,
}: ModulesSettingsPanelProps) => {
  const queryClient = useQueryClient();
  const [enabledModules, setEnabledModules] = useState<Record<string, boolean>>(
    {}
  );

  useEffect(() => {
    if (organization?.enabled_modules) {
      setEnabledModules(organization.enabled_modules);
    } else {
      // Default: all modules enabled
      const defaults: Record<string, boolean> = {};
      modules.forEach((m) => (defaults[m.key] = true));
      setEnabledModules(defaults);
    }
  }, [organization]);

  const updateModulesMutation = useMutation({
    mutationFn: async (modules: Record<string, boolean>) => {
      const { error } = await supabase
        .from("organizations")
        .update({ enabled_modules: modules })
        .eq("id", organization.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organizations-list"] });
      toast.success("تم تحديث إعدادات الموديلات بنجاح");
      onOpenChange(false);
    },
    onError: () => {
      toast.error("حدث خطأ أثناء تحديث إعدادات الموديلات");
    },
  });

  const handleToggle = (key: string, value: boolean) => {
    setEnabledModules((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    updateModulesMutation.mutate(enabledModules);
  };

  if (!organization) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>إعدادات الموديلات - {organization.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            يمكنك تفعيل أو تعطيل الموديلات المختلفة لهذه المنظمة حسب اشتراكها
          </p>

          <div className="grid gap-4">
            {modules.map((module) => {
              const Icon = module.icon;
              return (
                <Card key={module.key} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <Label
                          htmlFor={module.key}
                          className="text-base font-medium cursor-pointer"
                        >
                          {module.label}
                        </Label>
                        <p className="text-sm text-muted-foreground mt-1">
                          {module.description}
                        </p>
                      </div>
                    </div>
                    <Switch
                      id={module.key}
                      checked={enabledModules[module.key] || false}
                      onCheckedChange={(checked) =>
                        handleToggle(module.key, checked)
                      }
                    />
                  </div>
                </Card>
              );
            })}
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              إلغاء
            </Button>
            <Button
              onClick={handleSave}
              disabled={updateModulesMutation.isPending}
            >
              {updateModulesMutation.isPending ? "جاري الحفظ..." : "حفظ التغييرات"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
