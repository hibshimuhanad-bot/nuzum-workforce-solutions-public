import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Bell, Users, Truck, Settings } from "lucide-react";

const notificationTypes = [
  // Employee notifications
  { type: "employee_created", label: "إضافة موظف جديد", category: "employees", priority: "normal" },
  { type: "employee_updated", label: "تحديث بيانات موظف", category: "employees", priority: "low" },
  { type: "employee_deleted", label: "حذف موظف", category: "employees", priority: "high" },
  { type: "leave_request_created", label: "طلب إجازة جديد", category: "employees", priority: "high" },
  { type: "leave_request_status", label: "تحديث حالة إجازة", category: "employees", priority: "high" },
  { type: "overtime_detected", label: "ساعات إضافية", category: "employees", priority: "normal" },
  { type: "payroll_created", label: "إضافة راتب", category: "employees", priority: "normal" },
  { type: "employee_document_added", label: "مستند موظف جديد", category: "employees", priority: "low" },
  
  // Fleet notifications
  { type: "vehicle_created", label: "إضافة سيارة جديدة", category: "fleet", priority: "normal" },
  { type: "vehicle_assigned", label: "تعيين سيارة لموظف", category: "fleet", priority: "high" },
  { type: "vehicle_returned", label: "استلام سيارة من موظف", category: "fleet", priority: "normal" },
  { type: "maintenance_created", label: "إضافة صيانة", category: "fleet", priority: "normal" },
  { type: "maintenance_status", label: "تحديث حالة صيانة", category: "fleet", priority: "normal" },
  { type: "project_created", label: "إضافة مشروع جديد", category: "fleet", priority: "high" },
  { type: "vehicle_project_assigned", label: "تعيين سيارة لمشروع", category: "fleet", priority: "normal" },
  { type: "supplier_created", label: "إضافة مورد جديد", category: "fleet", priority: "low" },
  { type: "invoice_created", label: "فاتورة جديدة", category: "fleet", priority: "high" },
  { type: "invoice_status", label: "تحديث حالة فاتورة", category: "fleet", priority: "normal" },
  { type: "rental_agreement_created", label: "عقد إيجار جديد", category: "fleet", priority: "high" },
  { type: "vehicle_document_added", label: "وثيقة سيارة جديدة", category: "fleet", priority: "low" },
  
  // System notifications
  { type: "user_role_changed", label: "تغيير دور مستخدم", category: "system", priority: "high" },
  { type: "user_added", label: "إضافة مستخدم جديد", category: "system", priority: "normal" },
  { type: "user_removed", label: "إزالة مستخدم", category: "system", priority: "normal" },
  { type: "expiring_documents", label: "وثائق منتهية الصلاحية", category: "system", priority: "urgent" },
  { type: "upcoming_maintenance", label: "صيانة قادمة", category: "system", priority: "high" },
  { type: "ending_projects", label: "مشاريع قريبة الانتهاء", category: "system", priority: "normal" },
  { type: "overdue_invoices", label: "فواتير متأخرة", category: "system", priority: "urgent" },
  { type: "ending_rentals", label: "عقود إيجار قريبة الانتهاء", category: "system", priority: "high" },
];

export default function NotificationSettingsPanel() {
  const { organizationId } = useOrganization();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: settings = [] } = useQuery({
    queryKey: ["notification_settings", user?.id, organizationId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("notification_settings")
        .select("*")
        .eq("user_id", user?.id)
        .eq("organization_id", organizationId);

      if (error) throw error;
      return data || [];
    },
    enabled: !!user && !!organizationId,
  });

  const toggleSettingMutation = useMutation({
    mutationFn: async ({ type, isEnabled }: { type: string; isEnabled: boolean }) => {
      const existing = settings.find(s => s.notification_type === type);
      
      if (existing) {
        const { error } = await supabase
          .from("notification_settings")
          .update({ is_enabled: !isEnabled })
          .eq("id", existing.id);
        
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("notification_settings")
          .insert({
            user_id: user?.id,
            organization_id: organizationId,
            notification_type: type,
            is_enabled: true,
          });
        
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notification_settings"] });
      toast.success("تم تحديث إعدادات الإشعارات");
    },
    onError: () => {
      toast.error("فشل تحديث الإعدادات");
    },
  });

  const getSetting = (type: string) => {
    const setting = settings.find(s => s.notification_type === type);
    return setting?.is_enabled ?? true; // Default to enabled
  };

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      urgent: "destructive",
      high: "default",
      normal: "secondary",
      low: "outline",
    };
    return colors[priority] || "secondary";
  };

  const groupedNotifications = notificationTypes.reduce((acc, notif) => {
    if (!acc[notif.category]) {
      acc[notif.category] = [];
    }
    acc[notif.category].push(notif);
    return acc;
  }, {} as Record<string, typeof notificationTypes>);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Bell className="h-8 w-8" />
          إعدادات الإشعارات
        </h1>
        <p className="text-muted-foreground mt-2">
          تحكم في الإشعارات التي تريد استلامها
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>أنواع الإشعارات</CardTitle>
          <CardDescription>
            قم بتفعيل أو تعطيل الإشعارات حسب الحاجة
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="employees" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="employees" className="gap-2">
                <Users className="h-4 w-4" />
                الموظفين
              </TabsTrigger>
              <TabsTrigger value="fleet" className="gap-2">
                <Truck className="h-4 w-4" />
                الفليت
              </TabsTrigger>
              <TabsTrigger value="system" className="gap-2">
                <Settings className="h-4 w-4" />
                النظام
              </TabsTrigger>
            </TabsList>

            {Object.entries(groupedNotifications).map(([category, notifs]) => (
              <TabsContent key={category} value={category} className="space-y-4 mt-6">
                {notifs.map((notif) => {
                  const isEnabled = getSetting(notif.type);
                  
                  return (
                    <div
                      key={notif.type}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50 transition-colors"
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <Switch
                          checked={isEnabled}
                          onCheckedChange={() =>
                            toggleSettingMutation.mutate({
                              type: notif.type,
                              isEnabled,
                            })
                          }
                        />
                        <div className="flex-1">
                          <Label className="font-medium cursor-pointer">
                            {notif.label}
                          </Label>
                        </div>
                        <Badge variant={getPriorityColor(notif.priority) as any}>
                          {notif.priority === "urgent" && "عاجل"}
                          {notif.priority === "high" && "عالية"}
                          {notif.priority === "normal" && "عادية"}
                          {notif.priority === "low" && "منخفضة"}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
