import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Search, Edit, Trash2, UserPlus, Shield, User } from "lucide-react";
import { toast } from "sonner";
import { InviteUserDialog } from "./InviteUserDialog";

interface OrganizationUsersPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  organization: any;
}

export const OrganizationUsersPanel = ({
  open,
  onOpenChange,
  organization,
}: OrganizationUsersPanelProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<string>("");
  const queryClient = useQueryClient();

  const { data: users, isLoading } = useQuery({
    queryKey: ["organization-users", organization?.id],
    queryFn: async () => {
      if (!organization?.id) return [];

      const { data, error } = await supabase
        .from("profiles")
        .select(`
          *,
          user_roles(role),
          organization_members(role)
        `)
        .eq("organization_id", organization.id);

      if (error) throw error;
      return data;
    },
    enabled: !!organization?.id && open,
  });

  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      // حذف الدور القديم أولاً
      await supabase
        .from("user_roles")
        .delete()
        .eq("user_id", userId);

      // إضافة الدور الجديد
      const { error } = await supabase
        .from("user_roles")
        .insert({ user_id: userId, role: role as any });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organization-users"] });
      toast.success("تم تحديث صلاحيات المستخدم بنجاح");
      setEditDialogOpen(false);
    },
    onError: () => {
      toast.error("حدث خطأ أثناء تحديث الصلاحيات");
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const { error } = await supabase
        .from("organization_members")
        .delete()
        .eq("user_id", userId)
        .eq("organization_id", organization.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organization-users"] });
      toast.success("تم حذف المستخدم من المنظمة بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء حذف المستخدم");
    },
  });

  const filteredUsers = users?.filter((user) =>
    user.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getRoleBadge = (user: any) => {
    const userRoles = user.user_roles || [];
    const userRole = userRoles.length > 0 ? userRoles[0]?.role : null;
    const orgMembers = user.organization_members || [];
    const orgRole = orgMembers.length > 0 ? orgMembers[0]?.role : null;

    if (userRole === "super_admin") {
      return <Badge variant="destructive">Super Admin</Badge>;
    }
    if (userRole === "org_admin" || orgRole === "owner") {
      return <Badge variant="default">مدير</Badge>;
    }
    return <Badge variant="secondary">موظف</Badge>;
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>إدارة مستخدمي: {organization?.name}</DialogTitle>
            <DialogDescription>
              عرض وتعديل صلاحيات المستخدمين في هذه المنظمة
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="البحث عن مستخدم..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Button
                onClick={() => setInviteDialogOpen(true)}
                size="sm"
              >
                <UserPlus className="ml-2 h-4 w-4" />
                دعوة مستخدم
              </Button>
            </div>

            {isLoading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : (
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>البريد الإلكتروني</TableHead>
                      <TableHead>الصلاحية</TableHead>
                      <TableHead>دور المنظمة</TableHead>
                      <TableHead>الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers?.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">
                          {user.email}
                        </TableCell>
                        <TableCell>{getRoleBadge(user)}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {(() => {
                              const orgMembers = user.organization_members || [];
                              const orgRole = orgMembers.length > 0 ? orgMembers[0]?.role : null;
                              if (orgRole === "owner") return "مالك";
                              if (orgRole === "admin") return "مدير";
                              return "عضو";
                            })()}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setSelectedUser(user);
                                const userRoles = user.user_roles || [];
                                const currentRole = userRoles.length > 0 ? userRoles[0]?.role : "employee";
                                setSelectedRole(currentRole);
                                setEditDialogOpen(true);
                              }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                if (
                                  confirm(
                                    "هل أنت متأكد من حذف هذا المستخدم من المنظمة؟"
                                  )
                                ) {
                                  deleteUserMutation.mutate(user.id);
                                }
                              }}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredUsers?.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-8">
                          <p className="text-muted-foreground">
                            لا يوجد مستخدمين
                          </p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Role Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تعديل صلاحيات المستخدم</DialogTitle>
            <DialogDescription>
              تعديل دور وصلاحيات: {selectedUser?.email}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>الدور</Label>
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="employee">موظف</SelectItem>
                  <SelectItem value="manager">مدير قسم</SelectItem>
                  <SelectItem value="hr">موارد بشرية</SelectItem>
                  <SelectItem value="org_admin">مدير منظمة</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setEditDialogOpen(false)}
              >
                إلغاء
              </Button>
              <Button
                onClick={() => {
                  if (selectedUser) {
                    updateRoleMutation.mutate({
                      userId: selectedUser.id,
                      role: selectedRole,
                    });
                  }
                }}
              >
                حفظ التغييرات
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Invite User Dialog */}
      <InviteUserDialog
        open={inviteDialogOpen}
        onOpenChange={setInviteDialogOpen}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ["organization-users"] });
          setInviteDialogOpen(false);
        }}
      />
    </>
  );
};
