import { ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";

export const AccessDenied = () => {
  const navigate = useNavigate();

  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Card className="p-8 max-w-md text-center space-y-4">
        <ShieldAlert className="h-16 w-16 text-destructive mx-auto" />
        <h2 className="text-2xl font-bold">ممنوع الوصول</h2>
        <p className="text-muted-foreground">
          ليس لديك الصلاحيات اللازمة للوصول إلى هذه الصفحة.
          يرجى التواصل مع مدير النظام للحصول على الصلاحيات المطلوبة.
        </p>
        <div className="space-y-2">
          <Button onClick={() => navigate("/dashboard")} className="w-full">
            العودة إلى لوحة التحكم
          </Button>
          <Button variant="outline" onClick={() => navigate(-1)} className="w-full">
            العودة للصفحة السابقة
          </Button>
        </div>
      </Card>
    </div>
  );
};
