import { ReactNode, useEffect, useState } from "react";
import { usePermissions } from "@/hooks/usePermissions";
import { Loader2 } from "lucide-react";

interface ProtectedComponentProps {
  permission?: string;
  permissions?: string[];
  requireAll?: boolean;
  children: ReactNode;
  fallback?: ReactNode;
  showLoader?: boolean;
}

export const ProtectedComponent = ({
  permission,
  permissions = [],
  requireAll = false,
  children,
  fallback = null,
  showLoader = false,
}: ProtectedComponentProps) => {
  const { hasPermission, hasAnyPermission, hasAllPermissions } = usePermissions();
  const [canAccess, setCanAccess] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const checkAccess = async () => {
      setChecking(true);
      
      try {
        let result = false;
        
        if (permission) {
          result = await hasPermission(permission);
        } else if (permissions.length > 0) {
          if (requireAll) {
            result = await hasAllPermissions(permissions);
          } else {
            result = await hasAnyPermission(permissions);
          }
        }
        
        setCanAccess(result);
      } catch (error) {
        console.error('Error checking access:', error);
        setCanAccess(false);
      } finally {
        setChecking(false);
      }
    };

    checkAccess();
  }, [permission, permissions, requireAll, hasPermission, hasAnyPermission, hasAllPermissions]);

  if (checking && showLoader) {
    return (
      <div className="flex items-center justify-center p-4">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!canAccess) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};
