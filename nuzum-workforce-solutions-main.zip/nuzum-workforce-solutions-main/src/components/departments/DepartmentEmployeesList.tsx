import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Users, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Employee {
  id: string;
  name: string;
  position: string;
  email: string;
  phone: string;
  salary: number;
  status: string;
}

interface Department {
  id: string;
  name: string;
}

interface DepartmentEmployeesListProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  departmentId: string | null;
  departmentName: string;
  organizationId: string;
}

export const DepartmentEmployeesList = ({
  open,
  onOpenChange,
  departmentId,
  departmentName,
  organizationId,
}: DepartmentEmployeesListProps) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<string | null>(null);
  const [targetDepartment, setTargetDepartment] = useState<string>("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && departmentId) {
      fetchEmployees();
      fetchDepartments();
    }
  }, [open, departmentId]);

  const fetchEmployees = async () => {
    const { data } = await supabase
      .from("employees")
      .select("id, name, position, email, phone, salary, status")
      .eq("department_id", departmentId)
      .order("name");
    setEmployees(data || []);
  };

  const fetchDepartments = async () => {
    const { data } = await supabase
      .from("departments")
      .select("id, name")
      .eq("organization_id", organizationId)
      .neq("id", departmentId!)
      .order("name");
    setDepartments(data || []);
  };

  const handleMoveEmployee = async () => {
    if (!selectedEmployee || !targetDepartment) {
      toast({
        title: "خطأ",
        description: "يرجى اختيار موظف وقسم للنقل",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    const { error } = await supabase
      .from("employees")
      .update({ department_id: targetDepartment })
      .eq("id", selectedEmployee);

    if (error) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({ title: "تم نقل الموظف بنجاح" });
      fetchEmployees();
      setSelectedEmployee(null);
      setTargetDepartment("");
    }
    setLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            موظفو قسم {departmentName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {employees.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              لا يوجد موظفون في هذا القسم
            </div>
          ) : (
            <>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>الاسم</TableHead>
                      <TableHead>المنصب</TableHead>
                      <TableHead>البريد الإلكتروني</TableHead>
                      <TableHead>الهاتف</TableHead>
                      <TableHead>الراتب</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead>إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employees.map((emp) => (
                      <TableRow key={emp.id}>
                        <TableCell className="font-medium">{emp.name}</TableCell>
                        <TableCell>{emp.position}</TableCell>
                        <TableCell>{emp.email}</TableCell>
                        <TableCell>{emp.phone}</TableCell>
                        <TableCell>{emp.salary?.toLocaleString("ar-SA")} ر.س</TableCell>
                        <TableCell>
                          <Badge variant={emp.status === "active" ? "default" : "secondary"}>
                            {emp.status === "active" ? "نشط" : "غير نشط"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedEmployee(emp.id)}
                          >
                            نقل
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {selectedEmployee && (
                <div className="p-4 border rounded-lg bg-muted/50 space-y-4">
                  <h3 className="font-semibold">نقل موظف إلى قسم آخر</h3>
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <Select value={targetDepartment} onValueChange={setTargetDepartment}>
                        <SelectTrigger className="bg-background">
                          <SelectValue placeholder="اختر القسم المستهدف" />
                        </SelectTrigger>
                        <SelectContent className="bg-background z-50">
                          {departments.map((dept) => (
                            <SelectItem key={dept.id} value={dept.id}>
                              {dept.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button onClick={handleMoveEmployee} disabled={loading || !targetDepartment}>
                      <ArrowRight className="h-4 w-4 ml-2" />
                      نقل الآن
                    </Button>
                    <Button variant="outline" onClick={() => setSelectedEmployee(null)}>
                      إلغاء
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
