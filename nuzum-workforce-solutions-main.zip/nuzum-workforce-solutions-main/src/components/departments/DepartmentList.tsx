import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { usePermissions } from "@/hooks/usePermissions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2, Edit, Building2, Users, BarChart3, GitBranch, List } from "lucide-react";
import { DepartmentDialog } from "./DepartmentDialog";
import { DepartmentTreeView } from "./DepartmentTreeView";
import { DepartmentStatistics } from "./DepartmentStatistics";
import { DepartmentEmployeesList } from "./DepartmentEmployeesList";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AccessDenied } from "@/components/admin/AccessDenied";

interface Department {
  id: string;
  name: string;
  description?: string;
  manager_id?: string;
  manager?: { name: string };
  employee_count?: number;
}

export const DepartmentList = () => {
  const { organizationId } = useOrganization();
  const { canManageEmployees, canViewDepartments, canManageDepartments } = usePermissions();
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [departmentToDelete, setDepartmentToDelete] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"cards" | "tree" | "stats">("cards");
  const [employeesDialogOpen, setEmployeesDialogOpen] = useState(false);
  const [selectedDeptForEmployees, setSelectedDeptForEmployees] = useState<{id: string, name: string} | null>(null);

  useEffect(() => {
    if (organizationId) {
      fetchDepartments();
    }
  }, [organizationId]);

  const fetchDepartments = async () => {
    setLoading(true);
    try {
      const { data: depts, error } = await supabase
        .from("departments")
        .select("id, name, description, manager_id")
        .eq("organization_id", organizationId)
        .order("name");

      if (error) throw error;

      const deptsWithCount = await Promise.all(
        (depts || []).map(async (dept) => {
          const { count } = await supabase
            .from("employees")
            .select("*", { count: "exact", head: true })
            .eq("department_id", dept.id);

          let managerName = null;
          if (dept.manager_id) {
            const { data: manager } = await supabase
              .from("employees")
              .select("name")
              .eq("id", dept.manager_id)
              .single();
            managerName = manager?.name;
          }

          return {
            ...dept,
            employee_count: count || 0,
            manager: managerName ? { name: managerName } : undefined,
          };
        })
      );

      setDepartments(deptsWithCount);
    } catch (error: any) {
      toast({
        title: "خطأ في تحميل الأقسام",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!departmentToDelete) return;

    try {
      const { error } = await supabase
        .from("departments")
        .delete()
        .eq("id", departmentToDelete);

      if (error) throw error;

      toast({ title: "تم حذف القسم بنجاح" });
      fetchDepartments();
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDeleteDialogOpen(false);
      setDepartmentToDelete(null);
    }
  };

  const handleEdit = (dept: Department) => {
    setSelectedDepartment(dept);
    setDialogOpen(true);
  };

  const handleAdd = () => {
    setSelectedDepartment(null);
    setDialogOpen(true);
  };

  const handleViewEmployees = (dept: Department) => {
    setSelectedDeptForEmployees({ id: dept.id, name: dept.name });
    setEmployeesDialogOpen(true);
  };

  if (!canViewDepartments && !canManageEmployees) {
    return <AccessDenied />;
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Building2 className="h-6 w-6" />
          <h2 className="text-2xl font-bold">الأقسام</h2>
        </div>
        <div className="flex items-center gap-2">
          {(canManageDepartments || canManageEmployees) && (
            <Button onClick={handleAdd}>
              <Plus className="h-4 w-4 ml-2" />
              إضافة قسم
            </Button>
          )}
        </div>
      </div>

      <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "cards" | "tree" | "stats")}>
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="cards">
            <List className="h-4 w-4 ml-2" />
            البطاقات
          </TabsTrigger>
          <TabsTrigger value="tree">
            <GitBranch className="h-4 w-4 ml-2" />
            الهيكل الشجري
          </TabsTrigger>
          <TabsTrigger value="stats">
            <BarChart3 className="h-4 w-4 ml-2" />
            الإحصائيات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="stats" className="mt-6">
          <DepartmentStatistics />
        </TabsContent>

        <TabsContent value="tree" className="mt-6">
          <DepartmentTreeView 
            onSelectDepartment={(id) => {
              const dept = departments.find(d => d.id === id);
              if (dept) handleViewEmployees(dept);
            }}
          />
        </TabsContent>

        <TabsContent value="cards" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {departments.map((dept) => (
              <Card key={dept.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{dept.name}</CardTitle>
                      {dept.description && (
                        <CardDescription className="mt-2">{dept.description}</CardDescription>
                      )}
                    </div>
                    {(canManageDepartments || canManageEmployees) && (
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(dept)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setDepartmentToDelete(dept.id);
                            setDeleteDialogOpen(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {dept.manager?.name && (
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">المدير:</span>
                        <span className="font-medium">{dept.manager.name}</span>
                      </div>
                    )}
                    {dept.employee_count !== undefined && (
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">عدد الموظفين:</span>
                        <span className="font-medium">{dept.employee_count}</span>
                      </div>
                    )}
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full mt-4" 
                    size="sm"
                    onClick={() => handleViewEmployees(dept)}
                  >
                    <Users className="h-4 w-4 ml-2" />
                    عرض الموظفين
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {departments.length === 0 && (
            <div className="text-center p-8 text-muted-foreground">
              لا توجد أقسام. {(canManageDepartments || canManageEmployees) && "قم بإضافة قسم جديد للبدء."}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <DepartmentDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        department={selectedDepartment}
        onSuccess={fetchDepartments}
      />

      {selectedDeptForEmployees && (
        <DepartmentEmployeesList
          open={employeesDialogOpen}
          onOpenChange={setEmployeesDialogOpen}
          departmentId={selectedDeptForEmployees.id}
          departmentName={selectedDeptForEmployees.name}
          organizationId={organizationId!}
        />
      )}

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف هذا القسم؟ لن يتم حذف الموظفين ولكن سيصبحون بدون قسم.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
