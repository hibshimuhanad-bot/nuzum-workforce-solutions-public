import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useOrganization } from "@/hooks/useOrganization";
import { toast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Department {
  id: string;
  name: string;
  description?: string;
  manager_id?: string;
}

interface Employee {
  id: string;
  name: string;
}

interface DepartmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  department?: Department | null;
  onSuccess: () => void;
}

export const DepartmentDialog = ({ open, onOpenChange, department, onSuccess }: DepartmentDialogProps) => {
  const { user } = useAuth();
  const { organizationId } = useOrganization();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    manager_id: "",
    parent_department_id: "",
  });
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (department) {
      setFormData({
        name: department.name || "",
        description: department.description || "",
        manager_id: department.manager_id || "",
        parent_department_id: (department as any).parent_department_id || "",
      });
    } else {
      setFormData({ name: "", description: "", manager_id: "", parent_department_id: "" });
    }
  }, [department, open]);

  useEffect(() => {
    if (open && organizationId) {
      fetchEmployees();
      fetchDepartments();
    }
  }, [open, organizationId]);

  const fetchEmployees = async () => {
    const { data } = await supabase
      .from("employees")
      .select("id, name")
      .eq("organization_id", organizationId)
      .order("name");
    setEmployees(data || []);
  };

  const fetchDepartments = async () => {
    const { data } = await supabase
      .from("departments")
      .select("id, name, parent_department_id")
      .eq("organization_id", organizationId)
      .order("name");
    setDepartments(data || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !organizationId) return;

    setLoading(true);
    try {
      const payload = {
        name: formData.name,
        description: formData.description || null,
        manager_id: formData.manager_id || null,
        parent_department_id: formData.parent_department_id || null,
        organization_id: organizationId,
        user_id: user.id,
      };

      if (department) {
        const { error } = await supabase
          .from("departments")
          .update(payload)
          .eq("id", department.id);
        if (error) throw error;
        toast({ title: "تم تحديث القسم بنجاح" });
      } else {
        const { error } = await supabase
          .from("departments")
          .insert(payload);
        if (error) throw error;
        toast({ title: "تم إضافة القسم بنجاح" });
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{department ? "تعديل القسم" : "إضافة قسم جديد"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">اسم القسم *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>
          <div>
            <Label htmlFor="description">الوصف</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>
          <div>
            <Label htmlFor="parent">القسم الرئيسي</Label>
            <Select 
              value={formData.parent_department_id} 
              onValueChange={(val) => setFormData({ ...formData, parent_department_id: val })}
            >
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="قسم رئيسي (اختياري)" />
              </SelectTrigger>
              <SelectContent className="bg-background z-50">
                <SelectItem value="">لا يوجد - قسم رئيسي</SelectItem>
                {departments
                  .filter(d => d.id !== department?.id)
                  .map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="manager">مدير القسم</Label>
            <Select value={formData.manager_id} onValueChange={(val) => setFormData({ ...formData, manager_id: val })}>
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="اختر مدير القسم" />
              </SelectTrigger>
              <SelectContent className="bg-background z-50">
                <SelectItem value="">بدون مدير</SelectItem>
                {employees.map((emp) => (
                  <SelectItem key={emp.id} value={emp.id}>
                    {emp.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              إلغاء
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "جاري الحفظ..." : "حفظ"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
