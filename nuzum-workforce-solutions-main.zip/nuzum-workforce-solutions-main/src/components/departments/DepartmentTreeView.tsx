import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { Card } from "@/components/ui/card";
import { ChevronDown, ChevronRight, Users, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface DepartmentNode {
  id: string;
  name: string;
  parent_department_id: string | null;
  level: number;
  path: string;
  manager_id: string | null;
  manager_name: string | null;
  employee_count: number;
  active_employee_count: number;
  total_salary_cost: number;
  has_children: boolean;
}

export const DepartmentTreeView = ({ onSelectDepartment }: { onSelectDepartment?: (id: string) => void }) => {
  const { organizationId } = useOrganization();
  const [tree, setTree] = useState<DepartmentNode[]>([]);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (organizationId) {
      fetchTree();
    }
  }, [organizationId]);

  const fetchTree = async () => {
    setLoading(true);
    const { data, error } = await supabase.rpc("get_department_tree", {
      _org_id: organizationId,
    });

    if (!error && data) {
      setTree(data);
      // توسيع الأقسام الرئيسية تلقائياً
      const rootIds = data.filter((d: DepartmentNode) => d.level === 0).map((d: DepartmentNode) => d.id);
      setExpanded(new Set(rootIds));
    }
    setLoading(false);
  };

  const toggleExpand = (id: string) => {
    const newExpanded = new Set(expanded);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpanded(newExpanded);
  };

  const renderNode = (node: DepartmentNode) => {
    const isExpanded = expanded.has(node.id);
    const children = tree.filter((n) => n.parent_department_id === node.id);

    return (
      <div key={node.id} className="mb-2">
        <Card
          className="p-4 hover:shadow-md transition-all cursor-pointer"
          style={{ marginRight: `${node.level * 24}px` }}
          onClick={() => onSelectDepartment?.(node.id)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 flex-1">
              {node.has_children && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleExpand(node.id);
                  }}
                  className="p-0 h-6 w-6"
                >
                  {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                </Button>
              )}
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-lg">{node.name}</h3>
                  <Badge variant="outline">المستوى {node.level}</Badge>
                </div>
                {node.path && (
                  <p className="text-sm text-muted-foreground mt-1">{node.path}</p>
                )}
                <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                  {node.manager_name && (
                    <div className="flex items-center gap-1">
                      <User className="h-4 w-4" />
                      <span>{node.manager_name}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    <span>{node.active_employee_count} موظف نشط</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="text-left">
              <p className="text-sm font-medium">التكلفة الشهرية</p>
              <p className="text-lg font-bold text-primary">
                {node.total_salary_cost.toLocaleString("ar-SA")} ر.س
              </p>
            </div>
          </div>
        </Card>
        {isExpanded && children.length > 0 && (
          <div className="mt-2">
            {children.map((child) => renderNode(child))}
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const rootNodes = tree.filter((n) => n.level === 0);

  return (
    <div className="space-y-4">
      {rootNodes.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">لا توجد أقسام بعد</p>
        </Card>
      ) : (
        rootNodes.map((node) => renderNode(node))
      )}
    </div>
  );
};
