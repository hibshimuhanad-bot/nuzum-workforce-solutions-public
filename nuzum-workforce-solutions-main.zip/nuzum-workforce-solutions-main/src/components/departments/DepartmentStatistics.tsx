import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useOrganization } from "@/hooks/useOrganization";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Building2, DollarSign, TrendingUp, TrendingDown } from "lucide-react";

interface Statistics {
  totalDepartments: number;
  totalEmployees: number;
  activeEmployees: number;
  averageEmployeesPerDept: number;
  totalSalaryCost: number;
  largestDepartment: { name: string; count: number } | null;
  smallestDepartment: { name: string; count: number } | null;
}

export const DepartmentStatistics = () => {
  const { organizationId } = useOrganization();
  const [stats, setStats] = useState<Statistics>({
    totalDepartments: 0,
    totalEmployees: 0,
    activeEmployees: 0,
    averageEmployeesPerDept: 0,
    totalSalaryCost: 0,
    largestDepartment: null,
    smallestDepartment: null,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (organizationId) {
      fetchStatistics();
    }
  }, [organizationId]);

  const fetchStatistics = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("department_statistics")
      .select("*")
      .eq("organization_id", organizationId);

    if (data) {
      const totalDepartments = data.length;
      const totalEmployees = data.reduce((sum, d) => sum + (d.employee_count || 0), 0);
      const activeEmployees = data.reduce((sum, d) => sum + (d.active_employee_count || 0), 0);
      const totalSalaryCost = data.reduce((sum, d) => sum + (d.total_salary_cost || 0), 0);
      const averageEmployeesPerDept = totalDepartments > 0 ? totalEmployees / totalDepartments : 0;

      const sorted = [...data].sort((a, b) => (b.employee_count || 0) - (a.employee_count || 0));
      const largestDepartment = sorted[0] ? { name: sorted[0].name, count: sorted[0].employee_count || 0 } : null;
      const smallestDepartment = sorted[sorted.length - 1] && sorted.length > 1 
        ? { name: sorted[sorted.length - 1].name, count: sorted[sorted.length - 1].employee_count || 0 } 
        : null;

      setStats({
        totalDepartments,
        totalEmployees,
        activeEmployees,
        averageEmployeesPerDept,
        totalSalaryCost,
        largestDepartment,
        smallestDepartment,
      });
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="h-20 bg-muted/50"></CardHeader>
            <CardContent className="h-16 bg-muted/30"></CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">إجمالي الأقسام</CardTitle>
          <Building2 className="h-5 w-5 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{stats.totalDepartments}</div>
          <p className="text-xs text-muted-foreground mt-1">جميع الأقسام في المنظمة</p>
        </CardContent>
      </Card>

      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">إجمالي الموظفين</CardTitle>
          <Users className="h-5 w-5 text-blue-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{stats.totalEmployees}</div>
          <p className="text-xs text-muted-foreground mt-1">
            {stats.activeEmployees} موظف نشط
          </p>
        </CardContent>
      </Card>

      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">متوسط الموظفين/قسم</CardTitle>
          <TrendingUp className="h-5 w-5 text-green-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{stats.averageEmployeesPerDept.toFixed(1)}</div>
          <p className="text-xs text-muted-foreground mt-1">معدل التوزيع</p>
        </CardContent>
      </Card>

      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">إجمالي الرواتب</CardTitle>
          <DollarSign className="h-5 w-5 text-yellow-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">
            {stats.totalSalaryCost.toLocaleString("ar-SA")}
          </div>
          <p className="text-xs text-muted-foreground mt-1">ر.س شهرياً</p>
        </CardContent>
      </Card>

      {stats.largestDepartment && (
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">أكبر قسم</CardTitle>
            <TrendingUp className="h-5 w-5 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.largestDepartment.name}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats.largestDepartment.count} موظف
            </p>
          </CardContent>
        </Card>
      )}

      {stats.smallestDepartment && (
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">أصغر قسم</CardTitle>
            <TrendingDown className="h-5 w-5 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.smallestDepartment.name}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats.smallestDepartment.count} موظف
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
