import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Users, Calendar, Clock, TrendingUp, UserCheck, UserX, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";

export const DepartmentManagerDashboard = () => {
  const { data: currentUser } = useQuery({
    queryKey: ["current-user-dept"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data: employees } = await supabase
        .from("employees")
        .select("department_id")
        .eq("user_id", user.id)
        .single();

      return { ...user, department_id: employees?.department_id };
    },
  });

  const { data: directReports } = useQuery({
    queryKey: ["direct-reports", currentUser?.department_id],
    queryFn: async () => {
      if (!currentUser?.department_id) return [];

      const { data } = await supabase
        .from("employees")
        .select("*")
        .eq("department_id", currentUser.department_id)
        .eq("status", "active");

      return data || [];
    },
    enabled: !!currentUser?.department_id,
  });

  const { data: pendingLeaveRequests } = useQuery({
    queryKey: ["pending-leaves", currentUser?.department_id],
    queryFn: async () => {
      if (!currentUser?.department_id) return [];

      const { data } = await supabase
        .from("leave_requests")
        .select(`
          *,
          employees!inner(department_id, name)
        `)
        .eq("employees.department_id", currentUser.department_id)
        .eq("status", "pending");

      return data || [];
    },
    enabled: !!currentUser?.department_id,
  });

  const { data: todayAttendance } = useQuery({
    queryKey: ["today-attendance", currentUser?.department_id],
    queryFn: async () => {
      if (!currentUser?.department_id) return [];

      const today = new Date().toISOString().split("T")[0];

      const { data } = await supabase
        .from("attendance_records")
        .select(`
          *,
          employees!inner(department_id, name)
        `)
        .eq("employees.department_id", currentUser.department_id)
        .gte("check_in", `${today}T00:00:00`)
        .lte("check_in", `${today}T23:59:59`);

      return data || [];
    },
    enabled: !!currentUser?.department_id,
  });

  // Calculate statistics
  const totalEmployees = directReports?.length || 0;
  const presentToday = todayAttendance?.length || 0;
  const absentToday = totalEmployees - presentToday;
  const pendingLeaves = pendingLeaveRequests?.length || 0;

  const avgWorkHours =
    todayAttendance?.reduce((sum, r) => sum + (r.work_hours || 0), 0) /
      (todayAttendance?.length || 1) || 0;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">لوحة مدير القسم</h2>
        <p className="text-muted-foreground">نظرة عامة على القسم وموظفيك</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">إجمالي الموظفين</div>
              <div className="text-3xl font-bold">{totalEmployees}</div>
              <div className="text-xs text-muted-foreground mt-1">
                موظف في قسمك
              </div>
            </div>
            <Users className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">طلبات الإجازة المعلقة</div>
              <div className="text-3xl font-bold">{pendingLeaves}</div>
              <div className="text-xs text-muted-foreground mt-1">
                تحتاج إلى مراجعة
              </div>
            </div>
            <Calendar className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">الحضور اليوم</div>
              <div className="text-3xl font-bold">{presentToday}</div>
              <div className="text-xs text-muted-foreground mt-1">
                من {totalEmployees} موظف
              </div>
            </div>
            <UserCheck className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">متوسط ساعات العمل</div>
              <div className="text-3xl font-bold">{avgWorkHours.toFixed(1)}</div>
              <div className="text-xs text-muted-foreground mt-1">
                ساعة اليوم
              </div>
            </div>
            <Clock className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Users className="h-5 w-5" />
            الموظفين المباشرين
          </h3>
          <div className="space-y-3">
            {directReports?.slice(0, 5).map((employee) => (
              <div key={employee.id} className="flex justify-between items-center">
                <span className="text-muted-foreground">{employee.name}</span>
                <Badge variant="secondary">{employee.position}</Badge>
              </div>
            ))}
            {directReports && directReports.length > 5 && (
              <div className="text-sm text-muted-foreground text-center pt-2">
                و {directReports.length - 5} موظف آخر
              </div>
            )}
            {directReports?.length === 0 && (
              <div className="text-center py-6 text-muted-foreground">
                لا يوجد موظفين في القسم بعد
              </div>
            )}
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            طلبات الإجازة المعلقة
          </h3>
          <div className="space-y-3">
            {pendingLeaveRequests?.slice(0, 5).map((request: any) => (
              <div key={request.id} className="flex justify-between items-center">
                <div>
                  <span className="text-sm">{request.employees?.name}</span>
                  <div className="text-xs text-muted-foreground">
                    {request.days_count} أيام - {request.leave_type}
                  </div>
                </div>
                <Badge variant="outline">معلق</Badge>
              </div>
            ))}
            {pendingLeaveRequests?.length === 0 && (
              <div className="text-center py-6 text-muted-foreground">
                لا توجد طلبات معلقة
              </div>
            )}
          </div>
        </Card>
      </div>

      {absentToday > 0 && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            هناك {absentToday} موظف غائب اليوم من أصل {totalEmployees} موظف
          </AlertDescription>
        </Alert>
      )}

      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          إحصائيات سريعة
        </h3>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">معدل الحضور:</span>
              <span className="font-semibold">
                {totalEmployees > 0
                  ? ((presentToday / totalEmployees) * 100).toFixed(1)
                  : 0}
                %
              </span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">طلبات الإجازة:</span>
              <span className="font-semibold">{pendingLeaves}</span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">متوسط الساعات:</span>
              <span className="font-semibold">{avgWorkHours.toFixed(1)} ساعة</span>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};