import { ReactNode } from "react";
import { Home, Users, Truck, FileText, Settings, Menu, LogOut, Shield, BarChart3, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/usePermissions";
import { useModules } from "@/hooks/useModules";
import { LanguageToggle } from "@/components/LanguageToggle";

interface DashboardLayoutProps {
  children: ReactNode;
  activeModule: string;
  onModuleChange: (module: string) => void;
}

const DashboardLayout = ({ children, activeModule, onModuleChange }: DashboardLayoutProps) => {
  const { user, signOut } = useAuth();
  const { isSuperAdmin, isAdmin, loading: permissionsLoading } = usePermissions();
  const { accessibleModules } = useModules();
  const navigate = useNavigate();
  
  const allMenuItems = [
    { id: "employees", label: "إدارة الموظفين", icon: Users, module: "employees" as const },
    { id: "fleet", label: "إدارة الفليت", icon: Truck, module: "fleet" as const },
    { id: "reports", label: "التقارير", icon: FileText, module: "reports" as const },
    { id: "analytics", label: "التحليلات", icon: BarChart3, module: "analytics" as const },
  ];

  // Filter menu items based on accessibleModules from useModules hook
  const menuItems = allMenuItems.filter(item => {
    return !item.module || accessibleModules.includes(item.module);
  });

  const Sidebar = () => (
    <div className="h-full flex flex-col bg-gradient-to-b from-background to-muted/20 border-r border-border/50">
      <div className="p-6 border-b border-border/50">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
            <span className="text-primary-foreground font-bold text-2xl">N</span>
          </div>
          <div>
            <span className="text-xl font-bold bg-gradient-primary bg-clip-text text-transparent">Nuzum</span>
            <p className="text-xsmall text-muted-foreground">Business Suite</p>
          </div>
        </Link>
      </div>
      
      <nav className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeModule === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onModuleChange(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group relative overflow-hidden ${
                  isActive
                    ? "bg-gradient-primary text-primary-foreground font-semibold shadow-lg"
                    : "hover:bg-accent/50 text-foreground"
                }`}
              >
                {isActive && (
                  <div className="absolute inset-0 bg-white/10 animate-pulse"></div>
                )}
                <Icon className={`w-5 h-5 relative z-10 ${isActive ? '' : 'group-hover:scale-110 transition-transform'}`} />
                <span className="relative z-10">{item.label}</span>
                {isActive && (
                  <div className="ml-auto w-2 h-2 rounded-full bg-white/80 animate-pulse"></div>
                )}
              </button>
            );
          })}
          
          {!permissionsLoading && isSuperAdmin && (
            <>
              <div className="my-4 border-t border-border/30" />
              <button
                onClick={() => navigate("/super-admin")}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all bg-warning/10 hover:bg-warning/20 text-warning border border-warning/30"
              >
                <Shield className="w-5 h-5" />
                <span className="font-medium">Super Admin</span>
                <Badge variant="outline" className="ml-auto text-xsmall border-warning/50">
                  Admin
                </Badge>
              </button>
            </>
          )}
        </div>
      </nav>

      <div className="p-4 border-t border-border/30 bg-muted/30 space-y-3">
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon"
            className="hover:bg-accent rounded-lg"
          >
            <Bell className="w-4 h-4" />
          </Button>
          <LanguageToggle />
          <Link to="/settings">
            <Button 
              variant="ghost" 
              size="icon"
              className="hover:bg-accent rounded-lg"
              title="Settings"
            >
              <Settings className="w-4 h-4" />
            </Button>
          </Link>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={signOut}
            className="hover:bg-destructive/10 hover:text-destructive rounded-lg"
            title="Sign out"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center gap-3 px-3 py-3 bg-background/50 rounded-xl border border-border/50">
          <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center shadow-md">
            <span className="font-semibold text-primary-foreground">{user?.email?.charAt(0).toUpperCase()}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">{user?.email}</p>
            {isSuperAdmin && (
              <Badge variant="secondary" className="text-xsmall mt-1">Super Admin</Badge>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 border-r">
        <Sidebar />
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col bg-gradient-to-br from-background via-muted/10 to-background">
        {/* Desktop Header */}
        <header className="hidden lg:flex border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-40 px-8 py-4 items-center justify-between shadow-sm">
          <div>
            <h2 className="text-h3 font-bold text-foreground">
              {menuItems.find(item => item.id === activeModule)?.label || 'Dashboard'}
            </h2>
            <p className="text-small text-muted-foreground mt-0.5">Welcome back, manage your business operations</p>
          </div>
          {isSuperAdmin && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate("/super-admin")}
              className="flex items-center gap-2 border-warning/30 text-warning hover:bg-warning/10"
            >
              <Shield className="h-4 w-4" />
              <span>Admin Panel</span>
            </Button>
          )}
        </header>

        {/* Mobile Header */}
        <header className="lg:hidden border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-40 shadow-sm">
          <div className="flex items-center gap-4 p-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-lg">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-64">
                <Sidebar />
              </SheetContent>
            </Sheet>
            <div className="flex items-center gap-2 flex-1">
              <div className="w-10 h-10 rounded-xl bg-gradient-primary flex items-center justify-center shadow-md">
                <span className="text-primary-foreground font-bold text-lg">N</span>
              </div>
              <div>
                <span className="text-lg font-bold bg-gradient-primary bg-clip-text text-transparent">Nuzum</span>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="rounded-lg">
              <Bell className="w-5 h-5" />
            </Button>
            <LanguageToggle />
            {isSuperAdmin && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate("/super-admin")}
                title="Super Admin"
                className="rounded-lg text-warning"
              >
                <Shield className="h-4 w-4" />
              </Button>
            )}
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 lg:p-8 overflow-auto">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
