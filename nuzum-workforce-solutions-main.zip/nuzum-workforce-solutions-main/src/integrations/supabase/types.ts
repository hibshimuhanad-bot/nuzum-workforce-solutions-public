export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      allowances: {
        Row: {
          allowance_type: string | null
          amount: number
          applies_to_nationality: string | null
          created_at: string
          effective_date: string
          employee_id: string
          end_date: string | null
          id: string
          is_recurring: boolean | null
          is_taxable: boolean | null
          name: string
          organization_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          allowance_type?: string | null
          amount: number
          applies_to_nationality?: string | null
          created_at?: string
          effective_date?: string
          employee_id: string
          end_date?: string | null
          id?: string
          is_recurring?: boolean | null
          is_taxable?: boolean | null
          name: string
          organization_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          allowance_type?: string | null
          amount?: number
          applies_to_nationality?: string | null
          created_at?: string
          effective_date?: string
          employee_id?: string
          end_date?: string | null
          id?: string
          is_recurring?: boolean | null
          is_taxable?: boolean | null
          name?: string
          organization_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "allowances_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "allowances_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "allowances_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "allowances_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_records: {
        Row: {
          check_in: string
          check_out: string | null
          created_at: string
          employee_id: string
          id: string
          notes: string | null
          organization_id: string | null
          overtime_hours: number | null
          updated_at: string
          user_id: string
          work_hours: number | null
        }
        Insert: {
          check_in: string
          check_out?: string | null
          created_at?: string
          employee_id: string
          id?: string
          notes?: string | null
          organization_id?: string | null
          overtime_hours?: number | null
          updated_at?: string
          user_id: string
          work_hours?: number | null
        }
        Update: {
          check_in?: string
          check_out?: string | null
          created_at?: string
          employee_id?: string
          id?: string
          notes?: string | null
          organization_id?: string | null
          overtime_hours?: number | null
          updated_at?: string
          user_id?: string
          work_hours?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "attendance_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "attendance_records_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_records_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string | null
          entity_id: string | null
          entity_type: string
          id: string
          ip_address: string | null
          is_sensitive: boolean | null
          new_data: Json | null
          old_data: Json | null
          organization_id: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string | null
          entity_id?: string | null
          entity_type: string
          id?: string
          ip_address?: string | null
          is_sensitive?: boolean | null
          new_data?: Json | null
          old_data?: Json | null
          organization_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string | null
          entity_id?: string | null
          entity_type?: string
          id?: string
          ip_address?: string | null
          is_sensitive?: boolean | null
          new_data?: Json | null
          old_data?: Json | null
          organization_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "audit_logs_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      deductions: {
        Row: {
          amount: number
          applies_to_nationality: string | null
          created_at: string
          deduction_type: string | null
          effective_date: string
          employee_id: string
          end_date: string | null
          id: string
          is_recurring: boolean | null
          name: string
          organization_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          applies_to_nationality?: string | null
          created_at?: string
          deduction_type?: string | null
          effective_date?: string
          employee_id: string
          end_date?: string | null
          id?: string
          is_recurring?: boolean | null
          name: string
          organization_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          applies_to_nationality?: string | null
          created_at?: string
          deduction_type?: string | null
          effective_date?: string
          employee_id?: string
          end_date?: string | null
          id?: string
          is_recurring?: boolean | null
          name?: string
          organization_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "deductions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deductions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "deductions_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deductions_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      departments: {
        Row: {
          created_at: string
          description: string | null
          id: string
          level: number | null
          manager_id: string | null
          name: string
          organization_id: string
          parent_department_id: string | null
          path: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          level?: number | null
          manager_id?: string | null
          name: string
          organization_id: string
          parent_department_id?: string | null
          path?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          level?: number | null
          manager_id?: string | null
          name?: string
          organization_id?: string
          parent_department_id?: string | null
          path?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "departments_parent_department_id_fkey"
            columns: ["parent_department_id"]
            isOneToOne: false
            referencedRelation: "department_statistics"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_parent_department_id_fkey"
            columns: ["parent_department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_documents: {
        Row: {
          category: Database["public"]["Enums"]["document_category"]
          created_at: string
          document_name: string
          employee_id: string
          expiry_date: string | null
          file_path: string
          file_size: number | null
          id: string
          issue_date: string | null
          notes: string | null
          organization_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          category: Database["public"]["Enums"]["document_category"]
          created_at?: string
          document_name: string
          employee_id: string
          expiry_date?: string | null
          file_path: string
          file_size?: number | null
          id?: string
          issue_date?: string | null
          notes?: string | null
          organization_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: Database["public"]["Enums"]["document_category"]
          created_at?: string
          document_name?: string
          employee_id?: string
          expiry_date?: string | null
          file_path?: string
          file_size?: number | null
          id?: string
          issue_date?: string | null
          notes?: string | null
          organization_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_documents_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_documents_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "employee_documents_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_documents_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_leave_balances: {
        Row: {
          annual_leave_balance: number | null
          annual_leave_entitlement: number | null
          annual_leave_used: number | null
          created_at: string | null
          employee_id: string
          id: string
          leave_accrual_date: string | null
          organization_id: string
          sick_leave_used: number | null
          unpaid_leave_days: number | null
          updated_at: string | null
          user_id: string
          year: number
        }
        Insert: {
          annual_leave_balance?: number | null
          annual_leave_entitlement?: number | null
          annual_leave_used?: number | null
          created_at?: string | null
          employee_id: string
          id?: string
          leave_accrual_date?: string | null
          organization_id: string
          sick_leave_used?: number | null
          unpaid_leave_days?: number | null
          updated_at?: string | null
          user_id: string
          year: number
        }
        Update: {
          annual_leave_balance?: number | null
          annual_leave_entitlement?: number | null
          annual_leave_used?: number | null
          created_at?: string | null
          employee_id?: string
          id?: string
          leave_accrual_date?: string | null
          organization_id?: string
          sick_leave_used?: number | null
          unpaid_leave_days?: number | null
          updated_at?: string | null
          user_id?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "employee_leave_balances_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_leave_balances_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "employee_leave_balances_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_leave_balances_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      employees: {
        Row: {
          avatar_url: string | null
          contract_type: string | null
          created_at: string
          department_id: string | null
          email: string
          id: string
          iqama_expiry_date: string | null
          iqama_number: string | null
          join_date: string
          name: string
          national_id: string | null
          nationality: string | null
          nationality_type: string | null
          organization_id: string | null
          passport_number: string | null
          phone: string
          position: string
          salary: number | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          contract_type?: string | null
          created_at?: string
          department_id?: string | null
          email: string
          id?: string
          iqama_expiry_date?: string | null
          iqama_number?: string | null
          join_date: string
          name: string
          national_id?: string | null
          nationality?: string | null
          nationality_type?: string | null
          organization_id?: string | null
          passport_number?: string | null
          phone: string
          position: string
          salary?: number | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          contract_type?: string | null
          created_at?: string
          department_id?: string | null
          email?: string
          id?: string
          iqama_expiry_date?: string | null
          iqama_number?: string | null
          join_date?: string
          name?: string
          national_id?: string | null
          nationality?: string | null
          nationality_type?: string | null
          organization_id?: string | null
          passport_number?: string | null
          phone?: string
          position?: string
          salary?: number | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "employees_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      employment_terminations: {
        Row: {
          created_at: string | null
          employee_id: string
          end_of_service_amount: number | null
          final_settlement: number | null
          id: string
          last_working_day: string | null
          notes: string | null
          notice_period_days: number | null
          organization_id: string
          outstanding_loans: number | null
          processed_at: string | null
          processed_by: string | null
          reason: string | null
          termination_date: string
          termination_type: string
          unpaid_leave_deduction: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          employee_id: string
          end_of_service_amount?: number | null
          final_settlement?: number | null
          id?: string
          last_working_day?: string | null
          notes?: string | null
          notice_period_days?: number | null
          organization_id: string
          outstanding_loans?: number | null
          processed_at?: string | null
          processed_by?: string | null
          reason?: string | null
          termination_date: string
          termination_type: string
          unpaid_leave_deduction?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          employee_id?: string
          end_of_service_amount?: number | null
          final_settlement?: number | null
          id?: string
          last_working_day?: string | null
          notes?: string | null
          notice_period_days?: number | null
          organization_id?: string
          outstanding_loans?: number | null
          processed_at?: string | null
          processed_by?: string | null
          reason?: string | null
          termination_date?: string
          termination_type?: string
          unpaid_leave_deduction?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "employment_terminations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employment_terminations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "employment_terminations_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employment_terminations_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      fleet_projects: {
        Row: {
          actual_cost: number | null
          budget: number | null
          created_at: string
          description: string | null
          end_date: string | null
          id: string
          location: string | null
          name: string
          organization_id: string
          start_date: string
          status: string
          updated_at: string
          user_id: string
          vehicles_count: number | null
        }
        Insert: {
          actual_cost?: number | null
          budget?: number | null
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          location?: string | null
          name: string
          organization_id: string
          start_date: string
          status?: string
          updated_at?: string
          user_id: string
          vehicles_count?: number | null
        }
        Update: {
          actual_cost?: number | null
          budget?: number | null
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          location?: string | null
          name?: string
          organization_id?: string
          start_date?: string
          status?: string
          updated_at?: string
          user_id?: string
          vehicles_count?: number | null
        }
        Relationships: []
      }
      fuel_logs: {
        Row: {
          cost: number
          created_at: string
          employee_id: string | null
          fuel_date: string
          id: string
          liters: number
          mileage: number
          notes: string | null
          organization_id: string | null
          station_name: string | null
          updated_at: string
          user_id: string
          vehicle_id: string
        }
        Insert: {
          cost: number
          created_at?: string
          employee_id?: string | null
          fuel_date?: string
          id?: string
          liters: number
          mileage: number
          notes?: string | null
          organization_id?: string | null
          station_name?: string | null
          updated_at?: string
          user_id: string
          vehicle_id: string
        }
        Update: {
          cost?: number
          created_at?: string
          employee_id?: string | null
          fuel_date?: string
          id?: string
          liters?: number
          mileage?: number
          notes?: string | null
          organization_id?: string | null
          station_name?: string | null
          updated_at?: string
          user_id?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fuel_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fuel_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "fuel_logs_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fuel_logs_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fuel_logs_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      invoice_line_items: {
        Row: {
          created_at: string
          days_count: number
          description: string
          discount_amount: number | null
          discount_percent: number | null
          end_date: string
          id: string
          invoice_id: string
          line_total: number
          notes: string | null
          organization_id: string
          penalty_amount: number | null
          penalty_reason: string | null
          quantity: number | null
          rental_agreement_id: string | null
          start_date: string
          unit_price: number
          vehicle_id: string | null
        }
        Insert: {
          created_at?: string
          days_count: number
          description: string
          discount_amount?: number | null
          discount_percent?: number | null
          end_date: string
          id?: string
          invoice_id: string
          line_total: number
          notes?: string | null
          organization_id: string
          penalty_amount?: number | null
          penalty_reason?: string | null
          quantity?: number | null
          rental_agreement_id?: string | null
          start_date: string
          unit_price: number
          vehicle_id?: string | null
        }
        Update: {
          created_at?: string
          days_count?: number
          description?: string
          discount_amount?: number | null
          discount_percent?: number | null
          end_date?: string
          id?: string
          invoice_id?: string
          line_total?: number
          notes?: string | null
          organization_id?: string
          penalty_amount?: number | null
          penalty_reason?: string | null
          quantity?: number | null
          rental_agreement_id?: string | null
          start_date?: string
          unit_price?: number
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invoice_line_items_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "project_invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_line_items_rental_agreement_id_fkey"
            columns: ["rental_agreement_id"]
            isOneToOne: false
            referencedRelation: "vehicle_rental_agreements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_line_items_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      leave_requests: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          days_count: number
          employee_id: string
          end_date: string
          id: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          organization_id: string | null
          reason: string | null
          rejection_reason: string | null
          start_date: string
          status: Database["public"]["Enums"]["leave_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          days_count: number
          employee_id: string
          end_date: string
          id?: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          organization_id?: string | null
          reason?: string | null
          rejection_reason?: string | null
          start_date: string
          status?: Database["public"]["Enums"]["leave_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          days_count?: number
          employee_id?: string
          end_date?: string
          id?: string
          leave_type?: Database["public"]["Enums"]["leave_type"]
          organization_id?: string | null
          reason?: string | null
          rejection_reason?: string | null
          start_date?: string
          status?: Database["public"]["Enums"]["leave_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "leave_requests_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      maintenance_items: {
        Row: {
          created_at: string
          id: string
          item_name: string
          maintenance_id: string
          notes: string | null
          organization_id: string
          quantity: number
          total_price: number
          unit_price: number
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          item_name: string
          maintenance_id: string
          notes?: string | null
          organization_id: string
          quantity?: number
          total_price: number
          unit_price: number
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          item_name?: string
          maintenance_id?: string
          notes?: string | null
          organization_id?: string
          quantity?: number
          total_price?: number
          unit_price?: number
          user_id?: string
        }
        Relationships: []
      }
      maintenance_workshops: {
        Row: {
          address: string | null
          created_at: string
          email: string | null
          id: string
          name: string
          notes: string | null
          organization_id: string
          phone: string | null
          rating: number | null
          specialization: string | null
          total_services: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          address?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name: string
          notes?: string | null
          organization_id: string
          phone?: string | null
          rating?: number | null
          specialization?: string | null
          total_services?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          address?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          notes?: string | null
          organization_id?: string
          phone?: string | null
          rating?: number | null
          specialization?: string | null
          total_services?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      notification_settings: {
        Row: {
          created_at: string | null
          delivery_method: string[] | null
          id: string
          is_enabled: boolean | null
          notification_type: string
          organization_id: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          delivery_method?: string[] | null
          id?: string
          is_enabled?: boolean | null
          notification_type: string
          organization_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          delivery_method?: string[] | null
          id?: string
          is_enabled?: boolean | null
          notification_type?: string
          organization_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notification_settings_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notification_settings_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          action_label: string | null
          action_url: string | null
          category: string | null
          created_at: string
          expires_at: string | null
          id: string
          is_read: boolean
          message: string
          metadata: Json | null
          organization_id: string
          priority: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          action_label?: string | null
          action_url?: string | null
          category?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_read?: boolean
          message: string
          metadata?: Json | null
          organization_id: string
          priority?: string | null
          title: string
          type?: string
          user_id: string
        }
        Update: {
          action_label?: string | null
          action_url?: string | null
          category?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_read?: boolean
          message?: string
          metadata?: Json | null
          organization_id?: string
          priority?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      organization_members: {
        Row: {
          created_at: string | null
          id: string
          joined_at: string | null
          organization_id: string
          role: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          joined_at?: string | null
          organization_id: string
          role?: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          joined_at?: string | null
          organization_id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_members_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "organization_members_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          address: string | null
          created_at: string | null
          enabled_modules: Json | null
          expires_at: string | null
          id: string
          industry: string | null
          is_active: boolean | null
          logo_url: string | null
          max_employees: number | null
          max_vehicles: number | null
          name: string
          phone: string | null
          settings: Json | null
          slug: string
          subscription_tier: string
          updated_at: string | null
        }
        Insert: {
          address?: string | null
          created_at?: string | null
          enabled_modules?: Json | null
          expires_at?: string | null
          id?: string
          industry?: string | null
          is_active?: boolean | null
          logo_url?: string | null
          max_employees?: number | null
          max_vehicles?: number | null
          name: string
          phone?: string | null
          settings?: Json | null
          slug: string
          subscription_tier?: string
          updated_at?: string | null
        }
        Update: {
          address?: string | null
          created_at?: string | null
          enabled_modules?: Json | null
          expires_at?: string | null
          id?: string
          industry?: string | null
          is_active?: boolean | null
          logo_url?: string | null
          max_employees?: number | null
          max_vehicles?: number | null
          name?: string
          phone?: string | null
          settings?: Json | null
          slug?: string
          subscription_tier?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      overtime_records: {
        Row: {
          amount: number | null
          approved: boolean | null
          approved_by: string | null
          created_at: string
          date: string
          employee_id: string
          hours: number
          id: string
          notes: string | null
          organization_id: string | null
          rate_multiplier: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          amount?: number | null
          approved?: boolean | null
          approved_by?: string | null
          created_at?: string
          date: string
          employee_id: string
          hours: number
          id?: string
          notes?: string | null
          organization_id?: string | null
          rate_multiplier?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number | null
          approved?: boolean | null
          approved_by?: string | null
          created_at?: string
          date?: string
          employee_id?: string
          hours?: number
          id?: string
          notes?: string | null
          organization_id?: string | null
          rate_multiplier?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "overtime_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "overtime_records_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_records_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      payroll_records: {
        Row: {
          base_salary: number
          created_at: string
          employee_id: string
          end_of_service_provision: number | null
          food_allowance: number | null
          gosi_company: number | null
          gosi_employee: number | null
          housing_allowance: number | null
          id: string
          leave_balance_days: number | null
          month: number
          net_salary: number
          notes: string | null
          occupational_hazard: number | null
          organization_id: string | null
          other_taxable_allowances: number | null
          overtime_amount: number | null
          payment_date: string | null
          salary_template_id: string | null
          total_allowances: number | null
          total_company_cost: number | null
          total_deductions: number | null
          total_taxable_income: number | null
          transportation_allowance: number | null
          unpaid_leave_deduction: number | null
          updated_at: string
          user_id: string
          year: number
        }
        Insert: {
          base_salary: number
          created_at?: string
          employee_id: string
          end_of_service_provision?: number | null
          food_allowance?: number | null
          gosi_company?: number | null
          gosi_employee?: number | null
          housing_allowance?: number | null
          id?: string
          leave_balance_days?: number | null
          month: number
          net_salary: number
          notes?: string | null
          occupational_hazard?: number | null
          organization_id?: string | null
          other_taxable_allowances?: number | null
          overtime_amount?: number | null
          payment_date?: string | null
          salary_template_id?: string | null
          total_allowances?: number | null
          total_company_cost?: number | null
          total_deductions?: number | null
          total_taxable_income?: number | null
          transportation_allowance?: number | null
          unpaid_leave_deduction?: number | null
          updated_at?: string
          user_id: string
          year: number
        }
        Update: {
          base_salary?: number
          created_at?: string
          employee_id?: string
          end_of_service_provision?: number | null
          food_allowance?: number | null
          gosi_company?: number | null
          gosi_employee?: number | null
          housing_allowance?: number | null
          id?: string
          leave_balance_days?: number | null
          month?: number
          net_salary?: number
          notes?: string | null
          occupational_hazard?: number | null
          organization_id?: string | null
          other_taxable_allowances?: number | null
          overtime_amount?: number | null
          payment_date?: string | null
          salary_template_id?: string | null
          total_allowances?: number | null
          total_company_cost?: number | null
          total_deductions?: number | null
          total_taxable_income?: number | null
          transportation_allowance?: number | null
          unpaid_leave_deduction?: number | null
          updated_at?: string
          user_id?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "payroll_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "payroll_records_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_records_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_records_salary_template_id_fkey"
            columns: ["salary_template_id"]
            isOneToOne: false
            referencedRelation: "salary_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      permissions: {
        Row: {
          category: string
          created_at: string | null
          description: string | null
          id: string
          is_active: boolean | null
          name: string
        }
        Insert: {
          category: string
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name: string
        }
        Update: {
          category?: string
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          company_name: string | null
          created_at: string
          email: string | null
          id: string
          locale: string | null
          organization_id: string | null
          timezone: string | null
          updated_at: string
        }
        Insert: {
          company_name?: string | null
          created_at?: string
          email?: string | null
          id: string
          locale?: string | null
          organization_id?: string | null
          timezone?: string | null
          updated_at?: string
        }
        Update: {
          company_name?: string | null
          created_at?: string
          email?: string | null
          id?: string
          locale?: string | null
          organization_id?: string | null
          timezone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      project_invoices: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          attachments: string[] | null
          billing_period_end: string | null
          billing_period_start: string | null
          created_at: string
          discount_amount: number | null
          due_date: string
          id: string
          invoice_date: string
          invoice_file: string | null
          invoice_number: string
          invoice_type: string
          notes: string | null
          organization_id: string
          paid_amount: number | null
          payment_date: string | null
          payment_method: string | null
          payment_reference: string | null
          penalties: number | null
          project_id: string
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          status: string
          subtotal: number
          supplier_id: string
          tax_amount: number | null
          total_amount: number
          updated_at: string
          user_id: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          attachments?: string[] | null
          billing_period_end?: string | null
          billing_period_start?: string | null
          created_at?: string
          discount_amount?: number | null
          due_date: string
          id?: string
          invoice_date: string
          invoice_file?: string | null
          invoice_number: string
          invoice_type: string
          notes?: string | null
          organization_id: string
          paid_amount?: number | null
          payment_date?: string | null
          payment_method?: string | null
          payment_reference?: string | null
          penalties?: number | null
          project_id: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          status?: string
          subtotal?: number
          supplier_id: string
          tax_amount?: number | null
          total_amount: number
          updated_at?: string
          user_id: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          attachments?: string[] | null
          billing_period_end?: string | null
          billing_period_start?: string | null
          created_at?: string
          discount_amount?: number | null
          due_date?: string
          id?: string
          invoice_date?: string
          invoice_file?: string | null
          invoice_number?: string
          invoice_type?: string
          notes?: string | null
          organization_id?: string
          paid_amount?: number | null
          payment_date?: string | null
          payment_method?: string | null
          payment_reference?: string | null
          penalties?: number | null
          project_id?: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          status?: string
          subtotal?: number
          supplier_id?: string
          tax_amount?: number | null
          total_amount?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_invoices_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "fleet_projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_invoices_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      role_permissions: {
        Row: {
          created_at: string | null
          id: string
          organization_id: string | null
          permission_id: string | null
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          created_at?: string | null
          id?: string
          organization_id?: string | null
          permission_id?: string | null
          role: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          created_at?: string | null
          id?: string
          organization_id?: string | null
          permission_id?: string | null
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: [
          {
            foreignKeyName: "role_permissions_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "role_permissions_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "role_permissions_permission_id_fkey"
            columns: ["permission_id"]
            isOneToOne: false
            referencedRelation: "permissions"
            referencedColumns: ["id"]
          },
        ]
      }
      salary_templates: {
        Row: {
          base_salary: number
          created_at: string
          food_allowance: number | null
          housing_allowance: number | null
          id: string
          name: string
          organization_id: string | null
          transport_allowance: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          base_salary: number
          created_at?: string
          food_allowance?: number | null
          housing_allowance?: number | null
          id?: string
          name: string
          organization_id?: string | null
          transport_allowance?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          base_salary?: number
          created_at?: string
          food_allowance?: number | null
          housing_allowance?: number | null
          id?: string
          name?: string
          organization_id?: string | null
          transport_allowance?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "salary_templates_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "salary_templates_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      suppliers: {
        Row: {
          address: string | null
          bank_account: string | null
          city: string | null
          company_name: string | null
          contact_person: string | null
          created_at: string
          email: string | null
          id: string
          name: string
          notes: string | null
          organization_id: string
          phone: string
          rating: number | null
          status: string
          supplier_type: string
          tax_number: string | null
          total_invoices: number | null
          total_paid: number | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          address?: string | null
          bank_account?: string | null
          city?: string | null
          company_name?: string | null
          contact_person?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name: string
          notes?: string | null
          organization_id: string
          phone: string
          rating?: number | null
          status?: string
          supplier_type: string
          tax_number?: string | null
          total_invoices?: number | null
          total_paid?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          address?: string | null
          bank_account?: string | null
          city?: string | null
          company_name?: string | null
          contact_person?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          notes?: string | null
          organization_id?: string
          phone?: string
          rating?: number | null
          status?: string
          supplier_type?: string
          tax_number?: string | null
          total_invoices?: number | null
          total_paid?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      vehicle_assignments: {
        Row: {
          assigned_date: string
          checklist: Json | null
          created_at: string
          damages: string | null
          delivery_condition: string | null
          delivery_odometer: number | null
          delivery_photos: string[] | null
          employee_id: string
          employee_signature: string | null
          id: string
          notes: string | null
          organization_id: string | null
          return_condition: string | null
          return_date: string | null
          return_odometer: number | null
          return_photos: string[] | null
          status: string | null
          updated_at: string
          user_id: string
          vehicle_id: string
        }
        Insert: {
          assigned_date?: string
          checklist?: Json | null
          created_at?: string
          damages?: string | null
          delivery_condition?: string | null
          delivery_odometer?: number | null
          delivery_photos?: string[] | null
          employee_id: string
          employee_signature?: string | null
          id?: string
          notes?: string | null
          organization_id?: string | null
          return_condition?: string | null
          return_date?: string | null
          return_odometer?: number | null
          return_photos?: string[] | null
          status?: string | null
          updated_at?: string
          user_id: string
          vehicle_id: string
        }
        Update: {
          assigned_date?: string
          checklist?: Json | null
          created_at?: string
          damages?: string | null
          delivery_condition?: string | null
          delivery_odometer?: number | null
          delivery_photos?: string[] | null
          employee_id?: string
          employee_signature?: string | null
          id?: string
          notes?: string | null
          organization_id?: string | null
          return_condition?: string | null
          return_date?: string | null
          return_odometer?: number | null
          return_photos?: string[] | null
          status?: string | null
          updated_at?: string
          user_id?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_assignments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_assignments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "vehicle_assignments_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_assignments_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_assignments_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicle_check_in_out: {
        Row: {
          check_in: string
          check_out: string | null
          condition_in: string | null
          condition_out: string | null
          created_at: string | null
          driver_id: string | null
          fuel_level_in: number | null
          fuel_level_out: number | null
          id: string
          notes: string | null
          odometer_in: number | null
          odometer_out: number | null
          organization_id: string
          photos_in: string[] | null
          photos_out: string[] | null
          updated_at: string | null
          user_id: string
          vehicle_id: string
        }
        Insert: {
          check_in?: string
          check_out?: string | null
          condition_in?: string | null
          condition_out?: string | null
          created_at?: string | null
          driver_id?: string | null
          fuel_level_in?: number | null
          fuel_level_out?: number | null
          id?: string
          notes?: string | null
          odometer_in?: number | null
          odometer_out?: number | null
          organization_id: string
          photos_in?: string[] | null
          photos_out?: string[] | null
          updated_at?: string | null
          user_id: string
          vehicle_id: string
        }
        Update: {
          check_in?: string
          check_out?: string | null
          condition_in?: string | null
          condition_out?: string | null
          created_at?: string | null
          driver_id?: string | null
          fuel_level_in?: number | null
          fuel_level_out?: number | null
          id?: string
          notes?: string | null
          odometer_in?: number | null
          odometer_out?: number | null
          organization_id?: string
          photos_in?: string[] | null
          photos_out?: string[] | null
          updated_at?: string | null
          user_id?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_check_in_out_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_check_in_out_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "monthly_gosi_report"
            referencedColumns: ["employee_id"]
          },
          {
            foreignKeyName: "vehicle_check_in_out_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_check_in_out_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_check_in_out_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicle_documents: {
        Row: {
          created_at: string
          document_name: string
          document_number: string | null
          document_type: string
          expiry_date: string | null
          file_path: string | null
          id: string
          issue_date: string | null
          notes: string | null
          organization_id: string
          status: string
          updated_at: string
          user_id: string
          vehicle_id: string
        }
        Insert: {
          created_at?: string
          document_name: string
          document_number?: string | null
          document_type: string
          expiry_date?: string | null
          file_path?: string | null
          id?: string
          issue_date?: string | null
          notes?: string | null
          organization_id: string
          status?: string
          updated_at?: string
          user_id: string
          vehicle_id: string
        }
        Update: {
          created_at?: string
          document_name?: string
          document_number?: string | null
          document_type?: string
          expiry_date?: string | null
          file_path?: string | null
          id?: string
          issue_date?: string | null
          notes?: string | null
          organization_id?: string
          status?: string
          updated_at?: string
          user_id?: string
          vehicle_id?: string
        }
        Relationships: []
      }
      vehicle_maintenance: {
        Row: {
          after_photos: string[] | null
          before_photos: string[] | null
          city: string | null
          cost: number | null
          created_at: string
          description: string | null
          id: string
          invoice_number: string | null
          maintenance_category: string | null
          maintenance_date: string
          maintenance_type: string
          mileage: number | null
          next_maintenance_date: string | null
          organization_id: string | null
          parts_details: Json | null
          performed_by: string | null
          rating: number | null
          status: string | null
          updated_at: string
          user_id: string
          vehicle_id: string
          workshop_id: string | null
        }
        Insert: {
          after_photos?: string[] | null
          before_photos?: string[] | null
          city?: string | null
          cost?: number | null
          created_at?: string
          description?: string | null
          id?: string
          invoice_number?: string | null
          maintenance_category?: string | null
          maintenance_date: string
          maintenance_type: string
          mileage?: number | null
          next_maintenance_date?: string | null
          organization_id?: string | null
          parts_details?: Json | null
          performed_by?: string | null
          rating?: number | null
          status?: string | null
          updated_at?: string
          user_id: string
          vehicle_id: string
          workshop_id?: string | null
        }
        Update: {
          after_photos?: string[] | null
          before_photos?: string[] | null
          city?: string | null
          cost?: number | null
          created_at?: string
          description?: string | null
          id?: string
          invoice_number?: string | null
          maintenance_category?: string | null
          maintenance_date?: string
          maintenance_type?: string
          mileage?: number | null
          next_maintenance_date?: string | null
          organization_id?: string | null
          parts_details?: Json | null
          performed_by?: string | null
          rating?: number | null
          status?: string | null
          updated_at?: string
          user_id?: string
          vehicle_id?: string
          workshop_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_maintenance_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_maintenance_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_maintenance_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicle_project_assignments: {
        Row: {
          assigned_date: string
          created_at: string
          end_date: string | null
          id: string
          notes: string | null
          organization_id: string
          project_id: string
          updated_at: string
          user_id: string
          vehicle_id: string
        }
        Insert: {
          assigned_date?: string
          created_at?: string
          end_date?: string | null
          id?: string
          notes?: string | null
          organization_id: string
          project_id: string
          updated_at?: string
          user_id: string
          vehicle_id: string
        }
        Update: {
          assigned_date?: string
          created_at?: string
          end_date?: string | null
          id?: string
          notes?: string | null
          organization_id?: string
          project_id?: string
          updated_at?: string
          user_id?: string
          vehicle_id?: string
        }
        Relationships: []
      }
      vehicle_rental_agreements: {
        Row: {
          billing_type: string
          created_at: string
          daily_rate: number
          end_date: string | null
          id: string
          monthly_rate: number | null
          notes: string | null
          organization_id: string
          penalties: Json | null
          project_id: string
          start_date: string
          status: string
          supplier_id: string
          terms: string | null
          updated_at: string
          user_id: string
          vehicle_id: string
        }
        Insert: {
          billing_type: string
          created_at?: string
          daily_rate: number
          end_date?: string | null
          id?: string
          monthly_rate?: number | null
          notes?: string | null
          organization_id: string
          penalties?: Json | null
          project_id: string
          start_date: string
          status?: string
          supplier_id: string
          terms?: string | null
          updated_at?: string
          user_id: string
          vehicle_id: string
        }
        Update: {
          billing_type?: string
          created_at?: string
          daily_rate?: number
          end_date?: string | null
          id?: string
          monthly_rate?: number | null
          notes?: string | null
          organization_id?: string
          penalties?: Json | null
          project_id?: string
          start_date?: string
          status?: string
          supplier_id?: string
          terms?: string | null
          updated_at?: string
          user_id?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_rental_agreements_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "fleet_projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_rental_agreements_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_rental_agreements_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicles: {
        Row: {
          color: string | null
          created_at: string
          current_mileage: number | null
          id: string
          images: string[] | null
          insurance_expiry: string | null
          make: string
          model: string
          notes: string | null
          organization_id: string | null
          plate_number: string
          registration_date: string
          status: Database["public"]["Enums"]["vehicle_status"]
          updated_at: string
          user_id: string
          vin: string | null
          year: number
        }
        Insert: {
          color?: string | null
          created_at?: string
          current_mileage?: number | null
          id?: string
          images?: string[] | null
          insurance_expiry?: string | null
          make: string
          model: string
          notes?: string | null
          organization_id?: string | null
          plate_number: string
          registration_date: string
          status?: Database["public"]["Enums"]["vehicle_status"]
          updated_at?: string
          user_id: string
          vin?: string | null
          year: number
        }
        Update: {
          color?: string | null
          created_at?: string
          current_mileage?: number | null
          id?: string
          images?: string[] | null
          insurance_expiry?: string | null
          make?: string
          model?: string
          notes?: string | null
          organization_id?: string | null
          plate_number?: string
          registration_date?: string
          status?: Database["public"]["Enums"]["vehicle_status"]
          updated_at?: string
          user_id?: string
          vin?: string | null
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "vehicles_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicles_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      department_statistics: {
        Row: {
          active_employee_count: number | null
          average_salary: number | null
          employee_count: number | null
          id: string | null
          inactive_employee_count: number | null
          level: number | null
          manager_id: string | null
          max_salary: number | null
          min_salary: number | null
          name: string | null
          organization_id: string | null
          parent_department_id: string | null
          path: string | null
          total_salary_cost: number | null
        }
        Relationships: [
          {
            foreignKeyName: "departments_parent_department_id_fkey"
            columns: ["parent_department_id"]
            isOneToOne: false
            referencedRelation: "department_statistics"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_parent_department_id_fkey"
            columns: ["parent_department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      monthly_gosi_report: {
        Row: {
          base_salary: number | null
          employee_id: string | null
          employee_name: string | null
          gosi_company: number | null
          gosi_employee: number | null
          month: number | null
          national_id: string | null
          nationality: string | null
          nationality_type: string | null
          occupational_hazard: number | null
          organization_id: string | null
          organization_name: string | null
          total_company_cost: number | null
          total_taxable_income: number | null
          year: number | null
        }
        Relationships: [
          {
            foreignKeyName: "employees_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations_overview"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations_overview: {
        Row: {
          created_at: string | null
          employees_count: number | null
          enabled_modules: Json | null
          expires_at: string | null
          id: string | null
          is_active: boolean | null
          max_employees: number | null
          max_vehicles: number | null
          members_count: number | null
          name: string | null
          slug: string | null
          subscription_tier: string | null
          vehicles_count: number | null
        }
        Insert: {
          created_at?: string | null
          employees_count?: never
          enabled_modules?: Json | null
          expires_at?: string | null
          id?: string | null
          is_active?: boolean | null
          max_employees?: number | null
          max_vehicles?: number | null
          members_count?: never
          name?: string | null
          slug?: string | null
          subscription_tier?: string | null
          vehicles_count?: never
        }
        Update: {
          created_at?: string | null
          employees_count?: never
          enabled_modules?: Json | null
          expires_at?: string | null
          id?: string | null
          is_active?: boolean | null
          max_employees?: number | null
          max_vehicles?: number | null
          members_count?: never
          name?: string | null
          slug?: string | null
          subscription_tier?: string | null
          vehicles_count?: never
        }
        Relationships: []
      }
    }
    Functions: {
      auto_calculate_payroll: {
        Args: { _employee_id: string; _month: number; _year: number }
        Returns: Json
      }
      calculate_end_of_service: {
        Args: {
          _employee_id: string
          _termination_date?: string
          _termination_type?: string
        }
        Returns: number
      }
      calculate_gosi_for_employee: {
        Args: { _employee_id: string; _month: number; _year: number }
        Returns: Json
      }
      calculate_leave_balance: {
        Args: { _employee_id: string; _year?: number }
        Returns: Json
      }
      get_admin_user_ids: {
        Args: { _organization_id: string }
        Returns: string[]
      }
      get_department_tree: {
        Args: { _dept_id?: string; _org_id?: string }
        Returns: {
          active_employee_count: number
          employee_count: number
          has_children: boolean
          id: string
          level: number
          manager_id: string
          manager_name: string
          name: string
          parent_department_id: string
          path: string
          total_salary_cost: number
        }[]
      }
      get_organization_usage_stats: {
        Args: { _org_id: string }
        Returns: {
          employees_percentage: number
          last_activity: string
          total_attendance_records: number
          total_employees: number
          total_leave_requests: number
          total_payroll_records: number
          total_users: number
          total_vehicles: number
          vehicles_percentage: number
        }[]
      }
      get_user_organization_id: {
        Args: { _user_id: string }
        Returns: string
      }
      has_permission: {
        Args: { _permission_name: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      send_notification: {
        Args: {
          _action_label?: string
          _action_url?: string
          _category?: string
          _message: string
          _metadata?: Json
          _organization_id: string
          _priority?: string
          _title: string
          _type?: string
          _user_ids: string[]
        }
        Returns: undefined
      }
    }
    Enums: {
      app_role:
        | "admin"
        | "manager"
        | "employee"
        | "super_admin"
        | "org_admin"
        | "hr"
        | "fleet_manager"
      document_category:
        | "contract"
        | "certificate"
        | "id_document"
        | "license"
        | "other"
      leave_status: "pending" | "approved" | "rejected"
      leave_type: "annual" | "sick" | "emergency" | "unpaid"
      vehicle_status: "active" | "maintenance" | "retired"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "admin",
        "manager",
        "employee",
        "super_admin",
        "org_admin",
        "hr",
        "fleet_manager",
      ],
      document_category: [
        "contract",
        "certificate",
        "id_document",
        "license",
        "other",
      ],
      leave_status: ["pending", "approved", "rejected"],
      leave_type: ["annual", "sick", "emergency", "unpaid"],
      vehicle_status: ["active", "maintenance", "retired"],
    },
  },
} as const
