import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";

export const usePermissions = () => {
  const { user, session } = useAuth();
  const [isHR, setIsHR] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [userRoles, setUserRoles] = useState<string[]>([]);
  const [permissionCache, setPermissionCache] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const checkPermissions = async () => {
      console.log('🔍 Starting permissions check for user:', user?.id);
      
      if (!user || !session) {
        console.log('⚠️ No user/session found, clearing permissions');
        setIsHR(false);
        setIsAdmin(false);
        setIsSuperAdmin(false);
        setUserRoles([]);
        setLoading(false);
        return;
      }

      try {
        console.log('📋 Fetching user roles from database (no circular dependency)...');
        
        // Fetch user roles directly - RLS policy now prioritizes user_id = auth.uid()
        const { data: roles, error: rolesError } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id);

        if (rolesError) {
          console.error('❌ Error fetching roles:', rolesError);
        } else {
          console.log('✅ Roles fetched successfully:', roles);
        }

        // Check organization membership
        const { data: membership, error: membershipError } = await supabase
          .from("organization_members")
          .select("role")
          .eq("user_id", user.id)
          .maybeSingle();

        if (membershipError) {
          console.error('❌ Error fetching membership:', membershipError);
        } else {
          console.log('✅ Membership fetched:', membership);
        }

        const rolesList = roles?.map(r => r.role) || [];
        console.log('📝 Processed roles list:', rolesList);
        setUserRoles(rolesList);

        // Check super_admin directly from roles (most reliable)
        const hasSuperAdmin = rolesList.includes('super_admin');
        console.log('🔑 Super admin status:', hasSuperAdmin);

        const hasHRRole = rolesList.some(r => r === 'hr' || r === 'org_admin' || r === 'super_admin');
        const isOrgAdmin = membership?.role === 'owner' || membership?.role === 'admin';

        setIsHR(hasHRRole || isOrgAdmin || false);
        setIsAdmin(isOrgAdmin || rolesList.some(r => r === 'org_admin' || r === 'super_admin') || false);
        setIsSuperAdmin(hasSuperAdmin);
        
        console.log('✨ Final permissions set:', { 
          userId: user.id, 
          email: user.email,
          rolesList, 
          hasSuperAdmin,
          isHR: hasHRRole || isOrgAdmin,
          isAdmin: isOrgAdmin || rolesList.some(r => r === 'org_admin' || r === 'super_admin'),
          isOrgAdmin,
          membershipRole: membership?.role 
        });
      } catch (error) {
        console.error("❌ Critical error checking permissions:", error);
        setIsHR(false);
        setIsAdmin(false);
        setIsSuperAdmin(false);
        setUserRoles([]);
      } finally {
        console.log('🏁 Permissions check complete, setting loading to false');
        setLoading(false);
      }
    };

    checkPermissions();
  }, [user, session]);

  const hasPermission = async (permission: string): Promise<boolean> => {
    // Super Admin bypass - immediate true
    if (isSuperAdmin) return true;

    if (!user) return false;

    // Check cache first
    if (permissionCache[permission] !== undefined) {
      return permissionCache[permission];
    }
    
    try {
      const { data, error } = await supabase.rpc('has_permission', {
        _user_id: user.id,
        _permission_name: permission
      });
      
      if (error) {
        console.error('Error checking permission:', error);
        return false;
      }
      
      const result = data || false;
      
      // Cache the result
      setPermissionCache(prev => ({ ...prev, [permission]: result }));
      
      return result;
    } catch (error) {
      console.error('Error in hasPermission:', error);
      return false;
    }
  };

  const hasAnyPermission = async (permissions: string[]): Promise<boolean> => {
    // Super Admin bypass
    if (isSuperAdmin) return true;

    if (!user || !permissions.length) return false;
    
    for (const permission of permissions) {
      const result = await hasPermission(permission);
      if (result) return true;
    }
    
    return false;
  };

  const hasAllPermissions = async (permissions: string[]): Promise<boolean> => {
    // Super Admin bypass
    if (isSuperAdmin) return true;

    if (!user || !permissions.length) return false;
    
    for (const permission of permissions) {
      const result = await hasPermission(permission);
      if (!result) return false;
    }
    
    return true;
  };

  const [canViewDepartments, setCanViewDepartments] = useState(false);
  const [canManageDepartments, setCanManageDepartments] = useState(false);
  const [canViewDepartmentStats, setCanViewDepartmentStats] = useState(false);
  const [canManageHierarchy, setCanManageHierarchy] = useState(false);

  useEffect(() => {
    const checkDepartmentPermissions = async () => {
      if (!user) {
        setCanViewDepartments(false);
        setCanManageDepartments(false);
        setCanViewDepartmentStats(false);
        setCanManageHierarchy(false);
        return;
      }
      
      const viewDepts = await hasPermission('view_departments');
      const manageDepts = await hasPermission('manage_departments');
      const viewStats = await hasPermission('view_department_statistics');
      const manageHierarchy = await hasPermission('manage_department_hierarchy');
      
      setCanViewDepartments(viewDepts);
      setCanManageDepartments(manageDepts);
      setCanViewDepartmentStats(viewStats);
      setCanManageHierarchy(manageHierarchy);
    };
    
    if (!loading) {
      checkDepartmentPermissions();
    }
  }, [user, loading, userRoles]);

  return {
    isHR,
    isAdmin,
    isSuperAdmin,
    loading,
    canManageEmployees: isHR,
    canManageUsers: isAdmin || isSuperAdmin,
    canViewDepartments,
    canManageDepartments,
    canViewDepartmentStats,
    canManageHierarchy,
    userRoles,
    hasPermission,
    hasRole: (role: string) => userRoles.includes(role),
    hasAnyPermission,
    hasAllPermissions,
  };
};
