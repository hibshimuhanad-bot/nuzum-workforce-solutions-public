import { useOrganization } from "./useOrganization";
import { usePermissions } from "./usePermissions";

export type ModuleName = 
  | 'employees' 
  | 'fleet' 
  | 'payroll' 
  | 'attendance' 
  | 'leave' 
  | 'reports' 
  | 'analytics';

// Role-to-Module mapping
const ROLE_MODULE_ACCESS: Record<string, ModuleName[]> = {
  super_admin: ['employees', 'fleet', 'payroll', 'attendance', 'leave', 'reports', 'analytics'],
  org_admin: ['employees', 'fleet', 'payroll', 'attendance', 'leave', 'reports', 'analytics'],
  hr: ['employees', 'payroll', 'attendance', 'leave'],
  manager: ['employees', 'attendance', 'reports'],
  fleet_manager: ['fleet'],
  employee: [],
};

interface ModuleConfig {
  modules: Record<ModuleName, boolean>;
  isModuleEnabled: (module: ModuleName) => boolean;
  accessibleModules: ModuleName[];
  getInitialModule: () => ModuleName | 'overview';
  isLoading: boolean;
  limits: {
    maxEmployees?: number;
    maxVehicles?: number;
  } | null;
}

export const useModules = (): ModuleConfig => {
  const { isSuperAdmin, isAdmin, userRoles } = usePermissions();
  const { organization, isLoading } = useOrganization();
  
  const enabledModules = (organization?.enabled_modules as Record<ModuleName, boolean>) || {
    employees: true,
    fleet: true,
    payroll: true,
    attendance: true,
    leave: true,
    reports: true,
    analytics: true,
  };
  
  // Calculate accessible modules based on roles and organization settings
  const getAccessibleModules = (): ModuleName[] => {
    if (isSuperAdmin) {
      return ['employees', 'fleet', 'payroll', 'attendance', 'leave', 'reports', 'analytics'];
    }
    
    // Get all modules accessible by user's roles
    const roleModules = new Set<ModuleName>();
    userRoles.forEach(role => {
      const modules = ROLE_MODULE_ACCESS[role] || [];
      modules.forEach(module => roleModules.add(module));
    });
    
    // Filter by organization's enabled modules
    return Array.from(roleModules).filter(module => enabledModules[module] === true);
  };
  
  const accessibleModules = getAccessibleModules();
  
  // Determine initial module based on role priority
  const getInitialModule = (): ModuleName | 'overview' => {
    // Role priority: hr > fleet_manager > manager
    if (userRoles.includes('hr') && accessibleModules.includes('employees')) {
      return 'employees';
    }
    if (userRoles.includes('fleet_manager') && accessibleModules.includes('fleet')) {
      return 'fleet';
    }
    if (userRoles.includes('manager') && accessibleModules.includes('employees')) {
      return 'employees';
    }
    
    // Fallback: first accessible module or employees
    return accessibleModules[0] || 'employees';
  };
  
  return {
    modules: enabledModules,
    isModuleEnabled: (module: ModuleName) => {
      return isSuperAdmin || enabledModules[module] === true;
    },
    accessibleModules,
    getInitialModule,
    isLoading,
    limits: {
      maxEmployees: organization?.max_employees,
      maxVehicles: organization?.max_vehicles,
    },
  };
};
