import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, DollarSign, Truck, FileText, Shield, Globe, Check, Star, Award, Play, ArrowRight, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-image.jpg";
import featureEmployees from "@/assets/feature-employees.jpg";
import featurePayroll from "@/assets/feature-payroll.jpg";
import featureFleet from "@/assets/feature-fleet.jpg";

const Landing = () => {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-xl">N</span>
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Nuzum
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/auth">
              <Button variant="ghost">Login</Button>
            </Link>
            <Link to="/auth">
              <Button className="gradient-hero">Get Started</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 gradient-primary opacity-5 animate-pulse"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,hsl(var(--primary)/0.1),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,hsl(var(--accent)/0.1),transparent_50%)]"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8 animate-fade-in">
              {/* Trust Badges */}
              <div className="flex flex-wrap gap-3">
                <Badge variant="secondary" className="text-xs px-3 py-1">
                  <Shield className="w-3 h-3 mr-1" />
                  ISO Certified
                </Badge>
                <Badge variant="secondary" className="text-xs px-3 py-1">
                  <Award className="w-3 h-3 mr-1" />
                  Trusted by 500+ Companies
                </Badge>
              </div>

              <h1 className="text-display font-bold leading-tight">
                Streamline Your
                <span className="block bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-gradient">
                  Workforce Management
                </span>
              </h1>
              
              <p className="text-h4 text-muted-foreground font-regular">
                Complete HR, Payroll, and Fleet Management solution designed for Saudi SMBs. 
                Manage your entire operation from one powerful platform.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Link to="/auth">
                  <Button size="lg" className="gradient-hero text-lg h-14 px-10 hover-scale shadow-elegant group">
                    Start Free Trial
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="text-lg h-14 px-10 group">
                  <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                  Watch Demo
                </Button>
              </div>
              
              <p className="text-sm text-muted-foreground">
                ✓ No credit card required • ✓ 14-day free trial • ✓ Setup in 5 minutes
              </p>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 pt-4">
                <div className="space-y-1">
                  <div className="text-h1 font-bold bg-gradient-to-br from-primary to-accent bg-clip-text text-transparent">500+</div>
                  <div className="text-small text-muted-foreground">Active Companies</div>
                </div>
                <div className="space-y-1">
                  <div className="text-h1 font-bold bg-gradient-to-br from-primary to-accent bg-clip-text text-transparent">50K+</div>
                  <div className="text-small text-muted-foreground">Employees Managed</div>
                </div>
                <div className="space-y-1">
                  <div className="text-h1 font-bold bg-gradient-to-br from-primary to-accent bg-clip-text text-transparent">99.9%</div>
                  <div className="text-small text-muted-foreground">Uptime</div>
                </div>
              </div>
            </div>

            {/* Hero Image with Floating Elements */}
            <div className="relative animate-fade-in" style={{ animationDelay: '0.2s' }}>
              {/* Glow Effect */}
              <div className="absolute inset-0 gradient-primary rounded-3xl blur-3xl opacity-20 animate-pulse"></div>
              
              {/* Main Image */}
              <div className="relative rounded-2xl shadow-2xl overflow-hidden border border-border/50">
                <img 
                  src={heroImage} 
                  alt="Workforce Management Dashboard showcasing employee, payroll, and fleet management features" 
                  className="w-full hover-scale"
                />
              </div>

              {/* Floating Stat Cards */}
              <div className="absolute -top-6 -right-6 bg-card border shadow-elegant rounded-2xl p-4 animate-float hidden lg:block">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-success-light flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-success" />
                  </div>
                  <div>
                    <div className="text-h4 font-bold">+24%</div>
                    <div className="text-xsmall text-muted-foreground">Efficiency</div>
                  </div>
                </div>
              </div>

              <div className="absolute -bottom-6 -left-6 bg-card border shadow-elegant rounded-2xl p-4 animate-float hidden lg:block" style={{ animationDelay: '1s' }}>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-info-light flex items-center justify-center">
                    <Star className="w-6 h-6 text-info" />
                  </div>
                  <div>
                    <div className="text-h4 font-bold">4.9/5</div>
                    <div className="text-xsmall text-muted-foreground">Rating</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section - Alternating Layout */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20 space-y-4">
            <Badge variant="outline" className="mb-4">
              <Star className="w-3 h-3 mr-1" />
              Platform Features
            </Badge>
            <h2 className="text-h1 font-bold">Everything You Need in One Platform</h2>
            <p className="text-h4 text-muted-foreground max-w-2xl mx-auto font-regular">
              Powerful features designed to simplify workforce, payroll, and fleet management for growing businesses
            </p>
          </div>

          {/* Feature 1 - Employee Management */}
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-24">
            <div className="space-y-6 order-2 lg:order-1">
              <Badge variant="secondary" className="mb-2">
                <Star className="w-3 h-3 mr-1 fill-primary text-primary" />
                Most Popular
              </Badge>
              <h3 className="text-h2 font-bold">Employee Management</h3>
              <p className="text-body text-muted-foreground">
                Register employees, track attendance, manage leaves, and store important documents all in one place. 
                Streamline your HR operations with our comprehensive employee management system.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <span>Real-time attendance tracking with mobile check-in</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <span>Automated leave request workflows and approvals</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <span>Centralized document storage with version control</span>
                </li>
              </ul>
              <Button className="gradient-hero mt-4 group">
                Learn More
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
            <div className="order-1 lg:order-2">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-border/50 hover-scale">
                <img src={featureEmployees} alt="Employee management dashboard showing attendance tracking and leave management" className="w-full" />
              </div>
            </div>
          </div>

          {/* Feature 2 - Smart Payroll */}
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-24">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-border/50 hover-scale">
              <img src={featurePayroll} alt="Payroll management system with automated salary calculations and reports" className="w-full" />
            </div>
            <div className="space-y-6">
              <h3 className="text-h2 font-bold">Smart Payroll</h3>
              <p className="text-body text-muted-foreground">
                Automate salary calculations, manage allowances, track deductions, and export reports instantly. 
                Ensure accurate and timely payroll processing every month.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <span>Automated salary calculations with overtime and bonuses</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <span>Tax and GOSI compliance with automatic deductions</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <span>One-click export to Excel, PDF, or accounting software</span>
                </li>
              </ul>
              <Button className="gradient-hero mt-4 group">
                Learn More
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>

          {/* Feature 3 - Fleet Tracking */}
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-16">
            <div className="space-y-6 order-2 lg:order-1">
              <h3 className="text-h2 font-bold">Fleet Tracking</h3>
              <p className="text-body text-muted-foreground">
                Register vehicles, log maintenance, set reminders, and keep your fleet running smoothly. 
                Never miss a service date or inspection again.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <span>Comprehensive vehicle registration and documentation</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <span>Automated maintenance reminders and scheduling</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <span>Fuel consumption tracking and cost analysis</span>
                </li>
              </ul>
              <Button className="gradient-hero mt-4 group">
                Learn More
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
            <div className="order-1 lg:order-2">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-border/50 hover-scale">
                <img src={featureFleet} alt="Fleet management dashboard with vehicle tracking and maintenance logs" className="w-full" />
              </div>
            </div>
          </div>

          {/* Additional Features Grid */}
          <div className="grid md:grid-cols-3 gap-8 mt-20">
            <Card className="hover:shadow-elegant transition-shadow">
              <CardContent className="p-8 space-y-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <FileText className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-h3 font-bold">Comprehensive Reports</h3>
                <p className="text-muted-foreground">
                  Generate attendance, payroll, and maintenance reports in PDF or Excel format with customizable templates.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-elegant transition-shadow">
              <CardContent className="p-8 space-y-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-success to-info flex items-center justify-center">
                  <Shield className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-h3 font-bold">Secure & Compliant</h3>
                <p className="text-muted-foreground">
                  Enterprise-grade security with role-based access control, data encryption, and GDPR compliance.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-elegant transition-shadow">
              <CardContent className="p-8 space-y-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-warning to-accent flex items-center justify-center">
                  <Globe className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-h3 font-bold">Bilingual Support</h3>
                <p className="text-muted-foreground">
                  Full Arabic and English support with RTL layout for seamless operation in Saudi Arabia.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-20 border-y bg-card/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-h2 font-bold mb-4">Trusted by Leading Saudi Companies</h2>
            <p className="text-body text-muted-foreground">Join hundreds of businesses already streamlining their operations with Nuzum</p>
          </div>
          
          {/* Testimonials */}
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2">
              <CardContent className="p-8 space-y-4">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-warning text-warning" />
                  ))}
                </div>
                <p className="text-muted-foreground italic">
                  "Nuzum transformed how we manage our 200+ employees. The payroll automation alone saves us 20 hours per month."
                </p>
                <div className="flex items-center gap-3 pt-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold">
                    AK
                  </div>
                  <div>
                    <div className="font-semibold">Ahmed Khalid</div>
                    <div className="text-small text-muted-foreground">HR Director, Construction Co.</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardContent className="p-8 space-y-4">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-warning text-warning" />
                  ))}
                </div>
                <p className="text-muted-foreground italic">
                  "The fleet management module is outstanding. We track all our vehicles, maintenance, and fuel costs in one place."
                </p>
                <div className="flex items-center gap-3 pt-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-success to-info flex items-center justify-center text-white font-bold">
                    FA
                  </div>
                  <div>
                    <div className="font-semibold">Fatima Al-Rashid</div>
                    <div className="text-small text-muted-foreground">Operations Manager, Logistics Inc.</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardContent className="p-8 space-y-4">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-warning text-warning" />
                  ))}
                </div>
                <p className="text-muted-foreground italic">
                  "Excellent support team and the bilingual interface makes it perfect for our mixed workforce. Highly recommended!"
                </p>
                <div className="flex items-center gap-3 pt-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-warning to-accent flex items-center justify-center text-white font-bold">
                    MS
                  </div>
                  <div>
                    <div className="font-semibold">Mohammed Saleh</div>
                    <div className="text-small text-muted-foreground">CEO, Retail Group</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 pt-12 border-t">
            <div className="text-center">
              <div className="text-h2 font-bold text-primary mb-2">500+</div>
              <div className="text-small text-muted-foreground">Active Companies</div>
            </div>
            <div className="text-center">
              <div className="text-h2 font-bold text-primary mb-2">50,000+</div>
              <div className="text-small text-muted-foreground">Employees Managed</div>
            </div>
            <div className="text-center">
              <div className="text-h2 font-bold text-primary mb-2">99.9%</div>
              <div className="text-small text-muted-foreground">Uptime SLA</div>
            </div>
            <div className="text-center">
              <div className="text-h2 font-bold text-primary mb-2">24/7</div>
              <div className="text-small text-muted-foreground">Support Available</div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 space-y-4">
            <Badge variant="outline" className="mb-4">
              <DollarSign className="w-3 h-3 mr-1" />
              Simple Pricing
            </Badge>
            <h2 className="text-h1 font-bold">Choose Your Plan</h2>
            <p className="text-h4 text-muted-foreground max-w-2xl mx-auto font-regular">
              Transparent pricing that scales with your business. No hidden fees.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Starter Plan */}
            <Card className="border-2">
              <CardContent className="p-8 space-y-6">
                <div>
                  <h3 className="text-h3 font-bold mb-2">Starter</h3>
                  <p className="text-small text-muted-foreground">Perfect for small businesses</p>
                </div>
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-h1 font-bold">SAR 299</span>
                    <span className="text-muted-foreground">/month</span>
                  </div>
                  <p className="text-xsmall text-muted-foreground mt-1">Up to 50 employees</p>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Employee Management</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Attendance Tracking</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Basic Payroll</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Email Support</span>
                  </li>
                </ul>
                <Link to="/auth" className="block">
                  <Button variant="outline" className="w-full">Start Free Trial</Button>
                </Link>
              </CardContent>
            </Card>

            {/* Professional Plan */}
            <Card className="border-2 border-primary shadow-elegant relative">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <Badge className="gradient-hero px-4 py-1">Most Popular</Badge>
              </div>
              <CardContent className="p-8 space-y-6">
                <div>
                  <h3 className="text-h3 font-bold mb-2">Professional</h3>
                  <p className="text-small text-muted-foreground">For growing companies</p>
                </div>
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-h1 font-bold">SAR 699</span>
                    <span className="text-muted-foreground">/month</span>
                  </div>
                  <p className="text-xsmall text-muted-foreground mt-1">Up to 200 employees</p>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Everything in Starter</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Fleet Management</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Advanced Payroll</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Custom Reports</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Priority Support</span>
                  </li>
                </ul>
                <Link to="/auth" className="block">
                  <Button className="gradient-hero w-full">Start Free Trial</Button>
                </Link>
              </CardContent>
            </Card>

            {/* Enterprise Plan */}
            <Card className="border-2">
              <CardContent className="p-8 space-y-6">
                <div>
                  <h3 className="text-h3 font-bold mb-2">Enterprise</h3>
                  <p className="text-small text-muted-foreground">For large organizations</p>
                </div>
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-h1 font-bold">Custom</span>
                  </div>
                  <p className="text-xsmall text-muted-foreground mt-1">Unlimited employees</p>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Everything in Professional</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Custom Integrations</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">Dedicated Account Manager</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">24/7 Phone Support</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-small">SLA Guarantee</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">Contact Sales</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card className="gradient-hero p-12 text-center text-white border-0">
            <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Business?</h2>
            <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
              Join hundreds of Saudi businesses already using Nuzum to streamline their operations
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to="/auth">
                <Button size="lg" variant="secondary" className="text-lg h-12 px-8">
                  Start Your Free Trial
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="text-lg h-12 px-8 bg-white/10 border-white/20 text-white hover:bg-white/20">
                Contact Sales
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-xl">N</span>
                </div>
                <span className="text-xl font-bold">Nuzum</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Complete workforce, payroll, and fleet management for Saudi SMBs
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Features</li>
                <li>Pricing</li>
                <li>Demo</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>About</li>
                <li>Contact</li>
                <li>Careers</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Privacy</li>
                <li>Terms</li>
                <li>Security</li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-12 pt-8 text-center text-sm text-muted-foreground">
            <p>© 2025 Nuzum. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
