import { Navigate } from "react-router-dom";
import { usePermissions } from "@/hooks/usePermissions";
import { useAuth } from "@/hooks/useAuth";
import { SuperAdminDashboard } from "@/components/admin/SuperAdminDashboard";
import DashboardLayout from "@/components/dashboard/DashboardLayout";

const SuperAdmin = () => {
  const { loading: authLoading } = useAuth();
  const { isSuperAdmin, loading: permissionsLoading } = usePermissions();

  console.log('🎯 SuperAdmin page render:', { 
    isSuperAdmin, 
    authLoading, 
    permissionsLoading,
    anyLoading: authLoading || permissionsLoading 
  });

  // Wait for both auth and permissions to finish loading
  if (authLoading || permissionsLoading) {
    console.log('⏳ Still loading auth/permissions...');
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-primary"></div>
          <p className="text-muted-foreground">جاري التحقق من الصلاحيات...</p>
        </div>
      </div>
    );
  }

  // Only redirect after everything has loaded and user is NOT super admin
  if (!isSuperAdmin) {
    console.log('⚠️ Access denied: User is not Super Admin, redirecting to dashboard');
    return <Navigate to="/dashboard" replace />;
  }

  console.log('✅ Access granted: Rendering Super Admin Dashboard');
  return (
    <DashboardLayout activeModule="super-admin" onModuleChange={() => {}}>
      <SuperAdminDashboard />
    </DashboardLayout>
  );
};

export default SuperAdmin;
