import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Shield, Zap, Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";

const loginSchema = z.object({
  email: z.string().trim().email({ message: "Invalid email address" }).max(255),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
});

const signupSchema = z.object({
  companyName: z.string().trim().min(1, { message: "Company name is required" }).max(100),
  email: z.string().trim().email({ message: "Invalid email address" }).max(255),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  confirmPassword: z.string().min(6, { message: "Password must be at least 6 characters" }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

const Auth = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/dashboard");
    }
  }, [isAuthenticated, navigate]);

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;

    try {
      const validation = loginSchema.safeParse({ email, password });
      
      if (!validation.success) {
        const fieldErrors: Record<string, string> = {};
        validation.error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
        setIsLoading(false);
        return;
      }

      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast({
          title: "Login failed",
          description: error.message,
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      toast({
        title: "Welcome back!",
        description: "You've successfully logged in.",
      });
      navigate("/dashboard");
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const companyName = formData.get("companyName") as string;
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;
    const confirmPassword = formData.get("confirmPassword") as string;

    try {
      const validation = signupSchema.safeParse({
        companyName,
        email,
        password,
        confirmPassword,
      });

      if (!validation.success) {
        const fieldErrors: Record<string, string> = {};
        validation.error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
        setIsLoading(false);
        return;
      }

      const redirectUrl = `${window.location.origin}/dashboard`;

      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            company_name: companyName,
          },
        },
      });

      if (error) {
        toast({
          title: "Signup failed",
          description: error.message,
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      toast({
        title: "Account created!",
        description: "Welcome to Nuzum. Let's get started.",
      });
      navigate("/dashboard");
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10 animate-gradient"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(var(--primary),0.1),transparent_50%)]"></div>
      
      <div className="w-full max-w-6xl mx-auto grid lg:grid-cols-2 gap-8 items-center relative z-10">
        {/* Left side - Features */}
        <div className="hidden lg:block space-y-8">
          <div className="space-y-4">
            <h1 className="text-h1 font-bold bg-gradient-primary bg-clip-text text-transparent">
              Manage Your Business with Confidence
            </h1>
            <p className="text-body text-muted-foreground">
              Streamline HR, payroll, and fleet management in one powerful platform trusted by 500+ companies.
            </p>
          </div>

          <div className="space-y-6">
            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Shield className="w-6 h-6 text-success" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">Bank-Grade Security</h3>
                <p className="text-small text-muted-foreground">Your data is encrypted and protected with enterprise-level security</p>
              </div>
            </div>

            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-info/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Zap className="w-6 h-6 text-info" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">Lightning Fast</h3>
                <p className="text-small text-muted-foreground">Real-time updates and instant access to your business data</p>
              </div>
            </div>

            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Lock className="w-6 h-6 text-warning" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">ISO Certified</h3>
                <p className="text-small text-muted-foreground">Compliant with international standards and regulations</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Auth Form */}
        <div className="w-full max-w-md mx-auto space-y-4">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-all hover:gap-3">
            <ArrowLeft className="w-4 h-4" />
            Back to home
          </Link>

          <Card className="border-2 shadow-2xl backdrop-blur-sm bg-background/95 animate-scale-in">
            <CardHeader className="text-center space-y-4 pb-6">
              <div className="flex items-center justify-center gap-2">
                <div className="w-16 h-16 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-lg animate-float">
                  <span className="text-primary-foreground font-bold text-3xl">N</span>
                </div>
              </div>
              <div className="space-y-2">
                <CardTitle className="text-h2 font-bold">Welcome to Nuzum</CardTitle>
                <CardDescription className="text-body">Sign in to your account or create a new one</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <Tabs defaultValue="login" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-8 p-1 bg-muted/50">
                  <TabsTrigger value="login" className="data-[state=active]:bg-gradient-primary data-[state=active]:text-primary-foreground">Login</TabsTrigger>
                  <TabsTrigger value="signup" className="data-[state=active]:bg-gradient-primary data-[state=active]:text-primary-foreground">Sign Up</TabsTrigger>
                </TabsList>

                <TabsContent value="login" className="space-y-6">
                  <form onSubmit={handleLogin} className="space-y-5">
                    <div className="space-y-2">
                      <Label htmlFor="login-email" className="text-sm font-medium">Email</Label>
                      <Input 
                        id="login-email"
                        name="email"
                        type="email" 
                        placeholder="name@company.com"
                        className="h-11 transition-all focus-visible:ring-primary"
                        required 
                      />
                      {errors.email && (
                        <p className="text-xsmall text-destructive animate-fade-in">{errors.email}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="login-password" className="text-sm font-medium">Password</Label>
                      <Input 
                        id="login-password"
                        name="password"
                        type="password"
                        className="h-11 transition-all focus-visible:ring-primary"
                        required 
                      />
                      {errors.password && (
                        <p className="text-xsmall text-destructive animate-fade-in">{errors.password}</p>
                      )}
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full h-11 gradient-hero font-semibold text-base shadow-lg hover:shadow-xl transition-all hover:scale-[1.02]" 
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <span className="flex items-center gap-2">
                          <span className="animate-spin">⏳</span>
                          Signing in...
                        </span>
                      ) : (
                        "Sign In"
                      )}
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="signup" className="space-y-6">
                  <form onSubmit={handleSignup} className="space-y-5">
                    <div className="space-y-2">
                      <Label htmlFor="signup-name" className="text-sm font-medium">Company Name</Label>
                      <Input 
                        id="signup-name"
                        name="companyName"
                        type="text" 
                        placeholder="Your Company"
                        className="h-11 transition-all focus-visible:ring-primary"
                        required 
                      />
                      {errors.companyName && (
                        <p className="text-xsmall text-destructive animate-fade-in">{errors.companyName}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-email" className="text-sm font-medium">Email</Label>
                      <Input 
                        id="signup-email"
                        name="email"
                        type="email" 
                        placeholder="name@company.com"
                        className="h-11 transition-all focus-visible:ring-primary"
                        required 
                      />
                      {errors.email && (
                        <p className="text-xsmall text-destructive animate-fade-in">{errors.email}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-password" className="text-sm font-medium">Password</Label>
                      <Input 
                        id="signup-password"
                        name="password"
                        type="password"
                        placeholder="Min. 6 characters"
                        className="h-11 transition-all focus-visible:ring-primary"
                        required 
                      />
                      {errors.password && (
                        <p className="text-xsmall text-destructive animate-fade-in">{errors.password}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-confirm" className="text-sm font-medium">Confirm Password</Label>
                      <Input 
                        id="signup-confirm"
                        name="confirmPassword"
                        type="password"
                        placeholder="Re-enter password"
                        className="h-11 transition-all focus-visible:ring-primary"
                        required 
                      />
                      {errors.confirmPassword && (
                        <p className="text-xsmall text-destructive animate-fade-in">{errors.confirmPassword}</p>
                      )}
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full h-11 gradient-hero font-semibold text-base shadow-lg hover:shadow-xl transition-all hover:scale-[1.02]" 
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <span className="flex items-center gap-2">
                          <span className="animate-spin">⏳</span>
                          Creating account...
                        </span>
                      ) : (
                        "Create Account"
                      )}
                    </Button>
                    <p className="text-xsmall text-center text-muted-foreground pt-2">
                      By signing up, you agree to our <span className="text-primary hover:underline cursor-pointer">Terms</span> and <span className="text-primary hover:underline cursor-pointer">Privacy Policy</span>
                    </p>
                  </form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card className="border shadow-lg backdrop-blur-sm bg-background/95">
            <CardContent className="p-5 text-center">
              <p className="text-small text-muted-foreground">
                <span className="inline-block w-2 h-2 bg-success rounded-full mr-2 animate-pulse"></span>
                Demo account available - no credit card required
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Auth;
