import { useState, useEffect } from "react";
import DashboardLayout from "@/components/dashboard/DashboardLayout";
import EmployeeManagement from "@/components/employees/EmployeeManagement";
import FleetList from "@/components/fleet/FleetList";
import { ReportsList } from "@/components/reports/ReportsList";
import { useModules } from "@/hooks/useModules";

const Dashboard = () => {
  const { getInitialModule, accessibleModules, isLoading } = useModules();
  const [activeModule, setActiveModule] = useState<string>("overview");

  // Set initial module based on user role on first render
  useEffect(() => {
    if (!isLoading) {
      const initialModule = getInitialModule();
      setActiveModule(initialModule);
    }
  }, [isLoading, getInitialModule]);

  // Dynamically update active module if user's accessible modules change
  useEffect(() => {
    if (!isLoading && activeModule !== 'overview' && !accessibleModules.includes(activeModule as any)) {
      const initialModule = getInitialModule();
      setActiveModule(initialModule);
    }
  }, [accessibleModules, isLoading, activeModule, getInitialModule]);

  return (
    <DashboardLayout activeModule={activeModule} onModuleChange={setActiveModule}>
      {activeModule === "employees" && <EmployeeManagement />}
      {activeModule === "fleet" && <FleetList />}
      {activeModule === "reports" && <ReportsList />}
    </DashboardLayout>
  );
};

export default Dashboard;
