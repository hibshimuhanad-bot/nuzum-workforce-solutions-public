-- Create suppliers table
CREATE TABLE public.suppliers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL,
  user_id UUID REFERENCES auth.users(id),
  
  -- Basic information
  name TEXT NOT NULL,
  supplier_type TEXT NOT NULL CHECK (supplier_type IN ('external', 'internal')),
  company_name TEXT,
  contact_person TEXT,
  email TEXT,
  phone TEXT NOT NULL,
  address TEXT,
  city TEXT,
  
  -- Financial information
  tax_number TEXT,
  bank_account TEXT,
  
  -- Additional information
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  rating DECIMAL(2,1) CHECK (rating >= 0 AND rating <= 5),
  total_invoices INTEGER DEFAULT 0,
  total_paid NUMERIC(12,2) DEFAULT 0,
  notes TEXT,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create vehicle rental agreements table
CREATE TABLE public.vehicle_rental_agreements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL,
  user_id UUID NOT NULL,
  
  -- Link to project and vehicle
  project_id UUID NOT NULL REFERENCES fleet_projects(id) ON DELETE CASCADE,
  vehicle_id UUID NOT NULL REFERENCES vehicles(id),
  supplier_id UUID NOT NULL REFERENCES suppliers(id),
  
  -- Rental terms
  daily_rate NUMERIC(10,2) NOT NULL,
  monthly_rate NUMERIC(10,2),
  billing_type TEXT NOT NULL CHECK (billing_type IN ('daily', 'monthly', 'custom')),
  
  -- Rental period
  start_date DATE NOT NULL,
  end_date DATE,
  
  -- Additional terms
  terms TEXT,
  penalties JSONB DEFAULT '{}'::jsonb,
  
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled')),
  notes TEXT,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  
  UNIQUE(project_id, vehicle_id)
);

-- Create project invoices table
CREATE TABLE public.project_invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL,
  user_id UUID NOT NULL,
  
  -- Invoice information
  invoice_number TEXT NOT NULL UNIQUE,
  invoice_date DATE NOT NULL,
  due_date DATE NOT NULL,
  
  -- Link to supplier and project
  supplier_id UUID NOT NULL REFERENCES suppliers(id),
  project_id UUID NOT NULL REFERENCES fleet_projects(id),
  
  -- Invoice type
  invoice_type TEXT NOT NULL CHECK (invoice_type IN ('single_vehicle', 'multiple_vehicles', 'monthly', 'on_demand')),
  billing_period_start DATE,
  billing_period_end DATE,
  
  -- Amounts
  subtotal NUMERIC(12,2) NOT NULL DEFAULT 0,
  tax_amount NUMERIC(12,2) DEFAULT 0,
  discount_amount NUMERIC(12,2) DEFAULT 0,
  penalties NUMERIC(12,2) DEFAULT 0,
  total_amount NUMERIC(12,2) NOT NULL,
  
  -- Status
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN (
    'draft',
    'pending',
    'approved',
    'rejected',
    'paid',
    'partially_paid',
    'overdue'
  )),
  
  -- Approval/rejection information
  approved_by UUID REFERENCES auth.users(id),
  approved_at TIMESTAMPTZ,
  rejected_by UUID REFERENCES auth.users(id),
  rejected_at TIMESTAMPTZ,
  rejection_reason TEXT,
  
  -- Payment information
  payment_date DATE,
  payment_method TEXT,
  payment_reference TEXT,
  paid_amount NUMERIC(12,2) DEFAULT 0,
  
  -- Attachments
  invoice_file TEXT,
  attachments TEXT[],
  
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create invoice line items table
CREATE TABLE public.invoice_line_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL,
  invoice_id UUID NOT NULL REFERENCES project_invoices(id) ON DELETE CASCADE,
  
  -- Item details
  vehicle_id UUID REFERENCES vehicles(id),
  rental_agreement_id UUID REFERENCES vehicle_rental_agreements(id),
  
  description TEXT NOT NULL,
  
  -- Period and quantity
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  days_count INTEGER NOT NULL,
  
  -- Prices
  unit_price NUMERIC(10,2) NOT NULL,
  quantity NUMERIC(8,2) DEFAULT 1,
  
  -- Adjustments
  discount_percent NUMERIC(5,2) DEFAULT 0,
  discount_amount NUMERIC(10,2) DEFAULT 0,
  penalty_amount NUMERIC(10,2) DEFAULT 0,
  penalty_reason TEXT,
  
  -- Total
  line_total NUMERIC(12,2) NOT NULL,
  
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create storage bucket for invoices
INSERT INTO storage.buckets (id, name, public) 
VALUES ('project-invoices', 'project-invoices', false)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on all tables
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_rental_agreements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.project_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoice_line_items ENABLE ROW LEVEL SECURITY;

-- RLS Policies for suppliers
CREATE POLICY "Users can view organization suppliers"
ON public.suppliers FOR SELECT
USING (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization suppliers"
ON public.suppliers FOR ALL
USING (organization_id = get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- RLS Policies for vehicle_rental_agreements
CREATE POLICY "Users can view organization rental agreements"
ON public.vehicle_rental_agreements FOR SELECT
USING (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization rental agreements"
ON public.vehicle_rental_agreements FOR ALL
USING (organization_id = get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- RLS Policies for project_invoices
CREATE POLICY "Users can view organization invoices"
ON public.project_invoices FOR SELECT
USING (
  organization_id = get_user_organization_id(auth.uid()) OR
  EXISTS (
    SELECT 1 FROM suppliers 
    WHERE suppliers.id = project_invoices.supplier_id 
    AND suppliers.user_id = auth.uid()
  )
);

CREATE POLICY "Users can manage organization invoices"
ON public.project_invoices FOR ALL
USING (organization_id = get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Suppliers can create their own invoices"
ON public.project_invoices FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM suppliers 
    WHERE suppliers.id = project_invoices.supplier_id 
    AND suppliers.user_id = auth.uid()
  )
);

-- RLS Policies for invoice_line_items
CREATE POLICY "Users can view organization invoice items"
ON public.invoice_line_items FOR SELECT
USING (
  organization_id = get_user_organization_id(auth.uid()) OR
  EXISTS (
    SELECT 1 FROM project_invoices pi
    JOIN suppliers s ON s.id = pi.supplier_id
    WHERE pi.id = invoice_line_items.invoice_id
    AND s.user_id = auth.uid()
  )
);

CREATE POLICY "Users can manage organization invoice items"
ON public.invoice_line_items FOR ALL
USING (organization_id = get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- Storage policies for project-invoices bucket
CREATE POLICY "Users can view organization invoice files"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'project-invoices' AND
  (storage.foldername(name))[1] = get_user_organization_id(auth.uid())::text
);

CREATE POLICY "Users can upload organization invoice files"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'project-invoices' AND
  (storage.foldername(name))[1] = get_user_organization_id(auth.uid())::text
);

CREATE POLICY "Users can update organization invoice files"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'project-invoices' AND
  (storage.foldername(name))[1] = get_user_organization_id(auth.uid())::text
);

CREATE POLICY "Users can delete organization invoice files"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'project-invoices' AND
  (storage.foldername(name))[1] = get_user_organization_id(auth.uid())::text
);

-- Create triggers for updated_at
CREATE TRIGGER update_suppliers_updated_at
  BEFORE UPDATE ON public.suppliers
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_rental_agreements_updated_at
  BEFORE UPDATE ON public.vehicle_rental_agreements
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_project_invoices_updated_at
  BEFORE UPDATE ON public.project_invoices
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();