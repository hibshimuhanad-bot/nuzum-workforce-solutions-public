
-- Update existing user role to super_admin
UPDATE user_roles 
SET role = 'super_admin'
WHERE user_id = '94c75602-7896-4e8d-9395-1b02f0b746b6';
