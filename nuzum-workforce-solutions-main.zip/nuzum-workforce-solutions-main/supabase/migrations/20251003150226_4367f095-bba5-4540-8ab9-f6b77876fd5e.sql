-- المرحلة 2: إنشاء Triggers للإشعارات التلقائية (34 نوع)

-- =====================================
-- 2.1 إشعارات الموظفين (10 أنواع)
-- =====================================

-- 1) إضافة موظف جديد
CREATE OR REPLACE FUNCTION public.notify_employee_created()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
BEGIN
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'موظف جديد',
      'تم إضافة الموظف: ' || NEW.name,
      'success',
      'employee',
      '/dashboard?module=employees',
      'عرض',
      'normal',
      jsonb_build_object('employee_id', NEW.id, 'employee_name', NEW.name)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER employee_created_notification
AFTER INSERT ON public.employees
FOR EACH ROW
EXECUTE FUNCTION public.notify_employee_created();

-- 2) تعديل بيانات موظف
CREATE OR REPLACE FUNCTION public.notify_employee_updated()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
BEGIN
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'تحديث بيانات موظف',
      'تم تحديث بيانات الموظف: ' || NEW.name,
      'info',
      'employee',
      '/dashboard?module=employees',
      'عرض',
      'low',
      jsonb_build_object('employee_id', NEW.id, 'employee_name', NEW.name)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER employee_updated_notification
AFTER UPDATE ON public.employees
FOR EACH ROW
WHEN (OLD.* IS DISTINCT FROM NEW.*)
EXECUTE FUNCTION public.notify_employee_updated();

-- 3) حذف موظف
CREATE OR REPLACE FUNCTION public.notify_employee_deleted()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
BEGIN
  admin_ids := public.get_admin_user_ids(OLD.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      OLD.organization_id,
      'حذف موظف',
      'تم حذف الموظف: ' || OLD.name,
      'warning',
      'employee',
      NULL,
      NULL,
      'high',
      jsonb_build_object('employee_name', OLD.name)
    );
  END IF;
  
  RETURN OLD;
END;
$$;

CREATE TRIGGER employee_deleted_notification
AFTER DELETE ON public.employees
FOR EACH ROW
EXECUTE FUNCTION public.notify_employee_deleted();

-- 4) طلب إجازة جديد
CREATE OR REPLACE FUNCTION public.notify_leave_request_created()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  employee_name TEXT;
BEGIN
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  SELECT name INTO employee_name FROM public.employees WHERE id = NEW.employee_id;
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'طلب إجازة جديد',
      'طلب إجازة من: ' || COALESCE(employee_name, 'موظف') || ' لمدة ' || NEW.days_count || ' يوم',
      'info',
      'employee',
      '/dashboard?module=leave',
      'مراجعة',
      'high',
      jsonb_build_object('leave_request_id', NEW.id, 'employee_name', employee_name, 'days', NEW.days_count)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER leave_request_created_notification
AFTER INSERT ON public.leave_requests
FOR EACH ROW
EXECUTE FUNCTION public.notify_leave_request_created();

-- 5) الموافقة/رفض الإجازة
CREATE OR REPLACE FUNCTION public.notify_leave_request_status_changed()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  employee_user_id UUID;
  employee_name TEXT;
  status_text TEXT;
BEGIN
  SELECT user_id, name INTO employee_user_id, employee_name 
  FROM public.employees WHERE id = NEW.employee_id;
  
  status_text := CASE 
    WHEN NEW.status = 'approved' THEN 'تمت الموافقة على'
    WHEN NEW.status = 'rejected' THEN 'تم رفض'
    ELSE 'تم تحديث'
  END;
  
  IF employee_user_id IS NOT NULL THEN
    PERFORM public.send_notification(
      ARRAY[employee_user_id],
      NEW.organization_id,
      'تحديث طلب الإجازة',
      status_text || ' طلب الإجازة الخاص بك',
      CASE WHEN NEW.status = 'approved' THEN 'success' ELSE 'warning' END,
      'employee',
      '/dashboard?module=leave',
      'عرض',
      'high',
      jsonb_build_object('leave_request_id', NEW.id, 'status', NEW.status)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER leave_request_status_changed_notification
AFTER UPDATE ON public.leave_requests
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION public.notify_leave_request_status_changed();

-- 6) إضافة سجل حضور بإضافي
CREATE OR REPLACE FUNCTION public.notify_overtime_detected()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  employee_name TEXT;
BEGIN
  SELECT name INTO employee_name FROM public.employees WHERE id = NEW.employee_id;
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL AND NEW.overtime_hours > 0 THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'ساعات إضافية',
      'ساعات إضافية للموظف: ' || COALESCE(employee_name, 'موظف') || ' - ' || NEW.overtime_hours || ' ساعة',
      'info',
      'employee',
      '/dashboard?module=attendance',
      'عرض',
      'normal',
      jsonb_build_object('employee_id', NEW.employee_id, 'overtime_hours', NEW.overtime_hours)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER overtime_detected_notification
AFTER INSERT OR UPDATE ON public.attendance_records
FOR EACH ROW
WHEN (NEW.overtime_hours > 0)
EXECUTE FUNCTION public.notify_overtime_detected();

-- 7) إضافة/تعديل راتب
CREATE OR REPLACE FUNCTION public.notify_payroll_created()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  employee_user_id UUID;
  employee_name TEXT;
BEGIN
  SELECT user_id, name INTO employee_user_id, employee_name 
  FROM public.employees WHERE id = NEW.employee_id;
  
  IF employee_user_id IS NOT NULL THEN
    PERFORM public.send_notification(
      ARRAY[employee_user_id],
      NEW.organization_id,
      'إضافة راتب',
      'تم إضافة راتب شهر ' || NEW.month || '/' || NEW.year,
      'success',
      'employee',
      '/dashboard?module=payroll',
      'عرض',
      'normal',
      jsonb_build_object('payroll_id', NEW.id, 'amount', NEW.net_salary)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER payroll_created_notification
AFTER INSERT ON public.payroll_records
FOR EACH ROW
EXECUTE FUNCTION public.notify_payroll_created();

-- 8) إضافة مرفق للموظف
CREATE OR REPLACE FUNCTION public.notify_employee_document_added()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  employee_user_id UUID;
  employee_name TEXT;
BEGIN
  SELECT user_id, name INTO employee_user_id, employee_name 
  FROM public.employees WHERE id = NEW.employee_id;
  
  IF employee_user_id IS NOT NULL THEN
    PERFORM public.send_notification(
      ARRAY[employee_user_id],
      NEW.organization_id,
      'مستند جديد',
      'تم إضافة مستند جديد: ' || NEW.document_name,
      'info',
      'employee',
      '/dashboard?module=documents',
      'عرض',
      'low',
      jsonb_build_object('document_id', NEW.id, 'document_name', NEW.document_name)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER employee_document_added_notification
AFTER INSERT ON public.employee_documents
FOR EACH ROW
EXECUTE FUNCTION public.notify_employee_document_added();

-- =====================================
-- 2.2 إشعارات الفليت (18 نوع)
-- =====================================

-- 9) إضافة سيارة جديدة
CREATE OR REPLACE FUNCTION public.notify_vehicle_created()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
BEGIN
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'سيارة جديدة',
      'تم إضافة سيارة جديدة: ' || NEW.make || ' ' || NEW.model || ' (' || NEW.plate_number || ')',
      'success',
      'fleet',
      '/dashboard?module=fleet',
      'عرض',
      'normal',
      jsonb_build_object('vehicle_id', NEW.id, 'plate_number', NEW.plate_number)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER vehicle_created_notification
AFTER INSERT ON public.vehicles
FOR EACH ROW
EXECUTE FUNCTION public.notify_vehicle_created();

-- 10) تعيين سيارة لموظف
CREATE OR REPLACE FUNCTION public.notify_vehicle_assigned()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  employee_user_id UUID;
  employee_name TEXT;
  vehicle_info TEXT;
BEGIN
  SELECT user_id, name INTO employee_user_id, employee_name 
  FROM public.employees WHERE id = NEW.employee_id;
  
  SELECT make || ' ' || model || ' (' || plate_number || ')' INTO vehicle_info
  FROM public.vehicles WHERE id = NEW.vehicle_id;
  
  IF employee_user_id IS NOT NULL THEN
    PERFORM public.send_notification(
      ARRAY[employee_user_id],
      NEW.organization_id,
      'تعيين سيارة',
      'تم تعيين السيارة: ' || COALESCE(vehicle_info, 'سيارة') || ' لك',
      'info',
      'fleet',
      '/dashboard?module=fleet',
      'عرض',
      'high',
      jsonb_build_object('assignment_id', NEW.id, 'vehicle_id', NEW.vehicle_id)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER vehicle_assigned_notification
AFTER INSERT ON public.vehicle_assignments
FOR EACH ROW
EXECUTE FUNCTION public.notify_vehicle_assigned();

-- 11) استلام سيارة من موظف
CREATE OR REPLACE FUNCTION public.notify_vehicle_returned()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  employee_name TEXT;
  vehicle_info TEXT;
BEGIN
  SELECT name INTO employee_name FROM public.employees WHERE id = NEW.employee_id;
  SELECT make || ' ' || model || ' (' || plate_number || ')' INTO vehicle_info
  FROM public.vehicles WHERE id = NEW.vehicle_id;
  
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'استلام سيارة',
      'تم استلام السيارة: ' || COALESCE(vehicle_info, 'سيارة') || ' من ' || COALESCE(employee_name, 'موظف'),
      'success',
      'fleet',
      '/dashboard?module=fleet',
      'عرض',
      'normal',
      jsonb_build_object('assignment_id', NEW.id, 'vehicle_id', NEW.vehicle_id)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER vehicle_returned_notification
AFTER UPDATE ON public.vehicle_assignments
FOR EACH ROW
WHEN (OLD.return_date IS NULL AND NEW.return_date IS NOT NULL)
EXECUTE FUNCTION public.notify_vehicle_returned();

-- 12) إضافة صيانة
CREATE OR REPLACE FUNCTION public.notify_maintenance_created()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  vehicle_info TEXT;
BEGIN
  SELECT make || ' ' || model || ' (' || plate_number || ')' INTO vehicle_info
  FROM public.vehicles WHERE id = NEW.vehicle_id;
  
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'صيانة جديدة',
      'تم إضافة صيانة للسيارة: ' || COALESCE(vehicle_info, 'سيارة') || ' - ' || NEW.maintenance_type,
      'info',
      'fleet',
      '/dashboard?module=maintenance',
      'عرض',
      'normal',
      jsonb_build_object('maintenance_id', NEW.id, 'vehicle_id', NEW.vehicle_id, 'cost', NEW.cost)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER maintenance_created_notification
AFTER INSERT ON public.vehicle_maintenance
FOR EACH ROW
EXECUTE FUNCTION public.notify_maintenance_created();

-- 13) تغيير حالة الصيانة
CREATE OR REPLACE FUNCTION public.notify_maintenance_status_changed()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  vehicle_info TEXT;
BEGIN
  SELECT make || ' ' || model || ' (' || plate_number || ')' INTO vehicle_info
  FROM public.vehicles WHERE id = NEW.vehicle_id;
  
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'تحديث حالة الصيانة',
      'تم تحديث حالة صيانة السيارة: ' || COALESCE(vehicle_info, 'سيارة') || ' إلى: ' || NEW.status,
      'info',
      'fleet',
      '/dashboard?module=maintenance',
      'عرض',
      'normal',
      jsonb_build_object('maintenance_id', NEW.id, 'status', NEW.status)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER maintenance_status_changed_notification
AFTER UPDATE ON public.vehicle_maintenance
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION public.notify_maintenance_status_changed();

-- 14) إضافة مشروع جديد
CREATE OR REPLACE FUNCTION public.notify_project_created()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
BEGIN
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'مشروع جديد',
      'تم إضافة مشروع جديد: ' || NEW.name,
      'success',
      'fleet',
      '/dashboard?module=projects',
      'عرض',
      'high',
      jsonb_build_object('project_id', NEW.id, 'project_name', NEW.name, 'budget', NEW.budget)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER project_created_notification
AFTER INSERT ON public.fleet_projects
FOR EACH ROW
EXECUTE FUNCTION public.notify_project_created();

-- 15) تعيين سيارة لمشروع
CREATE OR REPLACE FUNCTION public.notify_vehicle_project_assigned()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  vehicle_info TEXT;
  project_name TEXT;
BEGIN
  SELECT make || ' ' || model || ' (' || plate_number || ')' INTO vehicle_info
  FROM public.vehicles WHERE id = NEW.vehicle_id;
  
  SELECT name INTO project_name FROM public.fleet_projects WHERE id = NEW.project_id;
  
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'تعيين سيارة لمشروع',
      'تم تعيين السيارة: ' || COALESCE(vehicle_info, 'سيارة') || ' للمشروع: ' || COALESCE(project_name, 'مشروع'),
      'info',
      'fleet',
      '/dashboard?module=projects',
      'عرض',
      'normal',
      jsonb_build_object('assignment_id', NEW.id, 'project_id', NEW.project_id, 'vehicle_id', NEW.vehicle_id)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER vehicle_project_assigned_notification
AFTER INSERT ON public.vehicle_project_assignments
FOR EACH ROW
EXECUTE FUNCTION public.notify_vehicle_project_assigned();

-- 16) إضافة مورد
CREATE OR REPLACE FUNCTION public.notify_supplier_created()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
BEGIN
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'مورد جديد',
      'تم إضافة مورد جديد: ' || NEW.name,
      'success',
      'fleet',
      '/dashboard?module=suppliers',
      'عرض',
      'low',
      jsonb_build_object('supplier_id', NEW.id, 'supplier_name', NEW.name)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER supplier_created_notification
AFTER INSERT ON public.suppliers
FOR EACH ROW
EXECUTE FUNCTION public.notify_supplier_created();

-- 17) إضافة فاتورة
CREATE OR REPLACE FUNCTION public.notify_invoice_created()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  supplier_name TEXT;
  project_name TEXT;
BEGIN
  SELECT name INTO supplier_name FROM public.suppliers WHERE id = NEW.supplier_id;
  SELECT name INTO project_name FROM public.fleet_projects WHERE id = NEW.project_id;
  
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'فاتورة جديدة',
      'فاتورة جديدة من: ' || COALESCE(supplier_name, 'مورد') || ' - المشروع: ' || COALESCE(project_name, 'مشروع'),
      'info',
      'fleet',
      '/dashboard?module=invoices',
      'مراجعة',
      'high',
      jsonb_build_object('invoice_id', NEW.id, 'total_amount', NEW.total_amount, 'invoice_number', NEW.invoice_number)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER invoice_created_notification
AFTER INSERT ON public.project_invoices
FOR EACH ROW
EXECUTE FUNCTION public.notify_invoice_created();

-- 18) الموافقة/رفض فاتورة
CREATE OR REPLACE FUNCTION public.notify_invoice_status_changed()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  supplier_user_id UUID;
  status_text TEXT;
BEGIN
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  SELECT user_id INTO supplier_user_id FROM public.suppliers WHERE id = NEW.supplier_id;
  
  status_text := CASE 
    WHEN NEW.status = 'approved' THEN 'تمت الموافقة على'
    WHEN NEW.status = 'rejected' THEN 'تم رفض'
    WHEN NEW.status = 'paid' THEN 'تم دفع'
    ELSE 'تم تحديث'
  END;
  
  -- إشعار للمدراء
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'تحديث حالة فاتورة',
      status_text || ' الفاتورة رقم: ' || NEW.invoice_number,
      CASE WHEN NEW.status = 'approved' THEN 'success' WHEN NEW.status = 'rejected' THEN 'warning' ELSE 'info' END,
      'fleet',
      '/dashboard?module=invoices',
      'عرض',
      'normal',
      jsonb_build_object('invoice_id', NEW.id, 'status', NEW.status)
    );
  END IF;
  
  -- إشعار للمورد إذا كان له حساب
  IF supplier_user_id IS NOT NULL THEN
    PERFORM public.send_notification(
      ARRAY[supplier_user_id],
      NEW.organization_id,
      'تحديث حالة فاتورة',
      status_text || ' فاتورتك رقم: ' || NEW.invoice_number,
      CASE WHEN NEW.status = 'approved' THEN 'success' WHEN NEW.status = 'rejected' THEN 'warning' ELSE 'info' END,
      'fleet',
      NULL,
      NULL,
      'high',
      jsonb_build_object('invoice_id', NEW.id, 'status', NEW.status)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER invoice_status_changed_notification
AFTER UPDATE ON public.project_invoices
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION public.notify_invoice_status_changed();

-- 19) إضافة عقد إيجار
CREATE OR REPLACE FUNCTION public.notify_rental_agreement_created()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  vehicle_info TEXT;
  supplier_name TEXT;
BEGIN
  SELECT make || ' ' || model || ' (' || plate_number || ')' INTO vehicle_info
  FROM public.vehicles WHERE id = NEW.vehicle_id;
  
  SELECT name INTO supplier_name FROM public.suppliers WHERE id = NEW.supplier_id;
  
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'عقد إيجار جديد',
      'عقد إيجار جديد للسيارة: ' || COALESCE(vehicle_info, 'سيارة') || ' من: ' || COALESCE(supplier_name, 'مورد'),
      'success',
      'fleet',
      '/dashboard?module=rentals',
      'عرض',
      'high',
      jsonb_build_object('rental_id', NEW.id, 'vehicle_id', NEW.vehicle_id, 'daily_rate', NEW.daily_rate)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER rental_agreement_created_notification
AFTER INSERT ON public.vehicle_rental_agreements
FOR EACH ROW
EXECUTE FUNCTION public.notify_rental_agreement_created();

-- 20) إضافة وثيقة سيارة
CREATE OR REPLACE FUNCTION public.notify_vehicle_document_added()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  vehicle_info TEXT;
BEGIN
  SELECT make || ' ' || model || ' (' || plate_number || ')' INTO vehicle_info
  FROM public.vehicles WHERE id = NEW.vehicle_id;
  
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'وثيقة سيارة جديدة',
      'تم إضافة وثيقة: ' || NEW.document_name || ' للسيارة: ' || COALESCE(vehicle_info, 'سيارة'),
      'info',
      'fleet',
      '/dashboard?module=fleet',
      'عرض',
      'low',
      jsonb_build_object('document_id', NEW.id, 'vehicle_id', NEW.vehicle_id)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER vehicle_document_added_notification
AFTER INSERT ON public.vehicle_documents
FOR EACH ROW
EXECUTE FUNCTION public.notify_vehicle_document_added();

-- =====================================
-- 2.3 إشعارات النظام (6 أنواع)
-- =====================================

-- 21) تغيير دور مستخدم
CREATE OR REPLACE FUNCTION public.notify_user_role_changed()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_org_id UUID;
BEGIN
  SELECT organization_id INTO user_org_id FROM public.profiles WHERE id = NEW.user_id;
  
  PERFORM public.send_notification(
    ARRAY[NEW.user_id],
    user_org_id,
    'تحديث صلاحياتك',
    'تم تغيير دورك في النظام إلى: ' || NEW.role::text,
    'info',
    'system',
    NULL,
    NULL,
    'high',
    jsonb_build_object('new_role', NEW.role)
  );
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER user_role_changed_notification
AFTER UPDATE ON public.user_roles
FOR EACH ROW
WHEN (OLD.role IS DISTINCT FROM NEW.role)
EXECUTE FUNCTION public.notify_user_role_changed();

-- 22) إضافة مستخدم جديد للمنظمة
CREATE OR REPLACE FUNCTION public.notify_user_added()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  user_email TEXT;
BEGIN
  admin_ids := public.get_admin_user_ids(NEW.organization_id);
  
  SELECT email INTO user_email FROM public.profiles WHERE id = NEW.user_id;
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      NEW.organization_id,
      'مستخدم جديد',
      'تمت إضافة مستخدم جديد: ' || COALESCE(user_email, 'مستخدم'),
      'success',
      'system',
      '/dashboard?module=settings',
      'عرض',
      'normal',
      jsonb_build_object('user_id', NEW.user_id, 'role', NEW.role)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER user_added_notification
AFTER INSERT ON public.organization_members
FOR EACH ROW
EXECUTE FUNCTION public.notify_user_added();

-- 23) إزالة مستخدم من المنظمة
CREATE OR REPLACE FUNCTION public.notify_user_removed()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  user_email TEXT;
BEGIN
  admin_ids := public.get_admin_user_ids(OLD.organization_id);
  
  SELECT email INTO user_email FROM public.profiles WHERE id = OLD.user_id;
  
  IF admin_ids IS NOT NULL THEN
    PERFORM public.send_notification(
      admin_ids,
      OLD.organization_id,
      'إزالة مستخدم',
      'تمت إزالة المستخدم: ' || COALESCE(user_email, 'مستخدم'),
      'warning',
      'system',
      NULL,
      NULL,
      'normal',
      jsonb_build_object('user_email', user_email)
    );
  END IF;
  
  RETURN OLD;
END;
$$;

CREATE TRIGGER user_removed_notification
AFTER DELETE ON public.organization_members
FOR EACH ROW
EXECUTE FUNCTION public.notify_user_removed();