-- Add enabled_modules column to organizations table
ALTER TABLE public.organizations 
ADD COLUMN IF NOT EXISTS enabled_modules JSONB DEFAULT '{"employees": true, "fleet": true, "payroll": true, "attendance": true, "leave": true, "analytics": true, "reports": true}'::jsonb;

-- Create function to get organization usage statistics
CREATE OR REPLACE FUNCTION public.get_organization_usage_stats(_org_id UUID)
RETURNS TABLE (
  total_users BIGINT,
  total_employees BIGINT,
  total_vehicles BIGINT,
  employees_percentage NUMERIC,
  vehicles_percentage NUMERIC,
  total_payroll_records BIGINT,
  total_attendance_records BIGINT,
  total_leave_requests BIGINT,
  last_activity TIMESTAMP WITH TIME ZONE
) 
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    (SELECT COUNT(*) FROM organization_members WHERE organization_id = _org_id) as total_users,
    (SELECT COUNT(*) FROM employees WHERE organization_id = _org_id) as total_employees,
    (SELECT COUNT(*) FROM vehicles WHERE organization_id = _org_id) as total_vehicles,
    (SELECT CASE 
      WHEN (SELECT max_employees FROM organizations WHERE id = _org_id) > 0 
      THEN ((SELECT COUNT(*) FROM employees WHERE organization_id = _org_id)::NUMERIC / (SELECT max_employees FROM organizations WHERE id = _org_id)::NUMERIC * 100)
      ELSE 0 
     END) as employees_percentage,
    (SELECT CASE 
      WHEN (SELECT max_vehicles FROM organizations WHERE id = _org_id) > 0 
      THEN ((SELECT COUNT(*) FROM vehicles WHERE organization_id = _org_id)::NUMERIC / (SELECT max_vehicles FROM organizations WHERE id = _org_id)::NUMERIC * 100)
      ELSE 0 
     END) as vehicles_percentage,
    (SELECT COUNT(*) FROM payroll_records WHERE organization_id = _org_id) as total_payroll_records,
    (SELECT COUNT(*) FROM attendance_records WHERE organization_id = _org_id) as total_attendance_records,
    (SELECT COUNT(*) FROM leave_requests WHERE organization_id = _org_id) as total_leave_requests,
    (SELECT MAX(updated_at) FROM profiles WHERE organization_id = _org_id) as last_activity;
$$;

-- Create view for organizations overview
CREATE OR REPLACE VIEW public.organizations_overview AS
SELECT 
  o.id,
  o.name,
  o.slug,
  o.subscription_tier,
  o.is_active,
  o.created_at,
  o.expires_at,
  o.max_employees,
  o.max_vehicles,
  o.enabled_modules,
  (SELECT COUNT(*) FROM organization_members om WHERE om.organization_id = o.id) as members_count,
  (SELECT COUNT(*) FROM employees e WHERE e.organization_id = o.id) as employees_count,
  (SELECT COUNT(*) FROM vehicles v WHERE v.organization_id = o.id) as vehicles_count
FROM organizations o;

-- Update RLS policies for super_admin access to organizations
CREATE POLICY "Super admins can view all organizations"
ON public.organizations
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Super admins can update all organizations"
ON public.organizations
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'super_admin'))
WITH CHECK (has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Super admins can insert organizations"
ON public.organizations
FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'super_admin'));

-- Grant access to view
GRANT SELECT ON public.organizations_overview TO authenticated;