-- المرحلة 0: إعداد قاعدة البيانات لنظام التحكم في الصلاحيات

-- 1) تحديث RLS على permissions لـ Super Admin bypass
DROP POLICY IF EXISTS "Admins can manage permissions" ON public.permissions;
CREATE POLICY "Admins can manage permissions" ON public.permissions
  FOR ALL
  USING (
    has_permission(auth.uid(), 'manage_permissions') 
    OR has_role(auth.uid(), 'super_admin')
  )
  WITH CHECK (
    has_permission(auth.uid(), 'manage_permissions')
    OR has_role(auth.uid(), 'super_admin')
  );

-- 2) دالة لمزامنة الأدوار organization_members → user_roles
CREATE OR REPLACE FUNCTION sync_organization_member_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- إذا owner أو admin، أضف org_admin في user_roles
  IF NEW.role IN ('owner', 'admin') THEN
    INSERT INTO user_roles (user_id, role)
    VALUES (NEW.user_id, 'org_admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  ELSIF OLD.role IN ('owner', 'admin') AND NEW.role = 'member' THEN
    -- إذا تم تخفيض الدور إلى member، احذف org_admin
    DELETE FROM user_roles 
    WHERE user_id = NEW.user_id AND role = 'org_admin';
  END IF;
  
  RETURN NEW;
END;
$$;

-- إنشاء Trigger للمزامنة
DROP TRIGGER IF EXISTS sync_org_member_role_trigger ON organization_members;
CREATE TRIGGER sync_org_member_role_trigger
AFTER INSERT OR UPDATE OF role ON organization_members
FOR EACH ROW
EXECUTE FUNCTION sync_organization_member_role();

-- 3) إنشاء صلاحيات عامة افتراضية
INSERT INTO permissions (name, description, category, is_active)
VALUES 
  ('view_employees', 'عرض الموظفين', 'employees', true),
  ('manage_employees', 'إدارة الموظفين', 'employees', true),
  ('delete_employees', 'حذف الموظفين', 'employees', true),
  ('view_fleet', 'عرض المركبات', 'fleet', true),
  ('manage_fleet', 'إدارة المركبات', 'fleet', true),
  ('delete_fleet', 'حذف المركبات', 'fleet', true),
  ('view_payroll', 'عرض الرواتب', 'employees', true),
  ('manage_payroll', 'إدارة الرواتب', 'employees', true),
  ('view_attendance', 'عرض الحضور', 'employees', true),
  ('manage_attendance', 'إدارة الحضور', 'employees', true),
  ('view_leave', 'عرض الإجازات', 'employees', true),
  ('manage_leave', 'إدارة الإجازات', 'employees', true),
  ('view_reports', 'عرض التقارير', 'system', true),
  ('view_analytics', 'عرض التحليلات', 'system', true),
  ('manage_permissions', 'إدارة الصلاحيات', 'system', true),
  ('manage_organization', 'إدارة المنظمة', 'system', true),
  ('view_audit_logs', 'عرض سجلات التدقيق', 'system', true)
ON CONFLICT (name) DO NOTHING;

-- 4) تعيين صلاحيات افتراضية عامة (organization_id = NULL) للأدوار
DO $$
DECLARE
  perm_id UUID;
BEGIN
  -- Super Admin → كل شيء (عام)
  FOR perm_id IN SELECT id FROM permissions LOOP
    INSERT INTO role_permissions (role, permission_id, organization_id)
    VALUES ('super_admin', perm_id, NULL)
    ON CONFLICT DO NOTHING;
  END LOOP;
  
  -- Org Admin → كل شيء ماعدا manage_permissions (عام)
  FOR perm_id IN SELECT id FROM permissions WHERE name NOT IN ('manage_permissions') LOOP
    INSERT INTO role_permissions (role, permission_id, organization_id)
    VALUES ('org_admin', perm_id, NULL)
    ON CONFLICT DO NOTHING;
  END LOOP;
  
  -- HR → إدارة الموظفين والرواتب والإجازات (عام)
  FOR perm_id IN SELECT id FROM permissions WHERE name IN (
    'view_employees', 'manage_employees',
    'view_payroll', 'manage_payroll',
    'view_attendance', 'manage_attendance',
    'view_leave', 'manage_leave',
    'view_reports'
  ) LOOP
    INSERT INTO role_permissions (role, permission_id, organization_id)
    VALUES ('hr', perm_id, NULL)
    ON CONFLICT DO NOTHING;
  END LOOP;
  
  -- Manager → عرض وإدارة محدودة (عام)
  FOR perm_id IN SELECT id FROM permissions WHERE name IN (
    'view_employees', 'view_attendance', 'view_leave', 'manage_leave',
    'view_fleet', 'view_reports'
  ) LOOP
    INSERT INTO role_permissions (role, permission_id, organization_id)
    VALUES ('manager', perm_id, NULL)
    ON CONFLICT DO NOTHING;
  END LOOP;
  
  -- Employee → view فقط (عام)
  FOR perm_id IN SELECT id FROM permissions WHERE name LIKE 'view_%' 
    AND name NOT IN ('view_payroll', 'view_audit_logs') LOOP
    INSERT INTO role_permissions (role, permission_id, organization_id)
    VALUES ('employee', perm_id, NULL)
    ON CONFLICT DO NOTHING;
  END LOOP;
END $$;