-- ==========================================
-- المرحلة 1: تحسين جدول الأقسام
-- ==========================================

-- إضافة الحقول الجديدة للتسلسل الهرمي
ALTER TABLE public.departments 
ADD COLUMN IF NOT EXISTS parent_department_id UUID REFERENCES public.departments(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS level INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS path TEXT;

-- إنشاء index للأداء
CREATE INDEX IF NOT EXISTS idx_departments_parent ON public.departments(parent_department_id);
CREATE INDEX IF NOT EXISTS idx_departments_org_parent ON public.departments(organization_id, parent_department_id);

-- ==========================================
-- المرحلة 2: View للإحصائيات
-- ==========================================

CREATE OR REPLACE VIEW public.department_statistics AS
SELECT 
  d.id,
  d.name,
  d.organization_id,
  d.parent_department_id,
  d.level,
  d.path,
  d.manager_id,
  COUNT(DISTINCT e.id) as employee_count,
  COUNT(DISTINCT e.id) FILTER (WHERE e.status = 'active') as active_employee_count,
  COUNT(DISTINCT e.id) FILTER (WHERE e.status = 'inactive') as inactive_employee_count,
  COALESCE(AVG(e.salary) FILTER (WHERE e.status = 'active'), 0) as average_salary,
  COALESCE(SUM(e.salary) FILTER (WHERE e.status = 'active'), 0) as total_salary_cost,
  COALESCE(MIN(e.salary) FILTER (WHERE e.status = 'active'), 0) as min_salary,
  COALESCE(MAX(e.salary) FILTER (WHERE e.status = 'active'), 0) as max_salary
FROM public.departments d
LEFT JOIN public.employees e ON e.department_id = d.id
GROUP BY d.id, d.name, d.organization_id, d.parent_department_id, d.level, d.path, d.manager_id;

-- ==========================================
-- المرحلة 3: دالة للحصول على الشجرة
-- ==========================================

CREATE OR REPLACE FUNCTION public.get_department_tree(_dept_id UUID DEFAULT NULL, _org_id UUID DEFAULT NULL)
RETURNS TABLE (
  id UUID,
  name TEXT,
  parent_department_id UUID,
  level INTEGER,
  path TEXT,
  manager_id UUID,
  manager_name TEXT,
  employee_count BIGINT,
  active_employee_count BIGINT,
  total_salary_cost NUMERIC,
  has_children BOOLEAN
) 
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  WITH RECURSIVE dept_tree AS (
    -- Base case: إما قسم محدد أو جميع الأقسام الرئيسية للمنظمة
    SELECT 
      d.id, 
      d.name, 
      d.parent_department_id, 
      d.level,
      d.path,
      d.manager_id,
      0 as depth
    FROM public.departments d
    WHERE 
      CASE 
        WHEN _dept_id IS NOT NULL THEN d.id = _dept_id
        WHEN _org_id IS NOT NULL THEN d.organization_id = _org_id AND d.parent_department_id IS NULL
        ELSE d.parent_department_id IS NULL
      END
    
    UNION ALL
    
    -- Recursive case: الأقسام الفرعية
    SELECT 
      d.id, 
      d.name, 
      d.parent_department_id, 
      d.level,
      d.path,
      d.manager_id,
      dt.depth + 1
    FROM public.departments d
    INNER JOIN dept_tree dt ON d.parent_department_id = dt.id
  )
  SELECT 
    dt.id,
    dt.name,
    dt.parent_department_id,
    dt.level,
    dt.path,
    dt.manager_id,
    e.name as manager_name,
    COUNT(DISTINCT emp.id) as employee_count,
    COUNT(DISTINCT emp.id) FILTER (WHERE emp.status = 'active') as active_employee_count,
    COALESCE(SUM(emp.salary) FILTER (WHERE emp.status = 'active'), 0) as total_salary_cost,
    EXISTS (SELECT 1 FROM public.departments cd WHERE cd.parent_department_id = dt.id) as has_children
  FROM dept_tree dt
  LEFT JOIN public.employees e ON e.id = dt.manager_id
  LEFT JOIN public.employees emp ON emp.department_id = dt.id
  GROUP BY dt.id, dt.name, dt.parent_department_id, dt.level, dt.path, dt.manager_id, e.name
  ORDER BY dt.level, dt.name;
$$;

-- ==========================================
-- المرحلة 4: دالة لتحديث المسار والمستوى تلقائياً
-- ==========================================

CREATE OR REPLACE FUNCTION public.update_department_hierarchy()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  parent_path TEXT;
  parent_level INTEGER;
BEGIN
  IF NEW.parent_department_id IS NULL THEN
    -- قسم رئيسي
    NEW.level := 0;
    NEW.path := NEW.name;
  ELSE
    -- قسم فرعي: احصل على معلومات القسم الرئيسي
    SELECT d.path, d.level 
    INTO parent_path, parent_level
    FROM public.departments d
    WHERE d.id = NEW.parent_department_id;
    
    NEW.level := parent_level + 1;
    NEW.path := parent_path || ' / ' || NEW.name;
  END IF;
  
  RETURN NEW;
END;
$$;

-- تطبيق الـ trigger
DROP TRIGGER IF EXISTS update_department_hierarchy_trigger ON public.departments;
CREATE TRIGGER update_department_hierarchy_trigger
  BEFORE INSERT OR UPDATE OF parent_department_id, name ON public.departments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_department_hierarchy();

-- ==========================================
-- المرحلة 5: إضافة Audit Trail للأقسام
-- ==========================================

CREATE OR REPLACE FUNCTION public.log_department_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.audit_logs (
    entity_type,
    entity_id,
    action,
    user_id,
    organization_id,
    old_data,
    new_data
  ) VALUES (
    'department',
    COALESCE(NEW.id, OLD.id),
    TG_OP,
    auth.uid(),
    COALESCE(NEW.organization_id, OLD.organization_id),
    CASE WHEN TG_OP IN ('DELETE', 'UPDATE') THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN to_jsonb(NEW) ELSE NULL END
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- تطبيق الـ trigger للـ audit
DROP TRIGGER IF EXISTS audit_department_changes ON public.departments;
CREATE TRIGGER audit_department_changes
  AFTER INSERT OR UPDATE OR DELETE ON public.departments
  FOR EACH ROW
  EXECUTE FUNCTION public.log_department_changes();

-- ==========================================
-- المرحلة 6: الإشعارات
-- ==========================================

-- إشعار عند نقل موظف بين الأقسام
CREATE OR REPLACE FUNCTION public.notify_employee_department_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  old_dept_name TEXT;
  new_dept_name TEXT;
  old_manager_id UUID;
  new_manager_id UUID;
BEGIN
  -- إذا تغير القسم
  IF OLD.department_id IS DISTINCT FROM NEW.department_id THEN
    -- الحصول على أسماء الأقسام والمديرين
    SELECT name, manager_id INTO old_dept_name, old_manager_id 
    FROM public.departments WHERE id = OLD.department_id;
    
    SELECT name, manager_id INTO new_dept_name, new_manager_id 
    FROM public.departments WHERE id = NEW.department_id;
    
    -- إشعار مدير القسم القديم
    IF old_manager_id IS NOT NULL THEN
      PERFORM public.send_notification(
        ARRAY[old_manager_id],
        NEW.organization_id,
        'نقل موظف من القسم',
        'تم نقل الموظف ' || NEW.name || ' إلى قسم ' || COALESCE(new_dept_name, 'آخر'),
        'info',
        'department',
        '/dashboard?module=departments',
        'عرض',
        'normal',
        jsonb_build_object('employee_id', NEW.id, 'old_department', old_dept_name, 'new_department', new_dept_name)
      );
    END IF;
    
    -- إشعار مدير القسم الجديد
    IF new_manager_id IS NOT NULL THEN
      PERFORM public.send_notification(
        ARRAY[new_manager_id],
        NEW.organization_id,
        'موظف جديد في القسم',
        'تم نقل الموظف ' || NEW.name || ' إلى قسمك',
        'success',
        'department',
        '/dashboard?module=departments',
        'عرض',
        'high',
        jsonb_build_object('employee_id', NEW.id, 'old_department', old_dept_name)
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS notify_employee_department_change ON public.employees;
CREATE TRIGGER notify_employee_department_change
  AFTER UPDATE OF department_id ON public.employees
  FOR EACH ROW
  WHEN (OLD.department_id IS DISTINCT FROM NEW.department_id)
  EXECUTE FUNCTION public.notify_employee_department_change();

-- إشعار عند تغيير مدير القسم
CREATE OR REPLACE FUNCTION public.notify_department_manager_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_ids UUID[];
  old_manager_name TEXT;
  new_manager_name TEXT;
BEGIN
  IF OLD.manager_id IS DISTINCT FROM NEW.manager_id THEN
    admin_ids := public.get_admin_user_ids(NEW.organization_id);
    
    SELECT name INTO old_manager_name FROM public.employees WHERE id = OLD.manager_id;
    SELECT name INTO new_manager_name FROM public.employees WHERE id = NEW.manager_id;
    
    -- إشعار للإدارة
    IF admin_ids IS NOT NULL THEN
      PERFORM public.send_notification(
        admin_ids,
        NEW.organization_id,
        'تغيير مدير قسم',
        'تم تغيير مدير قسم ' || NEW.name || ' من ' || COALESCE(old_manager_name, 'بدون مدير') || ' إلى ' || COALESCE(new_manager_name, 'بدون مدير'),
        'info',
        'department',
        '/dashboard?module=departments',
        'عرض',
        'normal',
        jsonb_build_object('department_id', NEW.id, 'old_manager', old_manager_name, 'new_manager', new_manager_name)
      );
    END IF;
    
    -- إشعار للمدير الجديد
    IF NEW.manager_id IS NOT NULL THEN
      PERFORM public.send_notification(
        ARRAY[NEW.manager_id],
        NEW.organization_id,
        'تم تعيينك مديراً',
        'تم تعيينك مديراً لقسم ' || NEW.name,
        'success',
        'department',
        '/dashboard?module=departments',
        'عرض',
        'high',
        jsonb_build_object('department_id', NEW.id)
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS notify_department_manager_change ON public.departments;
CREATE TRIGGER notify_department_manager_change
  AFTER UPDATE OF manager_id ON public.departments
  FOR EACH ROW
  WHEN (OLD.manager_id IS DISTINCT FROM NEW.manager_id)
  EXECUTE FUNCTION public.notify_department_manager_change();