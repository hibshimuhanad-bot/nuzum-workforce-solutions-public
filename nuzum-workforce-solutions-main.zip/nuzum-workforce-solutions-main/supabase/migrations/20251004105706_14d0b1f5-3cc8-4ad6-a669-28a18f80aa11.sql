-- Create update_updated_at_column function if it doesn't exist
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create vehicle_check_in_out table for vehicle attendance system
CREATE TABLE IF NOT EXISTS public.vehicle_check_in_out (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  driver_id UUID REFERENCES public.employees(id) ON DELETE SET NULL,
  check_in TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  check_out TIMESTAMP WITH TIME ZONE,
  odometer_in INTEGER,
  odometer_out INTEGER,
  fuel_level_in NUMERIC(5,2),
  fuel_level_out NUMERIC(5,2),
  condition_in TEXT,
  condition_out TEXT,
  photos_in TEXT[],
  photos_out TEXT[],
  notes TEXT,
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.vehicle_check_in_out ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view organization vehicle check-ins"
ON public.vehicle_check_in_out FOR SELECT
USING (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization vehicle check-ins"
ON public.vehicle_check_in_out FOR ALL
USING (organization_id = get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- Indexes for better performance
CREATE INDEX idx_vehicle_checkin_vehicle ON public.vehicle_check_in_out(vehicle_id);
CREATE INDEX idx_vehicle_checkin_driver ON public.vehicle_check_in_out(driver_id);
CREATE INDEX idx_vehicle_checkin_org ON public.vehicle_check_in_out(organization_id);
CREATE INDEX idx_vehicle_checkin_date ON public.vehicle_check_in_out(check_in);

-- Trigger to update updated_at
CREATE TRIGGER update_vehicle_checkin_updated_at
BEFORE UPDATE ON public.vehicle_check_in_out
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Audit trail trigger
CREATE OR REPLACE FUNCTION log_vehicle_checkin_changes()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO audit_logs (entity_type, entity_id, action, new_data, user_id, organization_id)
    VALUES ('vehicle_check_in_out', NEW.id, 'CREATE', to_jsonb(NEW), auth.uid(), NEW.organization_id);
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO audit_logs (entity_type, entity_id, action, old_data, new_data, user_id, organization_id)
    VALUES ('vehicle_check_in_out', NEW.id, 'UPDATE', to_jsonb(OLD), to_jsonb(NEW), auth.uid(), NEW.organization_id);
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO audit_logs (entity_type, entity_id, action, old_data, user_id, organization_id)
    VALUES ('vehicle_check_in_out', OLD.id, 'DELETE', to_jsonb(OLD), auth.uid(), OLD.organization_id);
    RETURN OLD;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER vehicle_checkin_audit_trigger
AFTER INSERT OR UPDATE OR DELETE ON public.vehicle_check_in_out
FOR EACH ROW EXECUTE FUNCTION log_vehicle_checkin_changes();