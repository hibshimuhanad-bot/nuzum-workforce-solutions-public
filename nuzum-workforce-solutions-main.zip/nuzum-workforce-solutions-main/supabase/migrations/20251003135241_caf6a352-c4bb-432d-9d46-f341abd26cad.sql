-- Add vehicles_count field to fleet_projects table
ALTER TABLE public.fleet_projects 
ADD COLUMN IF NOT EXISTS vehicles_count INTEGER DEFAULT 0;

-- Update existing projects to set vehicles_count to 0 if null
UPDATE public.fleet_projects 
SET vehicles_count = 0 
WHERE vehicles_count IS NULL;