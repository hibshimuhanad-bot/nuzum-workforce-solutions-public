-- Create enum types
CREATE TYPE public.app_role AS ENUM ('admin', 'manager', 'employee');
CREATE TYPE public.leave_type AS ENUM ('annual', 'sick', 'emergency', 'unpaid');
CREATE TYPE public.leave_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE public.vehicle_status AS ENUM ('active', 'maintenance', 'retired');
CREATE TYPE public.document_category AS ENUM ('contract', 'certificate', 'id_document', 'license', 'other');

-- User Roles Table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL DEFAULT 'employee',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Salary Templates Table
CREATE TABLE public.salary_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  base_salary DECIMAL(10,2) NOT NULL,
  housing_allowance DECIMAL(10,2) DEFAULT 0,
  transport_allowance DECIMAL(10,2) DEFAULT 0,
  food_allowance DECIMAL(10,2) DEFAULT 0,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Payroll Records Table
CREATE TABLE public.payroll_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  salary_template_id UUID REFERENCES public.salary_templates(id),
  month INTEGER NOT NULL CHECK (month >= 1 AND month <= 12),
  year INTEGER NOT NULL CHECK (year >= 2000),
  base_salary DECIMAL(10,2) NOT NULL,
  total_allowances DECIMAL(10,2) DEFAULT 0,
  total_deductions DECIMAL(10,2) DEFAULT 0,
  overtime_amount DECIMAL(10,2) DEFAULT 0,
  net_salary DECIMAL(10,2) NOT NULL,
  payment_date TIMESTAMPTZ,
  notes TEXT,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(employee_id, month, year)
);

-- Allowances Table
CREATE TABLE public.allowances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  is_recurring BOOLEAN DEFAULT true,
  effective_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_date TIMESTAMPTZ,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Deductions Table
CREATE TABLE public.deductions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  is_recurring BOOLEAN DEFAULT true,
  effective_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_date TIMESTAMPTZ,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Vehicles Table
CREATE TABLE public.vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plate_number TEXT NOT NULL,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER NOT NULL,
  color TEXT,
  vin TEXT,
  registration_date TIMESTAMPTZ NOT NULL,
  insurance_expiry TIMESTAMPTZ,
  status public.vehicle_status NOT NULL DEFAULT 'active',
  current_mileage INTEGER DEFAULT 0,
  notes TEXT,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(plate_number, user_id)
);

-- Vehicle Maintenance Table
CREATE TABLE public.vehicle_maintenance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  maintenance_type TEXT NOT NULL,
  description TEXT,
  cost DECIMAL(10,2),
  maintenance_date TIMESTAMPTZ NOT NULL,
  next_maintenance_date TIMESTAMPTZ,
  mileage INTEGER,
  performed_by TEXT,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Vehicle Assignments Table
CREATE TABLE public.vehicle_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  assigned_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  return_date TIMESTAMPTZ,
  notes TEXT,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Fuel Logs Table
CREATE TABLE public.fuel_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  employee_id UUID REFERENCES public.employees(id) ON DELETE SET NULL,
  liters DECIMAL(8,2) NOT NULL,
  cost DECIMAL(10,2) NOT NULL,
  mileage INTEGER NOT NULL,
  fuel_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  station_name TEXT,
  notes TEXT,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Attendance Records Table
CREATE TABLE public.attendance_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  check_in TIMESTAMPTZ NOT NULL,
  check_out TIMESTAMPTZ,
  work_hours DECIMAL(5,2),
  overtime_hours DECIMAL(5,2) DEFAULT 0,
  notes TEXT,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Leave Requests Table
CREATE TABLE public.leave_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  leave_type public.leave_type NOT NULL,
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ NOT NULL,
  days_count INTEGER NOT NULL,
  reason TEXT,
  status public.leave_status NOT NULL DEFAULT 'pending',
  approved_by UUID REFERENCES auth.users(id),
  approved_at TIMESTAMPTZ,
  rejection_reason TEXT,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Overtime Records Table
CREATE TABLE public.overtime_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  date TIMESTAMPTZ NOT NULL,
  hours DECIMAL(5,2) NOT NULL,
  rate_multiplier DECIMAL(3,2) DEFAULT 1.5,
  amount DECIMAL(10,2),
  approved BOOLEAN DEFAULT false,
  approved_by UUID REFERENCES auth.users(id),
  notes TEXT,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Employee Documents Table
CREATE TABLE public.employee_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  document_name TEXT NOT NULL,
  category public.document_category NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER,
  issue_date TIMESTAMPTZ,
  expiry_date TIMESTAMPTZ,
  notes TEXT,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.salary_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payroll_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.allowances ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deductions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_maintenance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fuel_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.overtime_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employee_documents ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_roles
CREATE POLICY "Users can view own role" ON public.user_roles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own role" ON public.user_roles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own role" ON public.user_roles FOR UPDATE USING (auth.uid() = user_id);

-- RLS Policies for salary_templates
CREATE POLICY "Users can view own salary templates" ON public.salary_templates FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own salary templates" ON public.salary_templates FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own salary templates" ON public.salary_templates FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own salary templates" ON public.salary_templates FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for payroll_records
CREATE POLICY "Users can view own payroll records" ON public.payroll_records FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own payroll records" ON public.payroll_records FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own payroll records" ON public.payroll_records FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own payroll records" ON public.payroll_records FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for allowances
CREATE POLICY "Users can view own allowances" ON public.allowances FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own allowances" ON public.allowances FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own allowances" ON public.allowances FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own allowances" ON public.allowances FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for deductions
CREATE POLICY "Users can view own deductions" ON public.deductions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own deductions" ON public.deductions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own deductions" ON public.deductions FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own deductions" ON public.deductions FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for vehicles
CREATE POLICY "Users can view own vehicles" ON public.vehicles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own vehicles" ON public.vehicles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own vehicles" ON public.vehicles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own vehicles" ON public.vehicles FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for vehicle_maintenance
CREATE POLICY "Users can view own vehicle maintenance" ON public.vehicle_maintenance FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own vehicle maintenance" ON public.vehicle_maintenance FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own vehicle maintenance" ON public.vehicle_maintenance FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own vehicle maintenance" ON public.vehicle_maintenance FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for vehicle_assignments
CREATE POLICY "Users can view own vehicle assignments" ON public.vehicle_assignments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own vehicle assignments" ON public.vehicle_assignments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own vehicle assignments" ON public.vehicle_assignments FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own vehicle assignments" ON public.vehicle_assignments FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for fuel_logs
CREATE POLICY "Users can view own fuel logs" ON public.fuel_logs FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own fuel logs" ON public.fuel_logs FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own fuel logs" ON public.fuel_logs FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own fuel logs" ON public.fuel_logs FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for attendance_records
CREATE POLICY "Users can view own attendance records" ON public.attendance_records FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own attendance records" ON public.attendance_records FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own attendance records" ON public.attendance_records FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own attendance records" ON public.attendance_records FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for leave_requests
CREATE POLICY "Users can view own leave requests" ON public.leave_requests FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own leave requests" ON public.leave_requests FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own leave requests" ON public.leave_requests FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own leave requests" ON public.leave_requests FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for overtime_records
CREATE POLICY "Users can view own overtime records" ON public.overtime_records FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own overtime records" ON public.overtime_records FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own overtime records" ON public.overtime_records FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own overtime records" ON public.overtime_records FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for employee_documents
CREATE POLICY "Users can view own employee documents" ON public.employee_documents FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own employee documents" ON public.employee_documents FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own employee documents" ON public.employee_documents FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own employee documents" ON public.employee_documents FOR DELETE USING (auth.uid() = user_id);

-- Create triggers for updated_at
CREATE TRIGGER update_user_roles_updated_at BEFORE UPDATE ON public.user_roles FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_salary_templates_updated_at BEFORE UPDATE ON public.salary_templates FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_payroll_records_updated_at BEFORE UPDATE ON public.payroll_records FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_allowances_updated_at BEFORE UPDATE ON public.allowances FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_deductions_updated_at BEFORE UPDATE ON public.deductions FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_vehicles_updated_at BEFORE UPDATE ON public.vehicles FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_vehicle_maintenance_updated_at BEFORE UPDATE ON public.vehicle_maintenance FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_vehicle_assignments_updated_at BEFORE UPDATE ON public.vehicle_assignments FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_fuel_logs_updated_at BEFORE UPDATE ON public.fuel_logs FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_attendance_records_updated_at BEFORE UPDATE ON public.attendance_records FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_leave_requests_updated_at BEFORE UPDATE ON public.leave_requests FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_overtime_records_updated_at BEFORE UPDATE ON public.overtime_records FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
CREATE TRIGGER update_employee_documents_updated_at BEFORE UPDATE ON public.employee_documents FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- Create indexes for better query performance
CREATE INDEX idx_payroll_records_employee ON public.payroll_records(employee_id);
CREATE INDEX idx_payroll_records_date ON public.payroll_records(year, month);
CREATE INDEX idx_vehicles_status ON public.vehicles(status);
CREATE INDEX idx_vehicle_assignments_vehicle ON public.vehicle_assignments(vehicle_id);
CREATE INDEX idx_vehicle_assignments_employee ON public.vehicle_assignments(employee_id);
CREATE INDEX idx_attendance_employee ON public.attendance_records(employee_id);
CREATE INDEX idx_attendance_date ON public.attendance_records(check_in);
CREATE INDEX idx_leave_requests_employee ON public.leave_requests(employee_id);
CREATE INDEX idx_leave_requests_status ON public.leave_requests(status);
CREATE INDEX idx_employee_documents_employee ON public.employee_documents(employee_id);
CREATE INDEX idx_employee_documents_category ON public.employee_documents(category);