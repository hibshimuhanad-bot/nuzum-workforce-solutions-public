-- Add city field to vehicle_maintenance table
ALTER TABLE public.vehicle_maintenance 
  ADD COLUMN IF NOT EXISTS city TEXT;