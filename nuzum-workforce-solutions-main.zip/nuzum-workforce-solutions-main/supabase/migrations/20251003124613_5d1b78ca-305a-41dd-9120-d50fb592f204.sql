-- Add images support for vehicles and maintenance

-- Add images column to vehicles table
ALTER TABLE public.vehicles 
  ADD COLUMN IF NOT EXISTS images TEXT[] DEFAULT '{}';

-- Add before and after photos to vehicle_maintenance table
ALTER TABLE public.vehicle_maintenance 
  ADD COLUMN IF NOT EXISTS before_photos TEXT[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS after_photos TEXT[] DEFAULT '{}';