-- =============================================
-- Phase 1: Multi-Tenancy Core Infrastructure
-- =============================================

-- 1. Create organizations table
CREATE TABLE public.organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  subscription_tier TEXT NOT NULL DEFAULT 'free',
  max_employees INTEGER DEFAULT 10,
  max_vehicles INTEGER DEFAULT 5,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE,
  settings JSONB DEFAULT '{}'::jsonb,
  logo_url TEXT,
  address TEXT,
  phone TEXT,
  industry TEXT
);

-- Enable RLS on organizations
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;

-- 2. Create organization_members junction table
CREATE TABLE public.organization_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role TEXT NOT NULL DEFAULT 'member',
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(organization_id, user_id)
);

-- Enable RLS on organization_members
ALTER TABLE public.organization_members ENABLE ROW LEVEL SECURITY;

-- 3. Update profiles table with organization_id
ALTER TABLE public.profiles 
ADD COLUMN organization_id UUID REFERENCES public.organizations(id),
ADD COLUMN locale TEXT DEFAULT 'en',
ADD COLUMN timezone TEXT DEFAULT 'Asia/Riyadh';

-- 4. Add organization_id to all existing tables
ALTER TABLE public.employees ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.vehicles ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.attendance_records ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.payroll_records ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.leave_requests ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.employee_documents ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.salary_templates ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.allowances ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.deductions ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.overtime_records ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.vehicle_assignments ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.vehicle_maintenance ADD COLUMN organization_id UUID REFERENCES public.organizations(id);
ALTER TABLE public.fuel_logs ADD COLUMN organization_id UUID REFERENCES public.organizations(id);

-- 5. Create security definer function to check user role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- 6. Create function to get user's organization_id
CREATE OR REPLACE FUNCTION public.get_user_organization_id(_user_id UUID)
RETURNS UUID
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT organization_id 
  FROM public.profiles 
  WHERE id = _user_id
$$;

-- 7. Update handle_new_user function to be more secure
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_org_id UUID;
  org_name TEXT;
BEGIN
  -- Get organization name from metadata
  org_name := COALESCE(
    new.raw_user_meta_data->>'company_name',
    new.email
  );
  
  -- Create organization for new user
  INSERT INTO public.organizations (name, slug, subscription_tier)
  VALUES (
    org_name,
    lower(replace(org_name || '-' || substring(new.id::text from 1 for 8), ' ', '-')),
    'free'
  )
  RETURNING id INTO new_org_id;
  
  -- Create profile
  INSERT INTO public.profiles (id, email, company_name, organization_id)
  VALUES (
    new.id,
    new.email,
    org_name,
    new_org_id
  );
  
  -- Add user as organization owner
  INSERT INTO public.organization_members (organization_id, user_id, role)
  VALUES (new_org_id, new.id, 'owner');
  
  -- Set user role as org_admin
  INSERT INTO public.user_roles (user_id, role)
  VALUES (new.id, 'org_admin');
  
  RETURN new;
END;
$$;

-- Recreate trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- 8. Drop old insecure RLS policies and create new secure ones

-- Organizations policies
CREATE POLICY "Users can view own organization"
ON public.organizations
FOR SELECT
USING (
  id = public.get_user_organization_id(auth.uid())
  OR public.has_role(auth.uid(), 'super_admin')
);

CREATE POLICY "Organization owners can update"
ON public.organizations
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.organization_members
    WHERE organization_id = organizations.id
      AND user_id = auth.uid()
      AND role = 'owner'
  )
  OR public.has_role(auth.uid(), 'super_admin')
);

-- Organization members policies
CREATE POLICY "Users can view own organization members"
ON public.organization_members
FOR SELECT
USING (
  organization_id = public.get_user_organization_id(auth.uid())
  OR public.has_role(auth.uid(), 'super_admin')
);

CREATE POLICY "Organization owners can manage members"
ON public.organization_members
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.organization_members om
    WHERE om.organization_id = organization_members.organization_id
      AND om.user_id = auth.uid()
      AND om.role IN ('owner', 'admin')
  )
  OR public.has_role(auth.uid(), 'super_admin')
);

-- Update profiles policies
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;

CREATE POLICY "Users can view own organization profiles"
ON public.profiles
FOR SELECT
USING (
  organization_id = public.get_user_organization_id(auth.uid())
  OR id = auth.uid()
  OR public.has_role(auth.uid(), 'super_admin')
);

CREATE POLICY "Users can update own profile"
ON public.profiles
FOR UPDATE
USING (id = auth.uid());

CREATE POLICY "System can insert profiles"
ON public.profiles
FOR INSERT
WITH CHECK (id = auth.uid());

-- Fix critical security issue in user_roles
DROP POLICY IF EXISTS "Users can update own role" ON public.user_roles;
DROP POLICY IF EXISTS "Users can view own role" ON public.user_roles;
DROP POLICY IF EXISTS "Users can insert own role" ON public.user_roles;

CREATE POLICY "Users can view own organization roles"
ON public.user_roles
FOR SELECT
USING (
  user_id IN (
    SELECT p.id FROM public.profiles p
    WHERE p.organization_id = public.get_user_organization_id(auth.uid())
  )
  OR user_id = auth.uid()
  OR public.has_role(auth.uid(), 'super_admin')
);

CREATE POLICY "Only org admins and super admins can manage roles"
ON public.user_roles
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.organization_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
  )
  OR public.has_role(auth.uid(), 'super_admin')
);

-- Update all table RLS policies to use organization_id

-- Employees
DROP POLICY IF EXISTS "Users can view own employees" ON public.employees;
DROP POLICY IF EXISTS "Users can insert own employees" ON public.employees;
DROP POLICY IF EXISTS "Users can update own employees" ON public.employees;
DROP POLICY IF EXISTS "Users can delete own employees" ON public.employees;

CREATE POLICY "Users can view organization employees"
ON public.employees FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization employees"
ON public.employees FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Vehicles
DROP POLICY IF EXISTS "Users can view own vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Users can insert own vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Users can update own vehicles" ON public.vehicles;
DROP POLICY IF EXISTS "Users can delete own vehicles" ON public.vehicles;

CREATE POLICY "Users can view organization vehicles"
ON public.vehicles FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization vehicles"
ON public.vehicles FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Attendance records
DROP POLICY IF EXISTS "Users can view own attendance records" ON public.attendance_records;
DROP POLICY IF EXISTS "Users can insert own attendance records" ON public.attendance_records;
DROP POLICY IF EXISTS "Users can update own attendance records" ON public.attendance_records;
DROP POLICY IF EXISTS "Users can delete own attendance records" ON public.attendance_records;

CREATE POLICY "Users can view organization attendance"
ON public.attendance_records FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization attendance"
ON public.attendance_records FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Payroll records
DROP POLICY IF EXISTS "Users can view own payroll records" ON public.payroll_records;
DROP POLICY IF EXISTS "Users can insert own payroll records" ON public.payroll_records;
DROP POLICY IF EXISTS "Users can update own payroll records" ON public.payroll_records;
DROP POLICY IF EXISTS "Users can delete own payroll records" ON public.payroll_records;

CREATE POLICY "Users can view organization payroll"
ON public.payroll_records FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization payroll"
ON public.payroll_records FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Leave requests
DROP POLICY IF EXISTS "Users can view own leave requests" ON public.leave_requests;
DROP POLICY IF EXISTS "Users can insert own leave requests" ON public.leave_requests;
DROP POLICY IF EXISTS "Users can update own leave requests" ON public.leave_requests;
DROP POLICY IF EXISTS "Users can delete own leave requests" ON public.leave_requests;

CREATE POLICY "Users can view organization leave requests"
ON public.leave_requests FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization leave requests"
ON public.leave_requests FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Employee documents
DROP POLICY IF EXISTS "Users can view own employee documents" ON public.employee_documents;
DROP POLICY IF EXISTS "Users can insert own employee documents" ON public.employee_documents;
DROP POLICY IF EXISTS "Users can update own employee documents" ON public.employee_documents;
DROP POLICY IF EXISTS "Users can delete own employee documents" ON public.employee_documents;

CREATE POLICY "Users can view organization documents"
ON public.employee_documents FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization documents"
ON public.employee_documents FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Salary templates
DROP POLICY IF EXISTS "Users can view own salary templates" ON public.salary_templates;
DROP POLICY IF EXISTS "Users can insert own salary templates" ON public.salary_templates;
DROP POLICY IF EXISTS "Users can update own salary templates" ON public.salary_templates;
DROP POLICY IF EXISTS "Users can delete own salary templates" ON public.salary_templates;

CREATE POLICY "Users can view organization salary templates"
ON public.salary_templates FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization salary templates"
ON public.salary_templates FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Allowances
DROP POLICY IF EXISTS "Users can view own allowances" ON public.allowances;
DROP POLICY IF EXISTS "Users can insert own allowances" ON public.allowances;
DROP POLICY IF EXISTS "Users can update own allowances" ON public.allowances;
DROP POLICY IF EXISTS "Users can delete own allowances" ON public.allowances;

CREATE POLICY "Users can view organization allowances"
ON public.allowances FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization allowances"
ON public.allowances FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Deductions
DROP POLICY IF EXISTS "Users can view own deductions" ON public.deductions;
DROP POLICY IF EXISTS "Users can insert own deductions" ON public.deductions;
DROP POLICY IF EXISTS "Users can update own deductions" ON public.deductions;
DROP POLICY IF EXISTS "Users can delete own deductions" ON public.deductions;

CREATE POLICY "Users can view organization deductions"
ON public.deductions FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization deductions"
ON public.deductions FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Overtime records
DROP POLICY IF EXISTS "Users can view own overtime records" ON public.overtime_records;
DROP POLICY IF EXISTS "Users can insert own overtime records" ON public.overtime_records;
DROP POLICY IF EXISTS "Users can update own overtime records" ON public.overtime_records;
DROP POLICY IF EXISTS "Users can delete own overtime records" ON public.overtime_records;

CREATE POLICY "Users can view organization overtime"
ON public.overtime_records FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization overtime"
ON public.overtime_records FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Vehicle assignments
DROP POLICY IF EXISTS "Users can view own vehicle assignments" ON public.vehicle_assignments;
DROP POLICY IF EXISTS "Users can insert own vehicle assignments" ON public.vehicle_assignments;
DROP POLICY IF EXISTS "Users can update own vehicle assignments" ON public.vehicle_assignments;
DROP POLICY IF EXISTS "Users can delete own vehicle assignments" ON public.vehicle_assignments;

CREATE POLICY "Users can view organization vehicle assignments"
ON public.vehicle_assignments FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization vehicle assignments"
ON public.vehicle_assignments FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Vehicle maintenance
DROP POLICY IF EXISTS "Users can view own vehicle maintenance" ON public.vehicle_maintenance;
DROP POLICY IF EXISTS "Users can insert own vehicle maintenance" ON public.vehicle_maintenance;
DROP POLICY IF EXISTS "Users can update own vehicle maintenance" ON public.vehicle_maintenance;
DROP POLICY IF EXISTS "Users can delete own vehicle maintenance" ON public.vehicle_maintenance;

CREATE POLICY "Users can view organization vehicle maintenance"
ON public.vehicle_maintenance FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization vehicle maintenance"
ON public.vehicle_maintenance FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- Fuel logs
DROP POLICY IF EXISTS "Users can view own fuel logs" ON public.fuel_logs;
DROP POLICY IF EXISTS "Users can insert own fuel logs" ON public.fuel_logs;
DROP POLICY IF EXISTS "Users can update own fuel logs" ON public.fuel_logs;
DROP POLICY IF EXISTS "Users can delete own fuel logs" ON public.fuel_logs;

CREATE POLICY "Users can view organization fuel logs"
ON public.fuel_logs FOR SELECT
USING (organization_id = public.get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization fuel logs"
ON public.fuel_logs FOR ALL
USING (organization_id = public.get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = public.get_user_organization_id(auth.uid()));

-- 9. Create indexes for performance
CREATE INDEX idx_organizations_slug ON public.organizations(slug);
CREATE INDEX idx_organization_members_org_id ON public.organization_members(organization_id);
CREATE INDEX idx_organization_members_user_id ON public.organization_members(user_id);
CREATE INDEX idx_profiles_organization_id ON public.profiles(organization_id);
CREATE INDEX idx_employees_organization_id ON public.employees(organization_id);
CREATE INDEX idx_vehicles_organization_id ON public.vehicles(organization_id);
CREATE INDEX idx_attendance_organization_id ON public.attendance_records(organization_id);
CREATE INDEX idx_payroll_organization_id ON public.payroll_records(organization_id);
CREATE INDEX idx_leave_organization_id ON public.leave_requests(organization_id);
CREATE INDEX idx_documents_organization_id ON public.employee_documents(organization_id);
CREATE INDEX idx_salary_templates_organization_id ON public.salary_templates(organization_id);
CREATE INDEX idx_allowances_organization_id ON public.allowances(organization_id);
CREATE INDEX idx_deductions_organization_id ON public.deductions(organization_id);
CREATE INDEX idx_overtime_organization_id ON public.overtime_records(organization_id);
CREATE INDEX idx_vehicle_assignments_organization_id ON public.vehicle_assignments(organization_id);
CREATE INDEX idx_vehicle_maintenance_organization_id ON public.vehicle_maintenance(organization_id);
CREATE INDEX idx_fuel_logs_organization_id ON public.fuel_logs(organization_id);

-- 10. Create trigger for updated_at on organizations
CREATE TRIGGER update_organizations_updated_at
BEFORE UPDATE ON public.organizations
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();