-- المرحلة 4: تطبيق Audit Log Triggers على الجداول

-- =====================================
-- Audit Log Triggers للموظفين
-- =====================================

CREATE TRIGGER employees_audit
AFTER INSERT OR UPDATE OR DELETE ON public.employees
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER payroll_records_audit
AFTER INSERT OR UPDATE OR DELETE ON public.payroll_records
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER attendance_records_audit
AFTER INSERT OR UPDATE OR DELETE ON public.attendance_records
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER leave_requests_audit
AFTER INSERT OR UPDATE OR DELETE ON public.leave_requests
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER allowances_audit
AFTER INSERT OR UPDATE OR DELETE ON public.allowances
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER deductions_audit
AFTER INSERT OR UPDATE OR DELETE ON public.deductions
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER salary_templates_audit
AFTER INSERT OR UPDATE OR DELETE ON public.salary_templates
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER departments_audit
AFTER INSERT OR UPDATE OR DELETE ON public.departments
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER employee_documents_audit
AFTER INSERT OR UPDATE OR DELETE ON public.employee_documents
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER overtime_records_audit
AFTER INSERT OR UPDATE OR DELETE ON public.overtime_records
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

-- =====================================
-- Audit Log Triggers للفليت
-- =====================================

CREATE TRIGGER vehicles_audit
AFTER INSERT OR UPDATE OR DELETE ON public.vehicles
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER vehicle_maintenance_audit
AFTER INSERT OR UPDATE OR DELETE ON public.vehicle_maintenance
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER fuel_logs_audit
AFTER INSERT OR UPDATE OR DELETE ON public.fuel_logs
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER vehicle_assignments_audit
AFTER INSERT OR UPDATE OR DELETE ON public.vehicle_assignments
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER fleet_projects_audit
AFTER INSERT OR UPDATE OR DELETE ON public.fleet_projects
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER vehicle_project_assignments_audit
AFTER INSERT OR UPDATE OR DELETE ON public.vehicle_project_assignments
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER suppliers_audit
AFTER INSERT OR UPDATE OR DELETE ON public.suppliers
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER project_invoices_audit
AFTER INSERT OR UPDATE OR DELETE ON public.project_invoices
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER invoice_line_items_audit
AFTER INSERT OR UPDATE OR DELETE ON public.invoice_line_items
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER vehicle_rental_agreements_audit
AFTER INSERT OR UPDATE OR DELETE ON public.vehicle_rental_agreements
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER vehicle_documents_audit
AFTER INSERT OR UPDATE OR DELETE ON public.vehicle_documents
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER maintenance_workshops_audit
AFTER INSERT OR UPDATE OR DELETE ON public.maintenance_workshops
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER maintenance_items_audit
AFTER INSERT OR UPDATE OR DELETE ON public.maintenance_items
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

-- =====================================
-- Audit Log Triggers للنظام
-- =====================================

CREATE TRIGGER user_roles_audit
AFTER INSERT OR UPDATE OR DELETE ON public.user_roles
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER organization_members_audit
AFTER INSERT OR UPDATE OR DELETE ON public.organization_members
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER organizations_audit
AFTER UPDATE ON public.organizations
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER role_permissions_audit
AFTER INSERT OR UPDATE OR DELETE ON public.role_permissions
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();

CREATE TRIGGER permissions_audit
AFTER INSERT OR UPDATE OR DELETE ON public.permissions
FOR EACH ROW
EXECUTE FUNCTION public.log_audit();