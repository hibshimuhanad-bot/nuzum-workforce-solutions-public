-- المرحلة 1: إنشاء البنية التحتية للصلاحيات والإشعارات

-- 1.1 جدول الصلاحيات (Permissions)
CREATE TABLE IF NOT EXISTS public.permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  category TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 1.2 جدول ربط الأدوار بالصلاحيات (Role Permissions)
CREATE TABLE IF NOT EXISTS public.role_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role app_role NOT NULL,
  permission_id UUID REFERENCES public.permissions(id) ON DELETE CASCADE,
  organization_id UUID REFERENCES public.organizations(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(role, permission_id, organization_id)
);

-- 1.3 تحديث جدول الإشعارات - إضافة حقول جديدة
ALTER TABLE public.notifications 
ADD COLUMN IF NOT EXISTS action_url TEXT,
ADD COLUMN IF NOT EXISTS action_label TEXT,
ADD COLUMN IF NOT EXISTS priority TEXT DEFAULT 'normal',
ADD COLUMN IF NOT EXISTS category TEXT,
ADD COLUMN IF NOT EXISTS metadata JSONB,
ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ;

-- إضافة constraint للأولوية
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'notifications_priority_check'
  ) THEN
    ALTER TABLE public.notifications 
    ADD CONSTRAINT notifications_priority_check 
    CHECK (priority IN ('low', 'normal', 'high', 'urgent'));
  END IF;
END $$;

-- 1.4 جدول إعدادات الإشعارات (Notification Settings)
CREATE TABLE IF NOT EXISTS public.notification_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id UUID REFERENCES public.organizations(id),
  notification_type TEXT NOT NULL,
  is_enabled BOOLEAN DEFAULT true,
  delivery_method TEXT[] DEFAULT ARRAY['in_app'],
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, organization_id, notification_type)
);

-- 1.5 جدول سجل التدقيق (Audit Logs)
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  organization_id UUID REFERENCES public.organizations(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  old_data JSONB,
  new_data JSONB,
  ip_address TEXT,
  user_agent TEXT,
  is_sensitive BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- إنشاء indexes لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON public.audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON public.audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON public.audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_org ON public.audit_logs(organization_id);

-- 1.6 إدراج الصلاحيات الأساسية (45 صلاحية)

-- صلاحيات الموظفين (12 صلاحية)
INSERT INTO public.permissions (name, description, category) VALUES
('view_employees', 'عرض الموظفين', 'employees'),
('create_employees', 'إضافة موظف', 'employees'),
('edit_employees', 'تعديل موظف', 'employees'),
('delete_employees', 'حذف موظف', 'employees'),
('view_payroll', 'عرض الرواتب', 'employees'),
('manage_payroll', 'إدارة الرواتب', 'employees'),
('view_attendance', 'عرض الحضور', 'employees'),
('manage_attendance', 'إدارة الحضور', 'employees'),
('view_leave_requests', 'عرض طلبات الإجازات', 'employees'),
('approve_leave_requests', 'الموافقة على الإجازات', 'employees'),
('manage_departments', 'إدارة الأقسام', 'employees'),
('view_employee_documents', 'عرض مرفقات الموظفين', 'employees')
ON CONFLICT (name) DO NOTHING;

-- صلاحيات الفليت (18 صلاحية)
INSERT INTO public.permissions (name, description, category) VALUES
('view_vehicles', 'عرض السيارات', 'fleet'),
('create_vehicles', 'إضافة سيارة', 'fleet'),
('edit_vehicles', 'تعديل سيارة', 'fleet'),
('delete_vehicles', 'حذف سيارة', 'fleet'),
('view_maintenance', 'عرض الصيانة', 'fleet'),
('create_maintenance', 'إضافة صيانة', 'fleet'),
('approve_maintenance', 'الموافقة على الصيانة', 'fleet'),
('view_fuel_logs', 'عرض سجلات الوقود', 'fleet'),
('manage_fuel_logs', 'إدارة الوقود', 'fleet'),
('view_assignments', 'عرض التعيينات', 'fleet'),
('create_assignments', 'تعيين سيارة', 'fleet'),
('view_projects', 'عرض المشاريع', 'fleet'),
('manage_projects', 'إدارة المشاريع', 'fleet'),
('view_suppliers', 'عرض الموردين', 'fleet'),
('manage_suppliers', 'إدارة الموردين', 'fleet'),
('view_invoices', 'عرض الفواتير', 'fleet'),
('approve_invoices', 'الموافقة على الفواتير', 'fleet'),
('manage_rentals', 'إدارة الإيجارات', 'fleet')
ON CONFLICT (name) DO NOTHING;

-- صلاحيات النظام (8 صلاحيات)
INSERT INTO public.permissions (name, description, category) VALUES
('manage_roles', 'إدارة الأدوار', 'system'),
('manage_permissions', 'إدارة الصلاحيات', 'system'),
('view_audit_logs', 'عرض سجل التدقيق', 'system'),
('manage_notifications', 'إدارة الإشعارات', 'system'),
('view_reports', 'عرض التقارير', 'system'),
('export_data', 'تصدير البيانات', 'system'),
('manage_settings', 'إدارة الإعدادات', 'system'),
('view_analytics', 'عرض التحليلات', 'system')
ON CONFLICT (name) DO NOTHING;

-- صلاحيات إضافية للمستقبل
INSERT INTO public.permissions (name, description, category) VALUES
('manage_allowances', 'إدارة البدلات', 'employees'),
('manage_deductions', 'إدارة الخصومات', 'employees'),
('manage_overtime', 'إدارة الإضافي', 'employees'),
('view_workshops', 'عرض الورش', 'fleet'),
('manage_workshops', 'إدارة الورش', 'fleet'),
('view_rental_agreements', 'عرض عقود الإيجار', 'fleet'),
('manage_vehicle_documents', 'إدارة وثائق السيارات', 'fleet')
ON CONFLICT (name) DO NOTHING;

-- 1.7 دالة التحقق من الصلاحيات (has_permission)
CREATE OR REPLACE FUNCTION public.has_permission(_user_id UUID, _permission_name TEXT)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    JOIN public.role_permissions rp ON rp.role = ur.role
    JOIN public.permissions p ON p.id = rp.permission_id
    WHERE ur.user_id = _user_id
      AND p.name = _permission_name
      AND p.is_active = true
      AND (rp.organization_id IS NULL OR rp.organization_id = public.get_user_organization_id(_user_id))
  )
$$;

-- 1.8 دالة تسجيل التدقيق (log_audit)
CREATE OR REPLACE FUNCTION public.log_audit()
RETURNS TRIGGER
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_sensitive_table BOOLEAN;
BEGIN
  -- تحديد الجداول الحساسة
  is_sensitive_table := TG_TABLE_NAME IN (
    'payroll_records', 'employees', 'user_roles', 
    'allowances', 'deductions', 'salary_templates'
  );
  
  INSERT INTO public.audit_logs (
    user_id, 
    organization_id, 
    action, 
    entity_type, 
    entity_id, 
    old_data, 
    new_data,
    is_sensitive
  ) VALUES (
    auth.uid(),
    public.get_user_organization_id(auth.uid()),
    TG_OP,
    TG_TABLE_NAME,
    COALESCE(NEW.id, OLD.id),
    CASE WHEN TG_OP IN ('DELETE', 'UPDATE') THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN to_jsonb(NEW) ELSE NULL END,
    is_sensitive_table
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- 1.9 دالة إرسال الإشعارات (send_notification)
CREATE OR REPLACE FUNCTION public.send_notification(
  _user_ids UUID[],
  _organization_id UUID,
  _title TEXT,
  _message TEXT,
  _type TEXT DEFAULT 'info',
  _category TEXT DEFAULT NULL,
  _action_url TEXT DEFAULT NULL,
  _action_label TEXT DEFAULT NULL,
  _priority TEXT DEFAULT 'normal',
  _metadata JSONB DEFAULT NULL
)
RETURNS void
LANGUAGE PLPGSQL
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (
    user_id, organization_id, title, message, type, 
    category, action_url, action_label, priority, metadata, is_read
  )
  SELECT 
    unnest(_user_ids),
    _organization_id,
    _title,
    _message,
    _type,
    _category,
    _action_url,
    _action_label,
    _priority,
    _metadata,
    false;
END;
$$;

-- 1.10 دالة للحصول على معرفات المدراء (get_admin_user_ids)
CREATE OR REPLACE FUNCTION public.get_admin_user_ids(_organization_id UUID)
RETURNS UUID[]
LANGUAGE SQL
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT ARRAY_AGG(user_id)
  FROM public.organization_members
  WHERE organization_id = _organization_id
    AND role IN ('owner', 'admin')
$$;

-- 1.11 تفعيل RLS على الجداول الجديدة
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- 1.12 سياسات RLS للصلاحيات
CREATE POLICY "Users can view permissions"
ON public.permissions FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Admins can manage permissions"
ON public.permissions FOR ALL
TO authenticated
USING (public.has_permission(auth.uid(), 'manage_permissions'))
WITH CHECK (public.has_permission(auth.uid(), 'manage_permissions'));

-- 1.13 سياسات RLS لربط الأدوار بالصلاحيات
CREATE POLICY "Users can view organization role permissions"
ON public.role_permissions FOR SELECT
TO authenticated
USING (
  organization_id IS NULL 
  OR organization_id = public.get_user_organization_id(auth.uid())
);

CREATE POLICY "Admins can manage role permissions"
ON public.role_permissions FOR ALL
TO authenticated
USING (
  public.has_permission(auth.uid(), 'manage_permissions')
  OR public.has_role(auth.uid(), 'super_admin'::app_role)
)
WITH CHECK (
  public.has_permission(auth.uid(), 'manage_permissions')
  OR public.has_role(auth.uid(), 'super_admin'::app_role)
);

-- 1.14 سياسات RLS لإعدادات الإشعارات
CREATE POLICY "Users can view own notification settings"
ON public.notification_settings FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Users can manage own notification settings"
ON public.notification_settings FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 1.15 سياسات RLS لسجل التدقيق
CREATE POLICY "Users can view organization audit logs"
ON public.audit_logs FOR SELECT
TO authenticated
USING (
  organization_id = public.get_user_organization_id(auth.uid())
  AND (
    public.has_permission(auth.uid(), 'view_audit_logs')
    OR NOT is_sensitive
  )
);

-- فقط النظام يمكنه الكتابة في audit_logs (عبر الـ triggers)
CREATE POLICY "System can insert audit logs"
ON public.audit_logs FOR INSERT
TO authenticated
WITH CHECK (true);

-- 1.16 trigger لتحديث updated_at في notification_settings
CREATE TRIGGER update_notification_settings_updated_at
BEFORE UPDATE ON public.notification_settings
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();