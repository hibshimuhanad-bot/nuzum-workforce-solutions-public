-- المرحلة 1: إنشاء جدول وثائق المركبات
CREATE TABLE IF NOT EXISTS public.vehicle_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL,
  document_name TEXT NOT NULL,
  document_type TEXT NOT NULL,
  document_number TEXT,
  issue_date TIMESTAMPTZ,
  expiry_date TIMESTAMPTZ,
  file_path TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  notes TEXT,
  organization_id UUID NOT NULL,
  user_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.vehicle_documents ENABLE ROW LEVEL SECURITY;

-- RLS policies for vehicle_documents
CREATE POLICY "Users can view organization vehicle documents" ON public.vehicle_documents
  FOR SELECT USING (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization vehicle documents" ON public.vehicle_documents
  FOR ALL USING (organization_id = get_user_organization_id(auth.uid()))
  WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- Trigger for updated_at
CREATE TRIGGER update_vehicle_documents_updated_at
  BEFORE UPDATE ON public.vehicle_documents
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- المرحلة 2: تحسين جدول vehicle_assignments
ALTER TABLE public.vehicle_assignments 
  ADD COLUMN IF NOT EXISTS delivery_condition TEXT,
  ADD COLUMN IF NOT EXISTS delivery_photos TEXT[],
  ADD COLUMN IF NOT EXISTS return_condition TEXT,
  ADD COLUMN IF NOT EXISTS return_photos TEXT[],
  ADD COLUMN IF NOT EXISTS delivery_odometer INTEGER,
  ADD COLUMN IF NOT EXISTS return_odometer INTEGER,
  ADD COLUMN IF NOT EXISTS employee_signature TEXT,
  ADD COLUMN IF NOT EXISTS damages TEXT,
  ADD COLUMN IF NOT EXISTS checklist JSONB DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active';

-- المرحلة 3: تحسين جدول vehicle_maintenance وإنشاء جداول مساعدة
ALTER TABLE public.vehicle_maintenance
  ADD COLUMN IF NOT EXISTS invoice_number TEXT,
  ADD COLUMN IF NOT EXISTS workshop_id UUID,
  ADD COLUMN IF NOT EXISTS maintenance_category TEXT DEFAULT 'corrective',
  ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS rating INTEGER,
  ADD COLUMN IF NOT EXISTS parts_details JSONB DEFAULT '[]'::jsonb;

-- جدول الورش
CREATE TABLE IF NOT EXISTS public.maintenance_workshops (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  address TEXT,
  phone TEXT,
  email TEXT,
  specialization TEXT,
  rating NUMERIC DEFAULT 0,
  total_services INTEGER DEFAULT 0,
  notes TEXT,
  organization_id UUID NOT NULL,
  user_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.maintenance_workshops ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Users can view organization workshops" ON public.maintenance_workshops
  FOR SELECT USING (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization workshops" ON public.maintenance_workshops
  FOR ALL USING (organization_id = get_user_organization_id(auth.uid()))
  WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- Trigger
CREATE TRIGGER update_maintenance_workshops_updated_at
  BEFORE UPDATE ON public.maintenance_workshops
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- جدول عناصر الصيانة
CREATE TABLE IF NOT EXISTS public.maintenance_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  maintenance_id UUID NOT NULL,
  item_name TEXT NOT NULL,
  quantity NUMERIC NOT NULL DEFAULT 1,
  unit_price NUMERIC NOT NULL,
  total_price NUMERIC NOT NULL,
  notes TEXT,
  organization_id UUID NOT NULL,
  user_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.maintenance_items ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Users can view organization maintenance items" ON public.maintenance_items
  FOR SELECT USING (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization maintenance items" ON public.maintenance_items
  FOR ALL USING (organization_id = get_user_organization_id(auth.uid()))
  WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- Storage bucket for vehicle documents
INSERT INTO storage.buckets (id, name, public) 
VALUES ('vehicle-documents', 'vehicle-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for vehicle documents
CREATE POLICY "Users can view their organization vehicle documents"
ON storage.objects FOR SELECT
USING (bucket_id = 'vehicle-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can upload their organization vehicle documents"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'vehicle-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their organization vehicle documents"
ON storage.objects FOR UPDATE
USING (bucket_id = 'vehicle-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their organization vehicle documents"
ON storage.objects FOR DELETE
USING (bucket_id = 'vehicle-documents' AND auth.uid()::text = (storage.foldername(name))[1]);