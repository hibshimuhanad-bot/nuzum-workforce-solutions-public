-- Insert default role permissions for all roles
-- This will set up the basic permissions structure for the system

-- Get all permission IDs
DO $$
DECLARE
  perm_view_employees UUID;
  perm_create_employees UUID;
  perm_edit_employees UUID;
  perm_delete_employees UUID;
  perm_view_attendance UUID;
  perm_manage_attendance UUID;
  perm_view_leave UUID;
  perm_manage_leave UUID;
  perm_view_payroll UUID;
  perm_manage_payroll UUID;
  perm_view_vehicles UUID;
  perm_create_vehicles UUID;
  perm_edit_vehicles UUID;
  perm_delete_vehicles UUID;
  perm_view_maintenance UUID;
  perm_manage_maintenance UUID;
  perm_view_projects UUID;
  perm_manage_projects UUID;
  perm_view_analytics UUID;
  perm_view_reports UUID;
  perm_manage_roles UUID;
  perm_manage_permissions UUID;
  perm_view_audit_logs UUID;
BEGIN
  -- Get permission IDs
  SELECT id INTO perm_view_employees FROM permissions WHERE name = 'view_employees';
  SELECT id INTO perm_create_employees FROM permissions WHERE name = 'create_employees';
  SELECT id INTO perm_edit_employees FROM permissions WHERE name = 'edit_employees';
  SELECT id INTO perm_delete_employees FROM permissions WHERE name = 'delete_employees';
  SELECT id INTO perm_view_attendance FROM permissions WHERE name = 'view_attendance';
  SELECT id INTO perm_manage_attendance FROM permissions WHERE name = 'manage_attendance';
  SELECT id INTO perm_view_leave FROM permissions WHERE name = 'view_leave_requests';
  SELECT id INTO perm_manage_leave FROM permissions WHERE name = 'manage_leave_requests';
  SELECT id INTO perm_view_payroll FROM permissions WHERE name = 'view_payroll';
  SELECT id INTO perm_manage_payroll FROM permissions WHERE name = 'manage_payroll';
  SELECT id INTO perm_view_vehicles FROM permissions WHERE name = 'view_vehicles';
  SELECT id INTO perm_create_vehicles FROM permissions WHERE name = 'create_vehicles';
  SELECT id INTO perm_edit_vehicles FROM permissions WHERE name = 'edit_vehicles';
  SELECT id INTO perm_delete_vehicles FROM permissions WHERE name = 'delete_vehicles';
  SELECT id INTO perm_view_maintenance FROM permissions WHERE name = 'view_maintenance';
  SELECT id INTO perm_manage_maintenance FROM permissions WHERE name = 'manage_maintenance';
  SELECT id INTO perm_view_projects FROM permissions WHERE name = 'view_projects';
  SELECT id INTO perm_manage_projects FROM permissions WHERE name = 'manage_projects';
  SELECT id INTO perm_view_analytics FROM permissions WHERE name = 'view_analytics';
  SELECT id INTO perm_view_reports FROM permissions WHERE name = 'view_reports';
  SELECT id INTO perm_manage_roles FROM permissions WHERE name = 'manage_roles';
  SELECT id INTO perm_manage_permissions FROM permissions WHERE name = 'manage_permissions';
  SELECT id INTO perm_view_audit_logs FROM permissions WHERE name = 'view_audit_logs';

  -- Super Admin: All permissions (global, no organization_id)
  INSERT INTO role_permissions (role, permission_id, organization_id)
  SELECT 'super_admin'::app_role, id, NULL
  FROM permissions
  ON CONFLICT DO NOTHING;

  -- Org Admin: Almost all permissions (organization-specific)
  -- We'll leave organization_id NULL for now, it will be set per organization
  INSERT INTO role_permissions (role, permission_id, organization_id)
  SELECT 'org_admin'::app_role, id, NULL
  FROM permissions
  WHERE name NOT IN ('manage_permissions') -- Only super_admin can manage permissions globally
  ON CONFLICT DO NOTHING;

  -- HR: Employee and payroll management
  INSERT INTO role_permissions (role, permission_id, organization_id)
  VALUES
    ('hr'::app_role, perm_view_employees, NULL),
    ('hr'::app_role, perm_create_employees, NULL),
    ('hr'::app_role, perm_edit_employees, NULL),
    ('hr'::app_role, perm_delete_employees, NULL),
    ('hr'::app_role, perm_view_attendance, NULL),
    ('hr'::app_role, perm_manage_attendance, NULL),
    ('hr'::app_role, perm_view_leave, NULL),
    ('hr'::app_role, perm_manage_leave, NULL),
    ('hr'::app_role, perm_view_payroll, NULL),
    ('hr'::app_role, perm_manage_payroll, NULL),
    ('hr'::app_role, perm_view_reports, NULL)
  ON CONFLICT DO NOTHING;

  -- Manager: View and limited management
  INSERT INTO role_permissions (role, permission_id, organization_id)
  VALUES
    ('manager'::app_role, perm_view_employees, NULL),
    ('manager'::app_role, perm_view_attendance, NULL),
    ('manager'::app_role, perm_view_leave, NULL),
    ('manager'::app_role, perm_manage_leave, NULL),
    ('manager'::app_role, perm_view_vehicles, NULL),
    ('manager'::app_role, perm_view_projects, NULL),
    ('manager'::app_role, perm_view_analytics, NULL),
    ('manager'::app_role, perm_view_reports, NULL)
  ON CONFLICT DO NOTHING;

  -- Employee: View only
  INSERT INTO role_permissions (role, permission_id, organization_id)
  VALUES
    ('employee'::app_role, perm_view_employees, NULL),
    ('employee'::app_role, perm_view_attendance, NULL),
    ('employee'::app_role, perm_view_leave, NULL)
  ON CONFLICT DO NOTHING;
END $$;