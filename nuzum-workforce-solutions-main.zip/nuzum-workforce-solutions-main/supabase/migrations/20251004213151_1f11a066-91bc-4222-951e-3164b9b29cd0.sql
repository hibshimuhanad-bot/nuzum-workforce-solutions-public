-- إضافة دور fleet_manager إلى enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'fleet_manager';