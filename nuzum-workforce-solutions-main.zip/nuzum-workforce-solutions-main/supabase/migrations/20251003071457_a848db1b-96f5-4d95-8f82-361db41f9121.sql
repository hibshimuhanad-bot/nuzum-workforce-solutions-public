-- Create fleet projects table
CREATE TABLE public.fleet_projects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  start_date TIMESTAMP WITH TIME ZONE NOT NULL,
  end_date TIMESTAMP WITH TIME ZONE,
  budget NUMERIC,
  actual_cost NUMERIC DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'on_hold', 'cancelled')),
  organization_id UUID NOT NULL,
  user_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create vehicle project assignments table
CREATE TABLE public.vehicle_project_assignments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  vehicle_id UUID NOT NULL,
  project_id UUID NOT NULL,
  assigned_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  end_date TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  organization_id UUID NOT NULL,
  user_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.fleet_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_project_assignments ENABLE ROW LEVEL SECURITY;

-- Create policies for fleet_projects
CREATE POLICY "Users can view organization fleet projects"
ON public.fleet_projects
FOR SELECT
USING (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization fleet projects"
ON public.fleet_projects
FOR ALL
USING (organization_id = get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- Create policies for vehicle_project_assignments
CREATE POLICY "Users can view organization vehicle project assignments"
ON public.vehicle_project_assignments
FOR SELECT
USING (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Users can manage organization vehicle project assignments"
ON public.vehicle_project_assignments
FOR ALL
USING (organization_id = get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- Create trigger for automatic timestamp updates on fleet_projects
CREATE TRIGGER update_fleet_projects_updated_at
BEFORE UPDATE ON public.fleet_projects
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

-- Create trigger for automatic timestamp updates on vehicle_project_assignments
CREATE TRIGGER update_vehicle_project_assignments_updated_at
BEFORE UPDATE ON public.vehicle_project_assignments
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();