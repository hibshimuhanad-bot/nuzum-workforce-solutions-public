-- Fix circular dependency in user_roles RLS policy
-- Drop existing problematic policy
DROP POLICY IF EXISTS "Users can view own organization roles" ON public.user_roles;

-- Create new policy that prioritizes direct user_id check to avoid circular dependency
CREATE POLICY "Users can view own roles and org roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (
  -- Users can always see their own roles (no circular dependency)
  user_id = auth.uid()
  OR
  -- Super admins can see all roles (uses security definer function)
  public.has_role(auth.uid(), 'super_admin'::app_role)
  OR
  -- Users in same organization can see each other's roles
  user_id IN (
    SELECT p.id
    FROM public.profiles p
    WHERE p.organization_id = (
      SELECT organization_id 
      FROM public.profiles 
      WHERE id = auth.uid()
    )
  )
);