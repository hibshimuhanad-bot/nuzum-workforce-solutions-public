-- ==========================================
-- المرحلة 1: تعديلات الجداول الأساسية
-- ==========================================

-- 1. تحديث جدول employees
ALTER TABLE public.employees
ADD COLUMN IF NOT EXISTS nationality TEXT,
ADD COLUMN IF NOT EXISTS nationality_type TEXT CHECK (nationality_type IN ('saudi', 'non_saudi')) DEFAULT 'saudi',
ADD COLUMN IF NOT EXISTS iqama_number TEXT,
ADD COLUMN IF NOT EXISTS iqama_expiry_date DATE;

-- 2. تحديث جدول payroll_records
ALTER TABLE public.payroll_records
ADD COLUMN IF NOT EXISTS gosi_employee NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS gosi_company NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS occupational_hazard NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS end_of_service_provision NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS leave_balance_days INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS unpaid_leave_deduction NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS housing_allowance NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS transportation_allowance NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS food_allowance NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS other_taxable_allowances NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_taxable_income NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_company_cost NUMERIC DEFAULT 0;

-- 3. إنشاء جدول employee_leave_balances
CREATE TABLE IF NOT EXISTS public.employee_leave_balances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  year INTEGER NOT NULL,
  annual_leave_entitlement INTEGER DEFAULT 21,
  annual_leave_used INTEGER DEFAULT 0,
  annual_leave_balance INTEGER DEFAULT 21,
  sick_leave_used INTEGER DEFAULT 0,
  unpaid_leave_days INTEGER DEFAULT 0,
  leave_accrual_date DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(employee_id, year)
);

ALTER TABLE public.employee_leave_balances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage organization leave balances"
ON public.employee_leave_balances
FOR ALL
USING (organization_id = get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

CREATE POLICY "Users can view organization leave balances"
ON public.employee_leave_balances
FOR SELECT
USING (organization_id = get_user_organization_id(auth.uid()));

-- 4. إنشاء جدول employment_terminations
CREATE TABLE IF NOT EXISTS public.employment_terminations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  organization_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  termination_date DATE NOT NULL,
  termination_type TEXT CHECK (termination_type IN ('resignation', 'termination', 'contract_end', 'retirement')) NOT NULL,
  notice_period_days INTEGER DEFAULT 0,
  last_working_day DATE,
  reason TEXT,
  end_of_service_amount NUMERIC DEFAULT 0,
  unpaid_leave_deduction NUMERIC DEFAULT 0,
  outstanding_loans NUMERIC DEFAULT 0,
  final_settlement NUMERIC DEFAULT 0,
  processed_by UUID,
  processed_at TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.employment_terminations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage organization terminations"
ON public.employment_terminations
FOR ALL
USING (organization_id = get_user_organization_id(auth.uid()))
WITH CHECK (organization_id = get_user_organization_id(auth.uid()));

-- 5. تحديث جدول allowances
ALTER TABLE public.allowances
ADD COLUMN IF NOT EXISTS allowance_type TEXT CHECK (allowance_type IN ('housing', 'transportation', 'food', 'education', 'mobile', 'other')),
ADD COLUMN IF NOT EXISTS is_taxable BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS applies_to_nationality TEXT CHECK (applies_to_nationality IN ('all', 'saudi', 'non_saudi')) DEFAULT 'all';

-- 6. تحديث جدول deductions
ALTER TABLE public.deductions
ADD COLUMN IF NOT EXISTS deduction_type TEXT CHECK (deduction_type IN ('loan', 'advance', 'absence', 'penalty', 'other')),
ADD COLUMN IF NOT EXISTS is_recurring BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS applies_to_nationality TEXT CHECK (applies_to_nationality IN ('all', 'saudi', 'non_saudi')) DEFAULT 'all';

-- ==========================================
-- المرحلة 2: الدوال PostgreSQL
-- ==========================================

-- دالة حساب GOSI حسب الجنسية
CREATE OR REPLACE FUNCTION public.calculate_gosi_for_employee(
  _employee_id UUID,
  _month INTEGER,
  _year INTEGER
)
RETURNS JSON AS $$
DECLARE
  employee_record RECORD;
  capped_salary NUMERIC;
  employee_gosi NUMERIC := 0;
  company_gosi NUMERIC := 0;
  occupational NUMERIC := 0;
  total_taxable NUMERIC := 0;
BEGIN
  -- جلب بيانات الموظف
  SELECT 
    e.nationality_type,
    e.salary as base_salary,
    COALESCE(SUM(a.amount) FILTER (WHERE a.is_taxable = true), 0) as taxable_allowances
  INTO employee_record
  FROM public.employees e
  LEFT JOIN public.allowances a ON a.employee_id = e.id 
    AND a.is_recurring = true
    AND (a.applies_to_nationality = 'all' OR a.applies_to_nationality = e.nationality_type)
  WHERE e.id = _employee_id
  GROUP BY e.id, e.nationality_type, e.salary;
  
  IF employee_record IS NULL THEN
    RETURN json_build_object('error', 'Employee not found');
  END IF;
  
  -- حساب الراتب الخاضع للتأمينات (محدود بـ 45,000)
  total_taxable := employee_record.base_salary + employee_record.taxable_allowances;
  capped_salary := LEAST(total_taxable, 45000);
  
  IF employee_record.nationality_type = 'saudi' THEN
    -- سعودي: 10% موظف + 12% شركة
    employee_gosi := ROUND(capped_salary * 0.10, 2);
    company_gosi := ROUND(capped_salary * 0.12, 2);
    occupational := 0;
  ELSE
    -- غير سعودي: 0% موظف + 2% شركة (إصابات عمل فقط)
    employee_gosi := 0;
    company_gosi := 0;
    occupational := ROUND(capped_salary * 0.02, 2);
  END IF;
  
  RETURN json_build_object(
    'employee_gosi', employee_gosi,
    'company_gosi', company_gosi,
    'occupational_hazard', occupational,
    'total_company_cost', company_gosi + occupational,
    'taxable_salary', total_taxable,
    'capped_salary', capped_salary
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- دالة حساب نهاية الخدمة
CREATE OR REPLACE FUNCTION public.calculate_end_of_service(
  _employee_id UUID,
  _termination_date DATE DEFAULT CURRENT_DATE,
  _termination_type TEXT DEFAULT 'termination'
)
RETURNS NUMERIC AS $$
DECLARE
  employee_record RECORD;
  years_of_service NUMERIC;
  months_of_service INTEGER;
  total_months NUMERIC;
  entitlement NUMERIC := 0;
  first_five_years NUMERIC;
  remaining_years NUMERIC;
BEGIN
  -- جلب بيانات الموظف
  SELECT 
    e.nationality_type,
    e.salary as base_salary,
    e.join_date::DATE
  INTO employee_record
  FROM public.employees e
  WHERE e.id = _employee_id;
  
  IF employee_record IS NULL THEN
    RETURN 0;
  END IF;
  
  -- حساب سنوات الخدمة بالضبط
  total_months := EXTRACT(YEAR FROM AGE(_termination_date, employee_record.join_date)) * 12 
                + EXTRACT(MONTH FROM AGE(_termination_date, employee_record.join_date));
  years_of_service := total_months / 12.0;
  
  -- للسعودي: المكافأة كاملة في جميع الحالات
  IF employee_record.nationality_type = 'saudi' THEN
    IF years_of_service <= 5 THEN
      entitlement := employee_record.base_salary * 0.5 * years_of_service;
    ELSE
      first_five_years := employee_record.base_salary * 0.5 * 5;
      remaining_years := employee_record.base_salary * 1.0 * (years_of_service - 5);
      entitlement := first_five_years + remaining_years;
    END IF;
  
  -- لغير السعودي: يعتمد على سبب الاستقالة
  ELSE
    IF _termination_type IN ('termination', 'contract_end', 'retirement') THEN
      -- فصل من الشركة أو انتهاء عقد: مكافأة كاملة
      IF years_of_service <= 5 THEN
        entitlement := employee_record.base_salary * 0.5 * years_of_service;
      ELSE
        first_five_years := employee_record.base_salary * 0.5 * 5;
        remaining_years := employee_record.base_salary * 1.0 * (years_of_service - 5);
        entitlement := first_five_years + remaining_years;
      END IF;
    ELSE
      -- استقالة: حسب سنوات الخدمة
      IF years_of_service < 2 THEN
        entitlement := 0; -- لا شيء
      ELSIF years_of_service < 5 THEN
        -- الثلث
        entitlement := (employee_record.base_salary * 0.5 * years_of_service) * (1.0 / 3.0);
      ELSIF years_of_service < 10 THEN
        -- الثلثين
        first_five_years := employee_record.base_salary * 0.5 * 5;
        remaining_years := employee_record.base_salary * 1.0 * (years_of_service - 5);
        entitlement := (first_five_years + remaining_years) * (2.0 / 3.0);
      ELSE
        -- 10+ سنوات: المكافأة كاملة
        first_five_years := employee_record.base_salary * 0.5 * 5;
        remaining_years := employee_record.base_salary * 1.0 * (years_of_service - 5);
        entitlement := first_five_years + remaining_years;
      END IF;
    END IF;
  END IF;
  
  RETURN ROUND(entitlement, 2);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- دالة حساب رصيد الإجازات
CREATE OR REPLACE FUNCTION public.calculate_leave_balance(
  _employee_id UUID,
  _year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER
)
RETURNS JSON AS $$
DECLARE
  employee_record RECORD;
  years_of_service NUMERIC;
  annual_entitlement INTEGER;
  leave_record RECORD;
BEGIN
  -- جلب بيانات الموظف
  SELECT 
    e.nationality_type,
    e.join_date::DATE
  INTO employee_record
  FROM public.employees e
  WHERE e.id = _employee_id;
  
  IF employee_record IS NULL THEN
    RETURN json_build_object('error', 'Employee not found');
  END IF;
  
  -- حساب سنوات الخدمة
  years_of_service := EXTRACT(YEAR FROM AGE(CURRENT_DATE, employee_record.join_date));
  
  -- تحديد الاستحقاق السنوي
  IF employee_record.nationality_type = 'saudi' THEN
    IF years_of_service >= 5 THEN
      annual_entitlement := 30;
    ELSE
      annual_entitlement := 21;
    END IF;
  ELSE
    annual_entitlement := 21;
  END IF;
  
  -- جلب رصيد الإجازات الحالي
  SELECT * INTO leave_record
  FROM public.employee_leave_balances
  WHERE employee_id = _employee_id AND year = _year;
  
  IF leave_record IS NULL THEN
    -- إنشاء رصيد جديد
    INSERT INTO public.employee_leave_balances (
      employee_id,
      organization_id,
      user_id,
      year,
      annual_leave_entitlement,
      annual_leave_balance
    )
    SELECT 
      _employee_id,
      e.organization_id,
      e.user_id,
      _year,
      annual_entitlement,
      annual_entitlement
    FROM public.employees e
    WHERE e.id = _employee_id
    RETURNING * INTO leave_record;
  END IF;
  
  RETURN json_build_object(
    'annual_entitlement', annual_entitlement,
    'annual_used', COALESCE(leave_record.annual_leave_used, 0),
    'annual_balance', COALESCE(leave_record.annual_leave_balance, annual_entitlement),
    'sick_leave_used', COALESCE(leave_record.sick_leave_used, 0),
    'unpaid_leave_days', COALESCE(leave_record.unpaid_leave_days, 0)
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- دالة الحساب التلقائي الشامل للراتب
CREATE OR REPLACE FUNCTION public.auto_calculate_payroll(
  _employee_id UUID,
  _month INTEGER,
  _year INTEGER
)
RETURNS JSON AS $$
DECLARE
  employee_record RECORD;
  gosi_calc JSON;
  leave_calc JSON;
  total_allowances NUMERIC := 0;
  total_deductions NUMERIC := 0;
  overtime_amount NUMERIC := 0;
  unpaid_leave_deduction NUMERIC := 0;
  net_salary NUMERIC;
  working_days INTEGER := 30;
  daily_wage NUMERIC;
BEGIN
  -- جلب بيانات الموظف
  SELECT 
    e.id,
    e.organization_id,
    e.user_id,
    e.salary as base_salary,
    e.nationality_type
  INTO employee_record
  FROM public.employees e
  WHERE e.id = _employee_id;
  
  IF employee_record IS NULL THEN
    RETURN json_build_object('error', 'Employee not found');
  END IF;
  
  -- حساب GOSI
  gosi_calc := public.calculate_gosi_for_employee(_employee_id, _month, _year);
  
  -- حساب رصيد الإجازات
  leave_calc := public.calculate_leave_balance(_employee_id, _year);
  
  -- حساب البدلات
  SELECT COALESCE(SUM(
    CASE 
      WHEN a.applies_to_nationality = 'all' OR a.applies_to_nationality = employee_record.nationality_type
      THEN a.amount 
      ELSE 0 
    END
  ), 0)
  INTO total_allowances
  FROM public.allowances a
  WHERE a.employee_id = _employee_id 
    AND a.is_recurring = true
    AND (a.effective_date IS NULL OR a.effective_date <= CURRENT_DATE)
    AND (a.end_date IS NULL OR a.end_date >= CURRENT_DATE);
  
  -- حساب الخصومات
  SELECT COALESCE(SUM(
    CASE 
      WHEN d.applies_to_nationality = 'all' OR d.applies_to_nationality = employee_record.nationality_type
      THEN d.amount 
      ELSE 0 
    END
  ), 0)
  INTO total_deductions
  FROM public.deductions d
  WHERE d.employee_id = _employee_id 
    AND d.is_recurring = true
    AND (d.effective_date IS NULL OR d.effective_date <= CURRENT_DATE)
    AND (d.end_date IS NULL OR d.end_date >= CURRENT_DATE);
  
  -- حساب الساعات الإضافية
  SELECT COALESCE(SUM(o.amount), 0)
  INTO overtime_amount
  FROM public.overtime_records o
  WHERE o.employee_id = _employee_id
    AND EXTRACT(MONTH FROM o.date) = _month
    AND EXTRACT(YEAR FROM o.date) = _year
    AND o.approved = true;
  
  -- حساب خصم الغياب بدون إجازة
  daily_wage := employee_record.base_salary / working_days;
  unpaid_leave_deduction := daily_wage * COALESCE((leave_calc->>'unpaid_leave_days')::INTEGER, 0);
  
  -- حساب الصافي
  net_salary := employee_record.base_salary 
                + total_allowances 
                + overtime_amount 
                - total_deductions 
                - (gosi_calc->>'employee_gosi')::NUMERIC
                - unpaid_leave_deduction;
  
  RETURN json_build_object(
    'base_salary', employee_record.base_salary,
    'total_allowances', total_allowances,
    'total_deductions', total_deductions,
    'overtime_amount', overtime_amount,
    'gosi_employee', (gosi_calc->>'employee_gosi')::NUMERIC,
    'gosi_company', (gosi_calc->>'company_gosi')::NUMERIC,
    'occupational_hazard', (gosi_calc->>'occupational_hazard')::NUMERIC,
    'unpaid_leave_deduction', unpaid_leave_deduction,
    'net_salary', net_salary,
    'total_company_cost', employee_record.base_salary + total_allowances + (gosi_calc->>'total_company_cost')::NUMERIC,
    'leave_balance', leave_calc
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- ==========================================
-- المرحلة 3: تقرير GOSI الشهري
-- ==========================================

CREATE OR REPLACE VIEW public.monthly_gosi_report AS
SELECT 
  e.id as employee_id,
  e.name as employee_name,
  e.national_id,
  e.nationality,
  e.nationality_type,
  e.organization_id,
  pr.month,
  pr.year,
  pr.base_salary,
  pr.total_taxable_income,
  pr.gosi_employee,
  pr.gosi_company,
  pr.occupational_hazard,
  pr.total_company_cost,
  o.name as organization_name
FROM public.payroll_records pr
JOIN public.employees e ON e.id = pr.employee_id
JOIN public.organizations o ON o.id = pr.organization_id
ORDER BY pr.year DESC, pr.month DESC, e.name;

-- إضافة triggers للتحديث التلقائي
CREATE OR REPLACE FUNCTION public.update_leave_balance_on_attendance()
RETURNS TRIGGER AS $$
BEGIN
  -- تحديث رصيد الإجازات عند تسجيل الحضور
  IF NEW.overtime_hours > 0 THEN
    -- يمكن إضافة منطق إضافي هنا
    NULL;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger للحضور
DROP TRIGGER IF EXISTS update_leave_on_attendance ON public.attendance_records;
CREATE TRIGGER update_leave_on_attendance
  AFTER INSERT OR UPDATE ON public.attendance_records
  FOR EACH ROW
  EXECUTE FUNCTION public.update_leave_balance_on_attendance();