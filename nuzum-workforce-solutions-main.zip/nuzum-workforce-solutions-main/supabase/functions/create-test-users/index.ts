import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.58.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface UserConfig {
  email: string;
  password: string;
  role: 'super_admin' | 'hr' | 'fleet_manager';
  organizationName: string;
  enabledModules: Record<string, boolean>;
  permissions: string[];
}

// SECURITY: This function should only be used in development
// Generate random passwords for each test user
const generatePassword = () => {
  return crypto.randomUUID() + '-' + Date.now();
};

const testUsers: UserConfig[] = [
  {
    email: 'Admin@test.com',
    password: generatePassword(),
    role: 'super_admin',
    organizationName: 'Super Admin Organization',
    enabledModules: {
      employees: true,
      payroll: true,
      attendance: true,
      leave: true,
      fleet: true,
      reports: true,
      analytics: true,
    },
    permissions: [], // Super admin gets all permissions via role
  },
  {
    email: 'Hr@test.com',
    password: generatePassword(),
    role: 'hr',
    organizationName: 'HR Department',
    enabledModules: {
      employees: true,
      payroll: true,
      attendance: true,
      leave: true,
      fleet: false,
      reports: false,
      analytics: false,
    },
    permissions: [
      'add_employee',
      'edit_employee',
      'delete_employee',
      'view_employee_attendance',
      'view_employee_payroll',
      'manage_employee_leaves',
      'approve_leave_requests',
      'manage_allowances',
      'manage_deductions',
      'manage_departments',
      'view_employee_documents',
    ],
  },
  {
    email: 'Fleet@test.com',
    password: generatePassword(),
    role: 'fleet_manager',
    organizationName: 'Fleet Management',
    enabledModules: {
      employees: false,
      payroll: false,
      attendance: false,
      leave: false,
      fleet: true,
      reports: false,
      analytics: false,
    },
    permissions: [
      'add_vehicle',
      'edit_vehicle',
      'delete_vehicle',
      'assign_vehicle',
      'manage_fleet_projects',
      'add_maintenance',
      'edit_maintenance',
      'delete_maintenance',
      'approve_maintenance',
      'add_fuel_log',
      'edit_fuel_log',
      'delete_fuel_log',
      'manage_workshops',
      'manage_suppliers',
      'manage_invoices',
      'approve_invoices',
      'manage_rental_agreements',
      'manage_vehicle_documents',
    ],
  },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // SECURITY: Prevent execution in production
    const environment = Deno.env.get('ENVIRONMENT') || 'development';
    if (environment === 'production') {
      return new Response(JSON.stringify({ 
        error: 'Test user creation is disabled in production' 
      }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    console.log('Starting test users creation...');
    console.log('⚠️ WARNING: Using randomly generated passwords for security');
    const results = [];

    for (const userConfig of testUsers) {
      console.log(`Creating user: ${userConfig.email}`);

      // Check if user already exists
      const { data: existingUser } = await supabaseAdmin.auth.admin.listUsers();
      const userExists = existingUser?.users.some(u => u.email === userConfig.email);

      if (userExists) {
        console.log(`User ${userConfig.email} already exists, skipping...`);
        results.push({
          email: userConfig.email,
          status: 'skipped',
          message: 'User already exists',
        });
        continue;
      }

      // Create user with admin API
      const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email: userConfig.email,
        password: userConfig.password,
        email_confirm: true,
        user_metadata: {
          company_name: userConfig.organizationName,
        },
      });

      if (authError || !authUser.user) {
        console.error(`Error creating user ${userConfig.email}:`, authError);
        results.push({
          email: userConfig.email,
          status: 'error',
          message: authError?.message || 'Failed to create user',
        });
        continue;
      }

      console.log(`User created: ${authUser.user.id}`);

      // The trigger handle_new_user() will create:
      // - organization
      // - profile
      // - organization_member
      // - user_role (with org_admin by default)

      // Wait a bit for trigger to complete
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Get the created organization
      const { data: profile } = await supabaseAdmin
        .from('profiles')
        .select('organization_id')
        .eq('id', authUser.user.id)
        .single();

      if (!profile?.organization_id) {
        console.error(`No organization found for user ${userConfig.email}`);
        results.push({
          email: userConfig.email,
          status: 'error',
          message: 'Organization not created',
        });
        continue;
      }

      // Update organization with enabled modules
      const { error: orgError } = await supabaseAdmin
        .from('organizations')
        .update({
          enabled_modules: userConfig.enabledModules,
          name: userConfig.organizationName,
        })
        .eq('id', profile.organization_id);

      if (orgError) {
        console.error(`Error updating organization:`, orgError);
      }

      // Handle role assignment
      if (userConfig.role === 'super_admin') {
        // For Admin@test.com, INSERT super_admin role (org_admin already exists from trigger)
        const { error: superAdminRoleError } = await supabaseAdmin
          .from('user_roles')
          .insert({ user_id: authUser.user.id, role: 'super_admin' })
          .select();

        if (superAdminRoleError) {
          console.error(`Error adding super_admin role:`, superAdminRoleError);
        } else {
          console.log(`Added super_admin role for ${userConfig.email}`);
        }
      } else {
        // For other users, UPDATE the existing org_admin role created by trigger
        const { error: roleError } = await supabaseAdmin
          .from('user_roles')
          .update({ role: userConfig.role })
          .eq('user_id', authUser.user.id);

        if (roleError) {
          console.error(`Error updating role:`, roleError);
        }
      }

      // For HR and Fleet, add specific permissions
      if (userConfig.permissions.length > 0) {
        // Get permission IDs
        const { data: permissions } = await supabaseAdmin
          .from('permissions')
          .select('id, name')
          .in('name', userConfig.permissions);

        if (permissions && permissions.length > 0) {
          // Add role permissions
          const rolePermissions = permissions.map(p => ({
            role: userConfig.role,
            permission_id: p.id,
            organization_id: profile.organization_id,
          }));

          const { error: permError } = await supabaseAdmin
            .from('role_permissions')
            .upsert(rolePermissions, {
              onConflict: 'role,permission_id,organization_id',
              ignoreDuplicates: true,
            });

          if (permError) {
            console.error(`Error adding permissions:`, permError);
          } else {
            console.log(`Added ${permissions.length} permissions for ${userConfig.email}`);
          }
        }
      }

      results.push({
        email: userConfig.email,
        status: 'success',
        role: userConfig.role,
        organization: userConfig.organizationName,
        permissions: userConfig.permissions.length,
      });

      console.log(`Successfully created user: ${userConfig.email}`);
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Test users creation completed',
        results,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error in create-test-users function:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
