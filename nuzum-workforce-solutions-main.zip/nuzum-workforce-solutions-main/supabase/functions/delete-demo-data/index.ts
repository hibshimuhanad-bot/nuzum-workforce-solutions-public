import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get authenticated user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = await req.json();
    const { organization_id } = body;

    // Validate organization_id
    if (!organization_id || typeof organization_id !== 'string') {
      return new Response(JSON.stringify({ error: 'Invalid organization_id' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Verify user is admin/owner of this organization
    const { data: membership, error: membershipError } = await supabaseClient
      .from('organization_members')
      .select('role')
      .eq('organization_id', organization_id)
      .eq('user_id', user.id)
      .single();

    if (membershipError || !membership || !['owner', 'admin'].includes(membership.role)) {
      return new Response(JSON.stringify({ error: 'Forbidden - Admin access required' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('🗑️ Deleting demo data for organization:', organization_id);

    // Delete all demo employees (emails starting with demo)
    const { data: demoEmployees } = await supabaseClient
      .from('employees')
      .select('id')
      .eq('organization_id', organization_id)
      .like('email', 'demo%@example.com');

    if (demoEmployees && demoEmployees.length > 0) {
      const employeeIds = demoEmployees.map(e => e.id);

      // Delete related records first
      await supabaseClient
        .from('attendance_records')
        .delete()
        .in('employee_id', employeeIds);

      await supabaseClient
        .from('leave_requests')
        .delete()
        .in('employee_id', employeeIds);

      await supabaseClient
        .from('payroll_records')
        .delete()
        .in('employee_id', employeeIds);

      // Delete employees
      await supabaseClient
        .from('employees')
        .delete()
        .in('id', employeeIds);

      console.log('✅ Deleted', demoEmployees.length, 'demo employees');
    }

    // Delete demo vehicles (plate numbers starting with ABC)
    const { data: demoVehicles } = await supabaseClient
      .from('vehicles')
      .select('id')
      .eq('organization_id', organization_id)
      .like('plate_number', 'ABC%');

    if (demoVehicles && demoVehicles.length > 0) {
      const vehicleIds = demoVehicles.map(v => v.id);

      // Delete related records
      await supabaseClient
        .from('fuel_logs')
        .delete()
        .in('vehicle_id', vehicleIds);

      await supabaseClient
        .from('vehicle_assignments')
        .delete()
        .in('vehicle_id', vehicleIds);

      // Delete vehicles
      await supabaseClient
        .from('vehicles')
        .delete()
        .in('id', vehicleIds);

      console.log('✅ Deleted', demoVehicles.length, 'demo vehicles');
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: 'تم حذف بيانات الديمو بنجاح',
        deleted: {
          employees: demoEmployees?.length || 0,
          vehicles: demoVehicles?.length || 0,
        },
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('❌ Error deleting demo data:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    const errorDetails = error instanceof Error ? error.toString() : String(error);
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        details: errorDetails
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});
