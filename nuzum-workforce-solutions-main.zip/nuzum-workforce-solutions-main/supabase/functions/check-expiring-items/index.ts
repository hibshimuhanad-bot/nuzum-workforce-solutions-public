import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    // Check expiring vehicle documents
    const { data: expiringVehicleDocs } = await supabase
      .from('vehicle_documents')
      .select('*, vehicles(make, model, plate_number, organization_id)')
      .lte('expiry_date', thirtyDaysFromNow.toISOString())
      .gte('expiry_date', now.toISOString())
      .eq('status', 'active');

    // Check expiring employee documents
    const { data: expiringEmployeeDocs } = await supabase
      .from('employee_documents')
      .select('*, employees(name, organization_id)')
      .lte('expiry_date', thirtyDaysFromNow.toISOString())
      .gte('expiry_date', now.toISOString());

    // Send notifications for expiring documents
    for (const doc of expiringVehicleDocs || []) {
      const vehicle = doc.vehicles as any;
      const { data: adminIds } = await supabase.rpc('get_admin_user_ids', {
        _organization_id: vehicle.organization_id
      });

      if (adminIds?.length) {
        await supabase.rpc('send_notification', {
          _user_ids: adminIds,
          _organization_id: vehicle.organization_id,
          _title: 'وثيقة سيارة قريبة الانتهاء',
          _message: `وثيقة ${doc.document_name} للسيارة ${vehicle.make} ${vehicle.model} (${vehicle.plate_number}) ستنتهي قريباً`,
          _type: 'warning',
          _category: 'fleet',
          _priority: 'urgent'
        });
      }
    }

    return new Response(JSON.stringify({ 
      success: true,
      checked: {
        vehicleDocs: expiringVehicleDocs?.length || 0,
        employeeDocs: expiringEmployeeDocs?.length || 0
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
