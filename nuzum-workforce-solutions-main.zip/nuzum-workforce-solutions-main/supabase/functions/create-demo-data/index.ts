import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get authenticated user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = await req.json();
    const { organization_id } = body;

    // Validate organization_id
    if (!organization_id || typeof organization_id !== 'string') {
      return new Response(JSON.stringify({ error: 'Invalid organization_id' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Verify user is admin/owner of this organization
    const { data: membership, error: membershipError } = await supabaseClient
      .from('organization_members')
      .select('role')
      .eq('organization_id', organization_id)
      .eq('user_id', user.id)
      .single();

    if (membershipError || !membership || !['owner', 'admin'].includes(membership.role)) {
      return new Response(JSON.stringify({ error: 'Forbidden - Admin access required' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('🎯 Creating demo data for organization:', organization_id);

    // Get organization details
    const { data: org } = await supabaseClient
      .from('organizations')
      .select('*')
      .eq('id', organization_id)
      .single();

    if (!org) {
      throw new Error('Organization not found');
    }

    // Get first user in organization
    const { data: members } = await supabaseClient
      .from('organization_members')
      .select('user_id')
      .eq('organization_id', organization_id)
      .limit(1);

    const userId = members?.[0]?.user_id;
    if (!userId) {
      throw new Error('No user found in organization');
    }

    // Create demo employees
    const employees = [];
    const employeeNames = [
      'أحمد محمد',
      'فاطمة علي',
      'خالد سعيد',
      'نورة عبدالله',
      'عمر حسن',
    ];

    for (let i = 0; i < Math.min(5, org.max_employees); i++) {
      const { data: emp, error: empError } = await supabaseClient
        .from('employees')
        .insert({
          organization_id,
          user_id: userId,
          name: employeeNames[i],
          email: `demo${i + 1}@example.com`,
          phone: `+966${50000000 + i}`,
          position: i === 0 ? 'مدير' : 'موظف',
          salary: 5000 + (i * 1000),
          join_date: new Date(2024, 0, 1 + i).toISOString(),
          nationality_type: i % 2 === 0 ? 'saudi' : 'non_saudi',
          status: 'active',
        })
        .select()
        .single();

      if (empError) {
        console.error('Error creating employee:', empError);
      } else {
        employees.push(emp);
        console.log('✅ Created employee:', emp.name);
      }
    }

    // Create demo vehicles
    const vehicles = [];
    const vehicleModels = [
      { make: 'Toyota', model: 'Camry', year: 2023 },
      { make: 'Hyundai', model: 'Sonata', year: 2023 },
      { make: 'Nissan', model: 'Altima', year: 2022 },
      { make: 'Honda', model: 'Accord', year: 2023 },
      { make: 'Kia', model: 'Optima', year: 2022 },
    ];

    for (let i = 0; i < Math.min(5, org.max_vehicles); i++) {
      const { data: vehicle, error: vehicleError } = await supabaseClient
        .from('vehicles')
        .insert({
          organization_id,
          user_id: userId,
          make: vehicleModels[i].make,
          model: vehicleModels[i].model,
          year: vehicleModels[i].year,
          plate_number: `ABC ${1000 + i}`,
          status: 'available',
          mileage: 10000 + (i * 5000),
        })
        .select()
        .single();

      if (vehicleError) {
        console.error('Error creating vehicle:', vehicleError);
      } else {
        vehicles.push(vehicle);
        console.log('✅ Created vehicle:', vehicle.make, vehicle.model);
      }
    }

    // Create attendance records for the last 7 days
    const attendanceRecords = [];
    for (const emp of employees) {
      for (let day = 0; day < 7; day++) {
        const date = new Date();
        date.setDate(date.getDate() - day);
        date.setHours(8, 0, 0, 0);

        const checkOut = new Date(date);
        checkOut.setHours(17, 0, 0, 0);

        const { data: attendance, error: attendanceError } = await supabaseClient
          .from('attendance_records')
          .insert({
            organization_id,
            user_id: userId,
            employee_id: emp.id,
            check_in: date.toISOString(),
            check_out: checkOut.toISOString(),
            work_hours: 9,
            overtime_hours: day === 0 ? 2 : 0,
          })
          .select()
          .single();

        if (attendanceError) {
          console.error('Error creating attendance:', attendanceError);
        } else {
          attendanceRecords.push(attendance);
        }
      }
    }

    console.log('✅ Created', attendanceRecords.length, 'attendance records');

    // Create leave requests
    for (const emp of employees.slice(0, 2)) {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() + 7);
      const endDate = new Date(startDate);
      endDate.setDate(endDate.getDate() + 3);

      await supabaseClient
        .from('leave_requests')
        .insert({
          organization_id,
          user_id: userId,
          employee_id: emp.id,
          leave_type: 'annual',
          start_date: startDate.toISOString(),
          end_date: endDate.toISOString(),
          days_count: 3,
          status: 'pending',
          reason: 'إجازة سنوية',
        });
    }

    console.log('✅ Created leave requests');

    // Create payroll records for current month
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();

    for (const emp of employees) {
      await supabaseClient
        .from('payroll_records')
        .insert({
          organization_id,
          user_id: userId,
          employee_id: emp.id,
          month: currentMonth,
          year: currentYear,
          base_salary: emp.salary,
          total_allowances: 500,
          total_deductions: 100,
          overtime_amount: 0,
          gosi_employee: emp.salary * 0.1,
          gosi_company: emp.salary * 0.12,
          net_salary: emp.salary + 500 - 100 - (emp.salary * 0.1),
        });
    }

    console.log('✅ Created payroll records');

    return new Response(
      JSON.stringify({
        success: true,
        message: 'تم إنشاء بيانات الديمو بنجاح',
        stats: {
          employees: employees.length,
          vehicles: vehicles.length,
          attendance: attendanceRecords.length,
        },
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('❌ Error creating demo data:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    const errorDetails = error instanceof Error ? error.toString() : String(error);
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        details: errorDetails
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});
